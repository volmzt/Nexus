# Room, Compose and AndroidX ship their own consumer rules.
-keepattributes SourceFile,LineNumberTable
# Shizuku talks to the system through binders and reflection; keep its classes intact.
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-dontwarn rikka.**
-dontwarn moe.**
