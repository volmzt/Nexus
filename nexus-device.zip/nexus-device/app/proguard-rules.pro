# Room, Compose and AndroidX ship their own consumer rules.
-keepattributes SourceFile,LineNumberTable
