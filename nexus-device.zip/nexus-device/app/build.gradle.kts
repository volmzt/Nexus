plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.nexus.device"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexus.device"
        minSdk = 26
        targetSdk = 35
        // CI passes its run number, so every build is newer than the previous one and installs as an update.
        versionCode = 100 + (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0)
        versionName = "0.9.8"
    }

    signingConfigs {
        // One fixed key for debug and release builds from this repository. Without it every CI run would
        // generate a new random debug key and Android would refuse to install a build over the previous one.
        // It is meant for sideloading only: it is public. Use the NEXUS_KEYSTORE_* secrets for a private release key.
        create("sideload") {
            storeFile = file("nexus-sideload.jks")
            storePassword = "nexus-sideload"
            keyAlias = "nexus"
            keyPassword = "nexus-sideload"
        }
        create("release") {
            val ks = System.getenv("NEXUS_KEYSTORE_FILE")
            if (ks != null) {
                storeFile = file(ks)
                storePassword = System.getenv("NEXUS_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("NEXUS_KEY_ALIAS")
                keyPassword = System.getenv("NEXUS_KEY_PASSWORD")
            } else {
                // No private release keystore supplied: use the fixed sideload key.
                val d = signingConfigs.getByName("sideload")
                storeFile = d.storeFile
                storePassword = d.storePassword
                keyAlias = d.keyAlias
                keyPassword = d.keyPassword
            }
        }
    }

    buildTypes {
        debug {
            // Not debuggable: the build that people install runs like a release build, without the debug slowdown.
            isDebuggable = false
            signingConfig = signingConfigs.getByName("sideload")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.icons.extended)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.shizuku.api)
    implementation(libs.shizuku.provider)

    testImplementation(libs.junit)
}
