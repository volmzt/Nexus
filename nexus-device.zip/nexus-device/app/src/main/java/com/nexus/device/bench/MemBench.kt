package com.nexus.device.bench

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile

data class StorageResult(val writeMBs: Double, val readMBs: Double, val randomIops: Double)

/** Memory and storage tests. Buffers are released as soon as a test ends, so the whole set fits in a small heap. */
object MemBench {
    @Volatile
    private var sink = 0

    /** Copies two 24 MB buffers back and forth for 2 seconds; returns GB/s of data moved. */
    fun copy(): Double {
        val a = ByteArray(24 shl 20)
        val b = ByteArray(24 shl 20)
        var i = 0
        while (i < a.size) { a[i] = 1; i += 4096 }
        System.arraycopy(a, 0, b, 0, a.size)
        var moved = 0L
        val start = System.nanoTime()
        val end = start + 2_000_000_000L
        var now = start
        while (now < end) {
            System.arraycopy(a, 0, b, 0, a.size)
            System.arraycopy(b, 0, a, 0, a.size)
            moved += 2L * a.size
            now = System.nanoTime()
        }
        sink = a[17].toInt() + b[17].toInt()
        return moved / ((now - start) / 1e9) / 1e9
    }

    /** Follows a random cycle through 24 MB of ints: every step must wait for the previous one, so it measures latency. */
    fun latency(): Double {
        val n = 6 shl 20
        val next = IntArray(n) { it }
        var x = 0x2545F491
        var i = n - 1
        while (i > 0) {
            x = x xor (x shl 13)
            x = x xor (x ushr 17)
            x = x xor (x shl 5)
            val j = (x and Int.MAX_VALUE) % i
            val t = next[i]
            next[i] = next[j]
            next[j] = t
            i--
        }
        var p = 0
        var steps = 0L
        val start = System.nanoTime()
        val end = start + 2_000_000_000L
        var now = start
        while (now < end) {
            for (k in 0 until 200_000) p = next[p]
            steps += 200_000L
            now = System.nanoTime()
        }
        sink = p
        return steps / ((now - start) / 1e9) / 1e6
    }

    /**
     * Writes 96 MB to the app's cache folder (forced to disk), then reads it back and reads random 4 KB blocks.
     * The file is dropped from the page cache before each read so the numbers are not just RAM speed.
     * Returns null when there is not enough free space.
     */
    fun storage(dir: File): StorageResult? {
        if (dir.usableSpace < (400L shl 20)) return null
        val file = File(dir, "nexus_bench.tmp")
        val blocks = 96
        val block = ByteArray(1 shl 20).also { java.util.Random(7).nextBytes(it) }
        try {
            val w0 = System.nanoTime()
            FileOutputStream(file).use { out ->
                for (k in 0 until blocks) out.write(block)
                out.flush()
                out.fd.sync()
            }
            val writeS = (System.nanoTime() - w0) / 1e9

            val buf = ByteArray(1 shl 20)
            val r0 = System.nanoTime()
            FileInputStream(file).use { input -> while (input.read(buf) > 0) { } }
            val readS = (System.nanoTime() - r0) / 1e9

            val ops = 2000
            val rnd = java.util.Random(11)
            val small = ByteArray(4096)
            val q0 = System.nanoTime()
            RandomAccessFile(file, "r").use { raf ->
                for (k in 0 until ops) {
                    raf.seek(rnd.nextInt(blocks * 256).toLong() * 4096L)
                    raf.readFully(small)
                }
            }
            val randS = (System.nanoTime() - q0) / 1e9
            return StorageResult(blocks / writeS, blocks / readS, ops / randS)
        } finally {
            file.delete()
        }
    }

}
