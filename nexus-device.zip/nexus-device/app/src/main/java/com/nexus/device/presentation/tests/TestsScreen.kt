package com.nexus.device.presentation.tests

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.diagnostics.BenchmarkRunner
import com.nexus.device.presentation.BenchmarkViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.groupShape

enum class Tool { NET, ANALYZER, SENSORS_LIVE }

private enum class DisplayTest { RED, GREEN, BLUE, WHITE, BLACK, GRADIENT, GRAY, TOUCH }

@Composable
fun TestsScreen(vm: BenchmarkViewModel, onTool: (Tool) -> Unit, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    var display by remember { mutableStateOf<DisplayTest?>(null) }

    Box(modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            item { BigTitle(stringResource(R.string.tests_title)) }
            item {
                Text(stringResource(R.string.tests_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (ui.running == null) Button(onClick = { vm.runAll() }) { Text(stringResource(R.string.run_all)) }
                    else OutlinedButton(onClick = { vm.cancel() }) { Text(stringResource(R.string.cancel)) }
                }
                ui.heatC?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(stringResource(R.string.hot_stop, Fmt.one(it.toDouble())), color = MaterialTheme.colorScheme.error)
                }
                ui.error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(12.dp))
            }

            val tests = BenchmarkRunner.tests
            items(tests.size) { i ->
                val t = tests[i]
                val runs = history.filter { it.testId == t.id }
                val last = runs.getOrNull(0)
                val prev = runs.getOrNull(1)
                val delta = if (last != null && prev != null && prev.value > 0) (last.value / prev.value - 1) * 100 else null
                ItemRow(
                    title = t.name,
                    subtitle = when {
                        ui.running == t.id -> stringResource(R.string.running)
                        last == null -> t.note
                        else -> Fmt.one(last.value) + " " + t.unit + (delta?.let { " · " + stringResource(R.string.vs_previous, (if (it >= 0) "+" else "") + Fmt.one(it) + " %") } ?: "")
                    },
                    icon = Icons.Filled.PlayArrow,
                    shape = groupShape(i, tests.size),
                    onClick = if (ui.running == null) ({ vm.run(t.id) }) else null,
                )
            }

            item { Spacer(Modifier.height(16.dp)); Text(stringResource(R.string.display_tests), style = MaterialTheme.typography.titleMedium); Spacer(Modifier.height(8.dp)) }
            val dt = DisplayTest.entries
            items(dt.size) { i ->
                val d = dt[i]
                ItemRow(
                    title = stringResource(
                        when (d) {
                            DisplayTest.RED -> R.string.test_red
                            DisplayTest.GREEN -> R.string.test_green
                            DisplayTest.BLUE -> R.string.test_blue
                            DisplayTest.WHITE -> R.string.test_white
                            DisplayTest.BLACK -> R.string.test_black
                            DisplayTest.GRADIENT -> R.string.test_gradient
                            DisplayTest.GRAY -> R.string.test_gray
                            DisplayTest.TOUCH -> R.string.test_touch
                        },
                    ),
                    icon = if (d == DisplayTest.TOUCH) Icons.Filled.TouchApp else Icons.Filled.Palette,
                    shape = groupShape(i, dt.size), onClick = { display = d },
                )
            }

            item { Spacer(Modifier.height(16.dp)); Text(stringResource(R.string.tools), style = MaterialTheme.typography.titleMedium); Spacer(Modifier.height(8.dp)) }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    ItemRow(stringResource(R.string.net_diag), icon = Icons.Filled.Cloud, shape = groupShape(0, 3), onClick = { onTool(Tool.NET) }, chevron = true)
                    ItemRow(stringResource(R.string.analyzer), icon = Icons.Filled.FolderOpen, shape = groupShape(1, 3), onClick = { onTool(Tool.ANALYZER) }, chevron = true)
                    ItemRow(stringResource(R.string.sensors_live), icon = Icons.Filled.ShowChart, shape = groupShape(2, 3), onClick = { onTool(Tool.SENSORS_LIVE) }, chevron = true)
                }
            }
            item { Spacer(Modifier.height(120.dp)) }
        }

        display?.let { DisplayTestOverlay(it) { display = null } }
    }
}

@Composable
private fun DisplayTestOverlay(test: DisplayTest, onClose: () -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when (test) {
            DisplayTest.RED -> Box(Modifier.fillMaxSize().background(Color.Red))
            DisplayTest.GREEN -> Box(Modifier.fillMaxSize().background(Color.Green))
            DisplayTest.BLUE -> Box(Modifier.fillMaxSize().background(Color.Blue))
            DisplayTest.WHITE -> Box(Modifier.fillMaxSize().background(Color.White))
            DisplayTest.BLACK -> Box(Modifier.fillMaxSize().background(Color.Black))
            DisplayTest.GRADIENT -> Box(
                Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)),
                ),
            )
            DisplayTest.GRAY -> Row(Modifier.fillMaxSize()) {
                val steps = 16
                for (i in 0 until steps) {
                    val v = i / (steps - 1f)
                    Box(Modifier.weight(1f).fillMaxSize().background(Color(v, v, v)))
                }
            }
            DisplayTest.TOUCH -> {
                // Every finger gets its own stroke, so multi-touch can be checked.
                Canvas(
                    Modifier.fillMaxSize().pointerInput(Unit) {
                        awaitPointerEventScope {
                            val active = HashMap<Long, Int>()
                            while (true) {
                                val ev = awaitPointerEvent()
                                for (c in ev.changes) {
                                    val id = c.id.value
                                    if (c.pressed) {
                                        val idx = active[id]
                                        if (idx == null) {
                                            strokes.add(listOf(c.position))
                                            active[id] = strokes.lastIndex
                                        } else {
                                            strokes[idx] = strokes[idx] + c.position
                                        }
                                        c.consume()
                                    } else {
                                        active.remove(id)
                                    }
                                }
                            }
                        }
                    },
                ) {
                    strokes.forEach { pts ->
                        if (pts.size == 1) {
                            drawCircle(Color.Cyan, 10f, pts[0])
                        } else {
                            val p = Path()
                            pts.forEachIndexed { i, o -> if (i == 0) p.moveTo(o.x, o.y) else p.lineTo(o.x, o.y) }
                            drawPath(p, Color.Cyan, style = Stroke(width = 8f, cap = StrokeCap.Round))
                        }
                    }
                }
                Text(
                    stringResource(R.string.touch_hint), color = Color.White,
                    modifier = Modifier.align(Alignment.TopCenter).windowInsetsPadding(WindowInsets.systemBars).padding(16.dp),
                )
            }
        }
        Button(
            onClick = onClose,
            modifier = Modifier.align(Alignment.BottomCenter).windowInsetsPadding(WindowInsets.systemBars).padding(16.dp),
        ) { Text(stringResource(R.string.close)) }
    }
}
