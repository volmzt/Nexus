package com.nexus.device.monitoring

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.io.File
import kotlin.math.abs

data class PowerState(
    val level: Int?,
    val charging: Boolean,
    val voltageV: Float?,
    /** Magnitude only: vendors disagree about the sign, so the direction comes from the charging state. */
    val currentMa: Int?,
    val watts: Float?,
    val tempC: Float?,
)

/**
 * Voltage, current and power of the battery. Two cheap reads (the sticky battery broadcast and one property),
 * no process, no polling of its own: the caller decides when to read.
 */
object PowerReader {
    fun read(context: Context): PowerState {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)?.takeIf { it >= 0 }
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        // Some phones report volts or millivolts in the broadcast; anything under 100 is volts.
        val volts = when { mv <= 0 -> null; mv < 100 -> mv.toFloat(); else -> mv / 1000f }
        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).takeIf { it != Int.MIN_VALUE && it != 0 }
            ?: runCatching { File("/sys/class/power_supply/battery/current_now").readText().trim().toInt() }.getOrNull()?.takeIf { it != 0 }
        // The property is documented as microamps, but some vendors report milliamps. Real battery currents are
        // under 20 A, so anything below 20000 in magnitude is read as milliamps.
        val ma = raw?.let { if (abs(it) < 20_000) abs(it) else abs(it) / 1000 }
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        return PowerState(
            level = level, charging = charging, voltageV = volts, currentMa = ma,
            watts = if (volts != null && ma != null) volts * ma / 1000f else null,
            tempC = if (t == Int.MIN_VALUE || t <= 0) null else t / 10f,
        )
    }
}
