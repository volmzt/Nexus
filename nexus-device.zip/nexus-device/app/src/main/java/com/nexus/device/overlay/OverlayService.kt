package com.nexus.device.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.nexus.device.MainActivity
import com.nexus.device.NexusApplication
import com.nexus.device.R
import com.nexus.device.access.AccessMode
import com.nexus.device.access.Privileged
import com.nexus.device.control.ControlRepo
import com.nexus.device.core.Fmt
import com.nexus.device.data.SettingsRepository
import com.nexus.device.monitoring.TempReader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Which values the small floating window can show. The first four are on by default. */
object OverlayItems {
    val all = listOf("pct", "fps", "time", "temp", "cpu", "load", "mhz", "ram")
    const val DEFAULT = "pct,fps,time,temp"
    fun decode(s: String): List<String> = s.split(',').filter { it in all }
}

/**
 * Small always-on-top pill with a few live values. Plain Android views (no Compose) so the service stays light.
 * Exists only while the user keeps the switch on and has allowed "display over other apps".
 */
class OverlayService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var view: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val wm by lazy { getSystemService(WindowManager::class.java) }
    private var fpsLayer: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as NexusApplication
        if (intent?.action == ACTION_STOP) {
            scope.launch { app.container.settings.setOverlayOn(false); stopSelf() }
            return START_NOT_STICKY
        }
        if (!canDraw(this)) { stopSelf(); return START_NOT_STICKY }
        ensureChannel()
        val n = notification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(ID, n)
        if (job == null) {
            job = scope.launch {
                val repo = app.container.settings
                val s0 = repo.settings.first()
                withContext(Dispatchers.Main) { attach(repo, s0.overlayX, s0.overlayY, s0.overlayAlpha) }
                val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
                while (isActive) {
                    val s = repo.settings.first()
                    val items = OverlayItems.decode(s.overlayItems)
                    val text = buildText(items, s.tempUnit, app, fmt)
                    withContext(Dispatchers.Main) { view?.let { v -> v.text = text; v.background?.alpha = (s.overlayAlpha * 255 / 100).coerceIn(40, 255) } }
                    delay(1000)
                }
            }
        }
        return START_STICKY
    }

    private suspend fun buildText(items: List<String>, unit: com.nexus.device.core.TempUnit, app: NexusApplication, fmt: SimpleDateFormat): String {
        val sample = app.container.sampler.sample()
        val temps = if ("temp" in items || "cpu" in items) TempReader.read(this) else null
        val parts = ArrayList<String>()
        for (id in items) {
            when (id) {
                "pct" -> parts += (sample.batteryLevel?.let { "$it%" } ?: "—")
                "fps" -> parts += (readFps()?.let { "$it FPS" } ?: "— FPS")
                "time" -> parts += fmt.format(Date())
                "temp" -> parts += (temps?.batteryC?.let { Fmt.temp(it, unit) } ?: "—")
                "cpu" -> parts += "CPU " + (temps?.cpuC?.let { Fmt.temp(it, unit) } ?: "—")
                "load" -> parts += "L " + (ControlRepo.coreLoads().takeIf { it.isNotEmpty() }?.average()?.toInt()?.let { "$it%" } ?: "—")
                "mhz" -> parts += (sample.cpuFreqKHz.filterNotNull().maxOrNull()?.let { "${it / 1000} MHz" } ?: "— MHz")
                "ram" -> parts += "RAM ${sample.ramUsedPercent.toInt()}%"
            }
        }
        return parts.joinToString("  ·  ")
    }

    /** Real frame rate of the app in front, from SurfaceFlinger. Needs Shizuku or root; otherwise null (shown as a dash). */
    private suspend fun readFps(): Int? {
        if (Privileged.state.value.mode == AccessMode.NONE) return null
        return runCatching {
            val top = Privileged.exec("dumpsys activity activities | grep -m1 topResumedActivity").out
            val comp = Regex("""([\w.]+/[\w.$]+)""").find(top)?.value ?: return null
            if (fpsLayer == null || fpsLayer?.startsWith(comp) != true) {
                val list = Privileged.exec("dumpsys SurfaceFlinger --list").out.lines()
                fpsLayer = list.firstOrNull { it.startsWith(comp) && !it.contains("Background") && !it.contains("Bounds") }?.trim()
                    ?: list.firstOrNull { it.contains(comp.substringBefore('/')) && it.contains("#") && !it.contains("Background") && !it.contains("Bounds") }?.trim()
            }
            val layer = fpsLayer ?: return null
            val rows = Privileged.exec("dumpsys SurfaceFlinger --latency '$layer'").out.lines().drop(1)
            val times = rows.mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
                .filter { it > 0 && it != Long.MAX_VALUE }
            if (times.size < 2) return null
            val newest = times.max()
            if (System.nanoTime() - newest > 1_500_000_000L) return 0
            val recent = times.filter { newest - it <= 1_000_000_000L }.sorted()
            if (recent.size < 2) return 0
            val span = (recent.last() - recent.first()) / 1e9
            if (span <= 0.0) null else Math.round((recent.size - 1) / span).toInt()
        }.getOrNull()
    }

    private fun attach(repo: SettingsRepository, x0: Int, y0: Int, alpha: Int) {
        val d = resources.displayMetrics.density
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding((10 * d).toInt(), (5 * d).toInt(), (10 * d).toInt(), (5 * d).toInt())
            background = GradientDrawable().apply { cornerRadius = 14 * d; setColor(Color.BLACK); this.alpha = (alpha * 255 / 100).coerceIn(40, 255) }
            text = "…"
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = x0; y = y0 }
        tv.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(e.rawX - sx) > 6 * d || abs(e.rawY - sy) > 6 * d) moved = true
                        if (moved) {
                            lp.x = (ox + (e.rawX - sx)).toInt().coerceAtLeast(0)
                            lp.y = (oy + (e.rawY - sy)).toInt().coerceAtLeast(0)
                            runCatching { wm.updateViewLayout(v, lp) }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) scope.launch { repo.setOverlayPos(lp.x, lp.y) }
                        else startActivity(Intent(this@OverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
                return true
            }
        })
        runCatching { wm.addView(tv, lp) }.onSuccess { view = tv; params = lp }
    }

    override fun onDestroy() {
        scope.cancel()
        view?.let { v -> runCatching { wm.removeView(v) } }
        view = null
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.ov_channel), NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_temp)
            .setContentTitle(getString(R.string.ov_notif))
            .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
            .setContentIntent(open)
            .addAction(0, getString(R.string.notif_stop), stop)
            .build()
    }

    companion object {
        private const val CHANNEL = "overlay"
        private const val ID = 7002
        private const val ACTION_STOP = "com.nexus.device.STOP_OVERLAY"

        fun canDraw(c: Context) = Settings.canDrawOverlays(c)

        fun start(context: Context) {
            if (!canDraw(context)) return
            val i = Intent(context, OverlayService::class.java)
            runCatching { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i) }
        }

        fun stop(context: Context) { context.stopService(Intent(context, OverlayService::class.java)) }
    }
}
