package com.nexus.device.core

/** How trustworthy / obtainable a value is. Drives the colour of the status label in the UI. */
enum class Availability { AVAILABLE, APPROXIMATE, UNAVAILABLE, PERMISSION }

data class Spec(
    val label: String,
    val value: String,
    val availability: Availability = Availability.AVAILABLE,
    /** Serial numbers, fingerprints and similar. Excluded from reports when "hide IDs" is on. */
    val sensitive: Boolean = false,
)

/**
 * The single error-handling mechanism for hardware reads.
 * - returns the value when [block] produces one;
 * - UNAVAILABLE with [reason] when Android does not expose it (null) or the read fails;
 * - PERMISSION when the system throws SecurityException.
 */
inline fun spec(
    label: String,
    approximate: Boolean = false,
    sensitive: Boolean = false,
    reason: String = "Not exposed by Android",
    block: () -> String?,
): Spec = try {
    val v = block()
    if (v.isNullOrBlank()) {
        Spec(label, reason, Availability.UNAVAILABLE)
    } else {
        Spec(label, v, if (approximate) Availability.APPROXIMATE else Availability.AVAILABLE, sensitive)
    }
} catch (e: SecurityException) {
    Spec(label, "Requires a permission", Availability.PERMISSION)
} catch (e: Exception) {
    Spec(label, reason, Availability.UNAVAILABLE)
}
