package com.nexus.device

import android.app.Application
import com.nexus.device.core.di.AppContainer

class NexusApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
