package com.nexus.device.presentation

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.nexus.device.R
import com.nexus.device.core.Availability
import com.nexus.device.core.Spec
import com.nexus.device.domain.Category
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.StatusText
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.theme.color

fun Category.titleRes(): Int = when (this) {
    Category.CPU -> R.string.cat_cpu
    Category.GPU -> R.string.cat_gpu
    Category.MEMORY -> R.string.cat_memory
    Category.STORAGE -> R.string.cat_storage
    Category.SYSTEM -> R.string.cat_system
    Category.DISPLAY -> R.string.cat_display
    Category.BATTERY -> R.string.cat_battery
    Category.NETWORK -> R.string.cat_network
    Category.SENSORS -> R.string.cat_sensors
    Category.CAMERA -> R.string.cat_camera
    Category.CODECS -> R.string.cat_codecs
    Category.APPS -> R.string.cat_apps
}

fun Category.icon(): ImageVector = when (this) {
    Category.CPU -> Icons.Filled.Memory
    Category.GPU -> Icons.Filled.BlurOn
    Category.MEMORY -> Icons.Filled.SdStorage
    Category.STORAGE -> Icons.Filled.Storage
    Category.SYSTEM -> Icons.Filled.Info
    Category.DISPLAY -> Icons.Filled.Smartphone
    Category.BATTERY -> Icons.Filled.BatteryFull
    Category.NETWORK -> Icons.Filled.Wifi
    Category.SENSORS -> Icons.Filled.Sensors
    Category.CAMERA -> Icons.Filled.CameraAlt
    Category.CODECS -> Icons.Filled.Movie
    Category.APPS -> Icons.Filled.Apps
}

@Composable
fun Availability.label(): String = when (this) {
    Availability.AVAILABLE -> stringResource(R.string.st_available)
    Availability.APPROXIMATE -> stringResource(R.string.st_approx)
    Availability.UNAVAILABLE -> stringResource(R.string.st_na)
    Availability.PERMISSION -> stringResource(R.string.st_perm)
}

/** Returns a function that copies text and tells the user. */
@Composable
fun rememberCopier(): (String) -> Unit {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    val msg = stringResource(R.string.copied)
    return { text ->
        clip.setText(AnnotatedString(text))
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }
}

fun toast(context: Context, text: String) = Toast.makeText(context, text, Toast.LENGTH_SHORT).show()

/** A grouped card of specification rows. Each row copies its value on tap and shows its availability. */
@Composable
fun SpecGroup(specs: List<Spec>, modifier: Modifier = Modifier, prefix: (Int) -> String = { "" }) {
    val copy = rememberCopier()
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        specs.forEachIndexed { i, s ->
            ItemRow(
                title = prefix(i) + s.label,
                subtitle = s.value,
                shape = groupShape(i, specs.size),
                onClick = { copy(s.value) },
                trailing = { if (s.availability != Availability.AVAILABLE) StatusText(s.availability.label(), s.availability.color()) },
            )
        }
    }
}
