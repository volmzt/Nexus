package com.nexus.device.presentation.bench

import androidx.compose.foundation.clickable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.bench.BenchGroup
import com.nexus.device.bench.formatPoints
import com.nexus.device.presentation.components.cardSurface

/** The big card at the top of Home: last total, the four group scores and the button that starts a new test. */
@Composable
fun BenchHomeCard(vm: BenchViewModel, onOpen: () -> Unit, onRun: () -> Unit, modifier: Modifier = Modifier) {
    val history by vm.history.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val last = history.firstOrNull()

    Column(
        modifier.fillMaxWidth().cardSurface(RoundedCornerShape(28.dp)).clickable(onClick = onOpen).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.bench_total), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(last?.let { formatPoints(it.total) } ?: "—", style = MaterialTheme.typography.displaySmall)
                Text(
                    if (ui.running) stringResource(R.string.bench_running) else if (last == null) stringResource(R.string.bench_never) else stringResource(R.string.bench_tap),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Button(onClick = onRun, enabled = !ui.running) { Text(stringResource(R.string.bench_run)) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            BenchGroup.entries.forEach { g ->
                Column {
                    Text(stringResource(groupName(g)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(last?.let { formatPoints(it.group(g)) } ?: "—", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}
