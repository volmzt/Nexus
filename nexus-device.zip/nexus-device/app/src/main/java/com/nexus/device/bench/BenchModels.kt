package com.nexus.device.bench

import androidx.annotation.StringRes
import com.nexus.device.R
import java.text.NumberFormat

enum class BenchGroup { CPU, GPU, MEM, UX }

/** What one test measures, in which unit, and the value that earns [Scoring.POINTS_AT_REFERENCE] points. */
data class TestDef(val id: String, val group: BenchGroup, @StringRes val name: Int, val unit: String, val reference: Double)

/**
 * The NEXUS test list. References describe a typical mid-range phone of about 2021, so a phone of that class lands
 * near 160 000 points. The scale belongs to NEXUS only: it is not comparable with AnTuTu or any other app.
 */
object Catalog {
    val defs: List<TestDef> = listOf(
        TestDef("cpu_int", BenchGroup.CPU, R.string.bench_t_int, "runs/s", 1500.0),
        TestDef("cpu_float", BenchGroup.CPU, R.string.bench_t_float, "runs/s", 4000.0),
        TestDef("cpu_crypto", BenchGroup.CPU, R.string.bench_t_crypto, "MB/s", 600.0),
        TestDef("cpu_zip", BenchGroup.CPU, R.string.bench_t_zip, "MB/s", 25.0),
        TestDef("cpu_multi", BenchGroup.CPU, R.string.bench_t_multi, "runs/s", 5000.0),
        TestDef("gpu_alu", BenchGroup.GPU, R.string.bench_t_alu, "fps", 35.0),
        TestDef("gpu_fill", BenchGroup.GPU, R.string.bench_t_fill, "Gpix/s", 2.0),
        TestDef("gpu_geo", BenchGroup.GPU, R.string.bench_t_geo, "Mtri/s", 250.0),
        TestDef("mem_copy", BenchGroup.MEM, R.string.bench_t_copy, "GB/s", 6.0),
        TestDef("mem_lat", BenchGroup.MEM, R.string.bench_t_lat, "M acc/s", 12.0),
        TestDef("st_write", BenchGroup.MEM, R.string.bench_t_write, "MB/s", 300.0),
        TestDef("st_read", BenchGroup.MEM, R.string.bench_t_read, "MB/s", 700.0),
        TestDef("st_rand", BenchGroup.MEM, R.string.bench_t_rand, "IOPS", 6000.0),
        TestDef("ux_json", BenchGroup.UX, R.string.bench_t_json, "MB/s", 12.0),
        TestDef("ux_image", BenchGroup.UX, R.string.bench_t_image, "MP/s", 10.0),
        TestDef("ux_smooth", BenchGroup.UX, R.string.bench_t_smooth, "%", 90.0),
    )

    private val byId = defs.associateBy { it.id }
    fun get(id: String): TestDef? = byId[id]
}

object Scoring {
    const val POINTS_AT_REFERENCE = 10_000
    fun points(value: Double, reference: Double): Int =
        (POINTS_AT_REFERENCE * value / reference).toInt().coerceAtLeast(0)
}

data class TestScore(val id: String, val value: Double, val points: Int)

data class BenchRun(
    val time: Long,
    val scores: List<TestScore>,
    val battStartC: Float?,
    val battEndC: Float?,
    val cpuStartC: Float?,
    val cpuEndC: Float?,
) {
    fun group(g: BenchGroup): Int = scores.filter { Catalog.get(it.id)?.group == g }.sumOf { it.points }
    val total: Int get() = scores.sumOf { it.points }
}

fun formatPoints(n: Int): String = NumberFormat.getIntegerInstance().format(n)
