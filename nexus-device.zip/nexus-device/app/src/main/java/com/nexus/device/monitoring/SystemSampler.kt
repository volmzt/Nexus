package com.nexus.device.monitoring

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import com.nexus.device.domain.Sample
import com.nexus.device.hardware.CpuFreqReader

/** Takes one real measurement. Used by Home, Monitoring and the benchmark's heat guard. */
class SystemSampler(private val context: Context) {
    private val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private fun batteryIntent(): Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    fun batteryTempC(): Float? {
        val t = batteryIntent()?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: return null
        return if (t == Int.MIN_VALUE) null else t / 10f
    }

    fun sample(): Sample {
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val b = batteryIntent()
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val st = StatFs(Environment.getDataDirectory().absolutePath)
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        return Sample(
            timestamp = System.currentTimeMillis(),
            ramUsedPercent = ((mi.totalMem - mi.availMem) * 100.0 / mi.totalMem).toFloat(),
            ramAvailBytes = mi.availMem,
            batteryTempC = batteryTempC(),
            batteryLevel = if (level >= 0 && scale > 0) level * 100 / scale else null,
            batteryCharging = if (status == -1) null else status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            storageUsedPercent = ((st.totalBytes - st.availableBytes) * 100.0 / st.totalBytes).toFloat(),
            cpuFreqKHz = CpuFreqReader.allCurrent(),
            networkOnline = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true,
        )
    }
}
