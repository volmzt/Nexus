package com.nexus.device.access

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit

enum class AccessMode { NONE, SHIZUKU, ROOT }

data class AccessState(
    val shizukuRunning: Boolean = false,
    val shizukuGranted: Boolean = false,
    val rootAvailable: Boolean = false,
    val rootChecked: Boolean = false,
) {
    /** Root wins when it was confirmed, then Shizuku, otherwise the app can only read. */
    val mode: AccessMode
        get() = when {
            rootAvailable -> AccessMode.ROOT
            shizukuRunning && shizukuGranted -> AccessMode.SHIZUKU
            else -> AccessMode.NONE
        }
}

data class ShellResult(val ok: Boolean, val out: String, val err: String)

/**
 * The only place that runs shell commands with extra rights.
 * - Shizuku: commands run as the adb shell user (enough for `wm`, `settings`, many /sys reads).
 * - Root: `su -c`, asked only when the user presses "Check root". Needed to write kernel files.
 * - None: commands run with the app's own rights, so most reads work and writes fail honestly.
 */
object Privileged {
    private const val REQ = 4711
    private val _state = MutableStateFlow(AccessState())
    val state: StateFlow<AccessState> = _state.asStateFlow()
    private var inited = false

    fun init() {
        if (inited) return
        inited = true
        runCatching {
            Shizuku.addBinderReceivedListener { refreshShizuku() }
            Shizuku.addBinderDeadListener { refreshShizuku() }
            Shizuku.addRequestPermissionResultListener { _, _ -> refreshShizuku() }
        }
        refreshShizuku()
    }

    fun refreshShizuku() {
        val running = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = running && runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)
        _state.update { it.copy(shizukuRunning = running, shizukuGranted = granted) }
    }

    fun requestShizuku() {
        runCatching {
            if (Shizuku.pingBinder() && !Shizuku.isPreV11()) Shizuku.requestPermission(REQ)
        }
        refreshShizuku()
    }

    /** Pops the root manager's prompt. Called only when the user presses the button. */
    suspend fun checkRoot(): Boolean {
        val r = run(listOf("su", "-c", "id"))
        val ok = r.ok && r.out.contains("uid=0")
        _state.update { it.copy(rootAvailable = ok, rootChecked = true) }
        return ok
    }

    /** Runs [cmd] with the best rights available, or with [mode] when given. */
    suspend fun exec(cmd: String, mode: AccessMode? = null): ShellResult = withContext(Dispatchers.IO) {
        when (mode ?: _state.value.mode) {
            AccessMode.ROOT -> run(listOf("su", "-c", cmd))
            AccessMode.SHIZUKU -> runShizuku(cmd)
            AccessMode.NONE -> run(listOf("sh", "-c", cmd))
        }
    }

    /** For kernel files: only root can write them. */
    suspend fun execRoot(cmd: String): ShellResult =
        if (_state.value.rootAvailable) exec(cmd, AccessMode.ROOT) else ShellResult(false, "", "NEEDS_ROOT")

    private fun runShizuku(cmd: String): ShellResult = try {
        // newProcess is not public in Shizuku API 13, the official guidance is a user service; reflection keeps this small.
        val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        collect(p)
    } catch (e: Throwable) {
        ShellResult(false, "", e.cause?.message ?: e.message ?: e.javaClass.simpleName)
    }

    private fun run(args: List<String>): ShellResult = try {
        collect(ProcessBuilder(args).redirectErrorStream(false).start())
    } catch (e: Throwable) {
        ShellResult(false, "", e.message ?: e.javaClass.simpleName)
    }

    private fun collect(p: Process): ShellResult {
        var err = ""
        val t = Thread { err = runCatching { p.errorStream.bufferedReader().readText() }.getOrDefault("") }.apply { isDaemon = true; start() }
        val out = p.inputStream.bufferedReader().readText()
        val done = runCatching { p.waitFor(15, TimeUnit.SECONDS) }.getOrDefault(true)
        t.join(500)
        val code = if (done) runCatching { p.exitValue() }.getOrDefault(0) else -1
        if (!done) runCatching { p.destroy() }
        return ShellResult(code == 0, out.trim(), err.trim())
    }
}
