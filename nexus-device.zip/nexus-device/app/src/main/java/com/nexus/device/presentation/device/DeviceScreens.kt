package com.nexus.device.presentation.device

import androidx.compose.foundation.background
import com.nexus.device.presentation.components.cardSurface
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.Availability
import com.nexus.device.core.Spec
import com.nexus.device.domain.Category
import com.nexus.device.hardware.CpuFreqReader
import com.nexus.device.presentation.DeviceViewModel
import com.nexus.device.presentation.SpecGroup
import com.nexus.device.presentation.ViewModeToggle
import com.nexus.device.presentation.categorySummary
import com.nexus.device.presentation.forView
import com.nexus.device.presentation.rememberSpecDialog
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.icon
import com.nexus.device.presentation.label
import com.nexus.device.presentation.rememberCopier
import com.nexus.device.presentation.theme.color
import com.nexus.device.presentation.titleRes
import kotlinx.coroutines.delay

@Composable
fun DeviceScreen(
    vm: DeviceViewModel,
    hidden: Set<String>,
    detailed: Boolean,
    onDetailed: (Boolean) -> Unit,
    onOpen: (Category) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
) {
    val query by vm.query.collectAsStateWithLifecycle()
    val results by vm.results.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val all by vm.all.collectAsStateWithLifecycle()
    val copy = rememberCopier()
    val show = rememberSpecDialog()
    val cats = Category.entries.filter { it.id !in hidden }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { BigTitle(stringResource(R.string.device_title)) }
        item {
            TextField(
                value = query, onValueChange = { vm.query.value = it }, singleLine = true,
                placeholder = { Text(stringResource(R.string.search_hint)) },
                shape = CircleShape,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                ),
                keyboardOptions = KeyboardOptions.Default,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            ViewModeToggle(detailed, onDetailed)
            Spacer(Modifier.height(8.dp))
            Text(
                stringResource(R.string.device_tip), style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 8.dp),
            )
            Spacer(Modifier.height(8.dp))
        }
        if (query.isBlank()) {
            items(cats.size) { i ->
                val c = cats[i]
                ItemRow(
                    stringResource(c.titleRes()), subtitle = categorySummary(c, all[c].orEmpty()),
                    icon = c.icon(), shape = groupShape(i, cats.size), onClick = { onOpen(c) }, chevron = true,
                )
            }
        } else if (loading) {
            item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        } else if (results.isEmpty()) {
            item { Text(stringResource(R.string.nothing_found), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp)) }
        } else {
            items(results.size) { i ->
                val (cat, s) = results[i]
                ItemRow(
                    title = s.label, subtitle = s.value, shape = groupShape(i, results.size),
                    onClick = { show(s) }, onLongClick = { copy(s.value) },
                    trailing = { Text(stringResource(cat.titleRes()), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                )
            }
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
fun DetailHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.layout.Box(Modifier.padding(top = 24.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
        }
        BigTitle(title)
    }
}

/** The generic detail page. Category-specific tools are appended through [extras]. */
@Composable
fun CategoryDetailScreen(
    category: Category,
    vm: DeviceViewModel,
    detailed: Boolean,
    onDetailed: (Boolean) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    listState: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState(),
    extras: @Composable () -> Unit = {},
) {
    val all by vm.all.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val specs: List<Spec> = all[category].orEmpty().forView(detailed)

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState) {
        item { DetailHeader(stringResource(category.titleRes()), onBack) }
        item { ViewModeToggle(detailed, onDetailed); Spacer(Modifier.height(8.dp)) }
        if (loading && specs.isEmpty()) {
            item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        }
        item { extras() }
        item { SpecGroup(specs) }
        item {
            Spacer(Modifier.height(8.dp))
            if (!detailed) Text(
                stringResource(R.string.view_simple_note), style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp),
            )
            Text(
                stringResource(R.string.tap_to_copy), style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(120.dp))
        }
    }
}

/** Per-core frequencies read live from sysfs. If Android hides the files, the screen says so instead of drawing zeros. */
@Composable
fun CpuLiveCores() {
    var freqs by remember { mutableStateOf<List<Long?>>(emptyList()) }
    LaunchedEffect(Unit) {
        while (true) {
            freqs = CpuFreqReader.allCurrent()
            delay(1000)
        }
    }
    if (freqs.isEmpty()) return
    val maxes = remember { List(freqs.size) { CpuFreqReader.maxKHz(it) } }
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp)
    Column(
        Modifier.fillMaxWidth().padding(bottom = 8.dp)
            .androidxClip(shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(stringResource(R.string.cpu_freq_mhz), style = MaterialTheme.typography.bodyLarge)
        if (freqs.all { it == null }) {
            Text(stringResource(R.string.cpu_freq_hidden), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            freqs.forEachIndexed { i, f ->
                val mx = maxes[i]
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("cpu$i", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(end = 2.dp))
                    val frac = if (f != null && mx != null && mx > 0) (f.toFloat() / mx).coerceIn(0f, 1f) else 0f
                    Box(Modifier.weight(1f).height(8.dp).androidxClipCircle(MaterialTheme.colorScheme.surfaceContainerHigh)) {
                        Box(Modifier.fillMaxWidth(frac).height(8.dp).androidxClipCircle(MaterialTheme.colorScheme.primary))
                    }
                    Text(f?.let { "${it / 1000}" } ?: "—", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(start = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun Modifier.androidxClip(shape: androidx.compose.ui.graphics.Shape): Modifier =
    this.then(Modifier.cardSurface(shape))

@Composable
private fun Modifier.androidxClipCircle(color: androidx.compose.ui.graphics.Color): Modifier =
    this.then(Modifier.clip(CircleShape).background(color))
