package com.nexus.device.domain

import com.nexus.device.core.Availability
import com.nexus.device.core.Spec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class Category(val id: String) {
    CPU("cpu"), GPU("gpu"), MEMORY("memory"), STORAGE("storage"), SYSTEM("system"),
    DISPLAY("display"), BATTERY("battery"), NETWORK("network"), SENSORS("sensors"),
    CAMERA("camera"), CODECS("codecs"), APPS("apps")
}

/** A hardware provider reads one category straight from Android APIs. It never returns invented values. */
interface SpecProvider {
    val category: Category
    fun read(): List<Spec>
}

class DeviceRepository(private val providers: List<SpecProvider>) {
    suspend fun readAll(): Map<Category, List<Spec>> = withContext(Dispatchers.Default) {
        providers.associate { p ->
            p.category to runCatching { p.read() }.getOrElse {
                listOf(Spec("Error", it.message ?: "Provider failed", Availability.UNAVAILABLE))
            }
        }
    }

    suspend fun read(category: Category): List<Spec> = withContext(Dispatchers.Default) {
        providers.firstOrNull { it.category == category }
            ?.let { p -> runCatching { p.read() }.getOrElse { listOf(Spec("Error", it.message ?: "Provider failed", Availability.UNAVAILABLE)) } }
            ?: emptyList()
    }
}

/** One measurement of the live system state. Every field comes from a real API read. */
data class Sample(
    val timestamp: Long,
    val ramUsedPercent: Float,
    val ramAvailBytes: Long,
    val batteryTempC: Float?,
    val batteryLevel: Int?,
    val batteryCharging: Boolean?,
    val storageUsedPercent: Float,
    val cpuFreqKHz: List<Long?>,
    val networkOnline: Boolean,
)
