package com.nexus.device.hardware

/** Reads Android system properties through `getprop`; any app may do this. Returns null when empty or unreadable. */
object SystemProps {
    fun get(key: String): String? = runCatching {
        val p = ProcessBuilder("getprop", key).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        text.ifBlank { null }
    }.getOrNull()
}
