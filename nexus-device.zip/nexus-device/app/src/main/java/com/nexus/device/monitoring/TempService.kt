package com.nexus.device.monitoring

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nexus.device.MainActivity
import com.nexus.device.NexusApplication
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Optional foreground service: battery and CPU temperature in the notification shade.
 * It exists only while the user keeps the switch on, and it survives closing the app.
 */
class TempService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            val c = (application as NexusApplication).container
            scope.launch { c.settings.setTempNotify(false); stopSelf() }
            return START_NOT_STICKY
        }
        ensureChannel()
        val first = build(getString(R.string.notif_starting), null, null)
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(ID, first)

        if (job == null) {
            job = scope.launch {
                val settings = (application as NexusApplication).container.settings
                val nm = getSystemService(NotificationManager::class.java)
                while (isActive) {
                    val unit: TempUnit = settings.settings.first().tempUnit
                    val t = TempReader.read(this@TempService)
                    runCatching { BatteryRecorder.record(this@TempService, (application as NexusApplication).container.database.batteryDao()) }
                    com.nexus.device.widget.TempWidget.push(this@TempService, t, unit)
                    val b = t.batteryC?.let { Fmt.temp(it, unit) } ?: "—"
                    val c = t.cpuC?.let { Fmt.temp(it, unit) } ?: "—"
                    val extra = t.zones.sortedByDescending { it.tempC }.take(4).joinToString("\n") { it.name + "  " + Fmt.temp(it.tempC, unit) }
                    nm.notify(ID, build(getString(R.string.notif_title, b, c), extra.ifBlank { null }, null))
                    delay(2000)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun build(title: String, big: String?, unused: Unit?): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, TempService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_temp)
            .setContentTitle(title)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(open)
            .addAction(0, getString(R.string.notif_stop), stop)
        if (big != null) b.setContentText(big.lines().first()).setStyle(NotificationCompat.BigTextStyle().bigText(big))
        return b.build()
    }

    companion object {
        private const val CHANNEL = "temps"
        private const val ID = 7001
        private const val ACTION_STOP = "com.nexus.device.STOP_TEMPS"

        /** Starts the notification service. Android may refuse a foreground start (for example from the background); that is not an error for the user. */
        fun start(context: Context) {
            val i = Intent(context, TempService::class.java)
            runCatching { if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i) }
        }

        fun stop(context: Context) { context.stopService(Intent(context, TempService::class.java)) }
    }
}
