package com.nexus.device.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.device.access.AccessMode
import com.nexus.device.access.Privileged
import com.nexus.device.access.ShellResult
import com.nexus.device.control.ControlRepo
import com.nexus.device.control.CpuPolicy
import com.nexus.device.control.DisplayState
import com.nexus.device.control.GpuState
import com.nexus.device.control.Tweaks
import com.nexus.device.core.di.AppContainer
import com.nexus.device.monitoring.TempReader
import com.nexus.device.monitoring.Temps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong

sealed interface Msg {
    data object Ok : Msg
    data object NeedsAccess : Msg
    data object NeedsRoot : Msg
    data class Err(val text: String) : Msg
}

class ControlViewModel(private val c: AppContainer) : ViewModel() {
    data class Ui(
        val cpu: List<CpuPolicy> = emptyList(),
        val gpu: GpuState? = null,
        val display: DisplayState? = null,
        val tweaks: Tweaks? = null,
        val loads: List<Int> = emptyList(),
        val temps: Temps? = null,
        val loaded: Boolean = false,
    )

    val access = Privileged.state
    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    private val _events = MutableSharedFlow<Msg>(extraBufferCapacity = 8)
    val events: SharedFlow<Msg> = _events.asSharedFlow()
    private var loop: Job? = null

    /** Live values refresh only while the Control screen is visible. */
    fun startLive() {
        if (loop != null) return
        loop = viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                val cpu = ControlRepo.cpuPolicies()
                val gpu = ControlRepo.gpu()
                val loads = ControlRepo.coreLoads()
                val temps = TempReader.read(c.context)
                _ui.update { it.copy(cpu = cpu, gpu = gpu, loads = loads, temps = temps, loaded = true) }
                delay(1300)
            }
        }
    }

    /** Display and tweak values change only when the user changes them, so they are read on demand. */
    fun refreshStatic() { viewModelScope.launch(Dispatchers.Default) { reloadStatic() } }

    fun stopLive() { loop?.cancel(); loop = null }

    private suspend fun reloadStatic() {
        val d = ControlRepo.display(c.context)
        val t = ControlRepo.tweaks()
        _ui.update { it.copy(display = d, tweaks = t) }
    }

    fun requestShizuku() = Privileged.requestShizuku()
    fun refreshAccess() = Privileged.refreshShizuku()
    fun checkRoot() { viewModelScope.launch { Privileged.checkRoot() } }

    private fun gate(needsRoot: Boolean): Msg? {
        val s = Privileged.state.value
        return when {
            s.mode == AccessMode.NONE -> Msg.NeedsAccess
            needsRoot && !s.rootAvailable -> Msg.NeedsRoot
            else -> null
        }
    }

    private fun report(r: ShellResult) {
        _events.tryEmit(
            when {
                r.err == "NEEDS_ROOT" -> Msg.NeedsRoot
                r.ok -> Msg.Ok
                else -> Msg.Err((r.err.ifBlank { r.out }).ifBlank { "failed" })
            },
        )
    }

    private fun run(needsRoot: Boolean, block: suspend () -> ShellResult) {
        gate(needsRoot)?.let { _events.tryEmit(it); return }
        viewModelScope.launch(Dispatchers.Default) {
            report(block())
            reloadStatic()
        }
    }

    fun setDensity(dpi: Int?) = run(false) { ControlRepo.setDensity(dpi) }
    fun setSize(size: String?) = run(false) { ControlRepo.setSize(size) }
    fun setRefresh(hz: Int?) = run(false) { ControlRepo.setRefresh(hz) }
    fun setAnim(scale: Float) = run(false) { ControlRepo.setAnimScale(scale) }
    fun setStayAwake(v: Boolean) = run(false) { ControlRepo.setStayAwake(v) }
    fun setShowTouches(v: Boolean) = run(false) { ControlRepo.setShowTouches(v) }
    fun setPointer(v: Boolean) = run(false) { ControlRepo.setPointer(v) }

    fun setCpu(p: CpuPolicy, governor: String?, minKHz: Long?, maxKHz: Long?) {
        gate(true)?.let { _events.tryEmit(it); return }
        viewModelScope.launch(Dispatchers.Default) {
            val r = ControlRepo.setCpu(p, governor, minKHz, maxKHz)
            // The kernel or the vendor may silently refuse a value, so read it back.
            val now = ControlRepo.cpuPolicies().firstOrNull { it.id == p.id }
            val refused = now != null && (
                (governor != null && now.governor != governor) ||
                    (maxKHz != null && now.maxKHz != maxKHz) ||
                    (minKHz != null && now.minKHz != minKHz)
                )
            if (r.ok && refused) _events.tryEmit(Msg.Err("The system did not keep the value (vendor control)")) else report(r)
            now?.let { n -> _ui.update { u -> u.copy(cpu = u.cpu.map { if (it.id == n.id) n else it }) } }
        }
    }

    fun setGpu(governor: String?, maxHz: Long?) {
        gate(true)?.let { _events.tryEmit(it); return }
        viewModelScope.launch(Dispatchers.Default) { report(ControlRepo.setGpu(governor, maxHz)) }
    }

    override fun onCleared() { stopLive() }
}

/** All-core load test with a performance graph. Runs until stopped, or until the battery gets too hot. */
class ThrottleViewModel(private val c: AppContainer) : ViewModel() {
    data class Ui(
        val running: Boolean = false,
        val seconds: Int = 0,
        val perf: List<Float> = emptyList(),
        val battery: List<Float> = emptyList(),
        val cpu: List<Float> = emptyList(),
        val stoppedHot: Float? = null,
    ) {
        /** Speed lost since the first seconds, in percent. Needs at least 10 samples. */
        val dropPercent: Float?
            get() {
                if (perf.size < 10) return null
                val base = perf.take(5).average()
                val now = perf.takeLast(5).average()
                return if (base <= 0) null else ((1 - now / base) * 100).toFloat().coerceAtLeast(0f)
            }
    }

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    private var job: Job? = null
    @Volatile private var go = false
    private val workers = ArrayList<Thread>()
    private val counter = AtomicLong(0)
    @Volatile private var sink = 0.0

    fun start() {
        if (job != null) return
        _ui.value = Ui(running = true)
        go = true
        counter.set(0)
        repeat(Runtime.getRuntime().availableProcessors()) {
            workers += Thread {
                var x = 1.0001
                while (go) {
                    for (i in 0 until 20_000) { x = x * 1.0000001 + 0.0000003; if (x > 1e6) x = 1.0001 }
                    counter.addAndGet(20_000)
                    sink = x
                }
            }.apply { isDaemon = true; priority = Thread.NORM_PRIORITY; start() }
        }
        job = viewModelScope.launch(Dispatchers.Default) {
            val limit = c.settings.settings.first().stopTempC.toFloat()
            var hot: Float? = null
            while (isActive && go) {
                delay(1000)
                val ops = counter.getAndSet(0) / 1_000_000f
                val t = TempReader.read(c.context)
                _ui.update {
                    it.copy(
                        seconds = it.seconds + 1,
                        perf = (it.perf + ops).takeLast(300),
                        battery = t.batteryC?.let { b -> (it.battery + b).takeLast(300) } ?: it.battery,
                        cpu = t.cpuC?.let { v -> (it.cpu + v).takeLast(300) } ?: it.cpu,
                    )
                }
                if ((t.batteryC ?: 0f) >= limit) { hot = t.batteryC; break }
            }
            halt()
            _ui.update { it.copy(running = false, stoppedHot = hot) }
            job = null
        }
    }

    private fun halt() {
        go = false
        workers.forEach { runCatching { it.join(300) } }
        workers.clear()
    }

    fun stop() { go = false }

    override fun onCleared() { go = false; job?.cancel() }
}
