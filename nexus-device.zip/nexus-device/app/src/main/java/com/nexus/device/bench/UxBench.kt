package com.nexus.device.bench

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import org.json.JSONArray
import org.json.JSONObject

/** The parts of the "everyday use" group that do not need a screen. The smoothness test lives in the UI. */
object UxBench {
    /** Builds, writes and parses a JSON document of 1500 objects; returns MB/s of text handled. */
    fun json(): Double {
        var mb = 0.0
        val runs = CpuBench.rate(2200) {
            val arr = JSONArray()
            for (i in 0 until 1500) {
                arr.put(
                    JSONObject().put("id", i).put("name", "item-$i").put("score", i * 0.37)
                        .put("tags", JSONArray().put("a").put("b$i")).put("ok", i % 2 == 0),
                )
            }
            val text = arr.toString()
            val back = JSONArray(text)
            CpuBench.sink += (back.length() + text.length).toLong()
            mb = text.length / 1048576.0
        }
        return runs * mb
    }

    /** Blurs a 1024 x 1024 picture on the CPU and redraws it with a colour filter; returns megapixels per second. */
    fun image(): Double {
        val w = 1024
        val h = 1024
        val src = IntArray(w * h) { (0xFF000000L or ((it * 7).toLong() and 0xFFFFFFL)).toInt() }
        val dst = IntArray(w * h)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0.3f) }) }
        val runs = CpuBench.rate(2200) {
            blur(src, dst, w, h)
            bmp.setPixels(dst, 0, w, 0, 0, w, h)
            canvas.drawBitmap(bmp, 0f, 0f, paint)
        }
        bmp.recycle()
        out.recycle()
        return runs * (w * h) / 1e6
    }

    private fun blur(s: IntArray, d: IntArray, w: Int, h: Int) {
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                var r = 0
                var g = 0
                var b = 0
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        val p = s[(y + dy) * w + x + dx]
                        r += (p shr 16) and 0xFF
                        g += (p shr 8) and 0xFF
                        b += p and 0xFF
                    }
                }
                d[y * w + x] = (0xFF shl 24) or ((r / 9) shl 16) or ((g / 9) shl 8) or (b / 9)
            }
        }
    }
}
