package com.nexus.device.presentation.hwcheck

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.nativeKeyCode
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.nexus.device.R
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.cardSurface
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.device.DetailHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin

private enum class Test(val title: Int, val desc: Int, val icon: ImageVector) {
    DISPLAY(R.string.hw_display, R.string.hw_display_d, Icons.Filled.PhoneAndroid),
    TOUCH(R.string.hw_touch, R.string.hw_touch_d, Icons.Filled.TouchApp),
    SOUND(R.string.hw_sound, R.string.hw_sound_d, Icons.Filled.VolumeUp),
    VIBRATION(R.string.hw_vibration, R.string.hw_vibration_d, Icons.Filled.Vibration),
    FLASH(R.string.hw_flash, R.string.hw_flash_d, Icons.Filled.FlashlightOn),
    KEYS(R.string.hw_keys, R.string.hw_keys_d, Icons.Filled.Keyboard),
    CAMERA(R.string.hw_camera, R.string.hw_camera_d, Icons.Filled.CameraAlt),
    SENSORS(R.string.hw_sensors, R.string.hw_sensors_d, Icons.Filled.Sensors),
}

/** A menu of hands-on hardware checks. Every test uses a real system service; nothing here is simulated. */
@Composable
fun HwCheckScreen(onBack: () -> Unit, onSensors: () -> Unit, modifier: Modifier = Modifier) {
    var active by rememberSaveable { mutableStateOf<String?>(null) }
    val test = Test.entries.firstOrNull { it.name == active }
    BackHandler(enabled = test != null) { active = null }

    when (test) {
        null -> LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            item { DetailHeader(stringResource(R.string.hw_title), onBack) }
            val all = Test.entries
            items(all.size) { i ->
                val t = all[i]
                ItemRow(
                    stringResource(t.title), stringResource(t.desc), icon = t.icon, shape = groupShape(i, all.size),
                    onClick = { if (t == Test.SENSORS) onSensors() else active = t.name }, chevron = true,
                )
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
        Test.DISPLAY -> DisplayTest { active = null }
        Test.TOUCH -> TouchTest { active = null }
        Test.SOUND -> Panel(R.string.hw_sound, modifier) { SoundTest() }
        Test.VIBRATION -> Panel(R.string.hw_vibration, modifier) { VibrationTest() }
        Test.FLASH -> Panel(R.string.hw_flash, modifier) { FlashTest() }
        Test.KEYS -> Panel(R.string.hw_keys, modifier) { KeysTest() }
        Test.CAMERA -> Panel(R.string.hw_camera, modifier) { CameraTest() }
        Test.SENSORS -> {}
    }
}

@Composable
private fun Panel(title: Int, modifier: Modifier, content: @Composable () -> Unit) {
    Column(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DetailHeader(stringResource(title), {})
        content()
    }
}

// ---- display: solid colours and a gradient, tap to move on ----

@Composable
private fun DisplayTest(onExit: () -> Unit) {
    val steps = listOf(Color.Black, Color.White, Color.Red, Color(0xFF00FF00), Color.Blue, Color(0xFF808080), Color.Transparent)
    var i by remember { mutableIntStateOf(0) }
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    val modifier = Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
        if (i + 1 >= steps.size) onExit() else i++
    }
    Box(modifier.then(if (steps[i] == Color.Transparent) Modifier.background(Brush.horizontalGradient(listOf(Color.Black, Color.White))) else Modifier.background(steps[i]))) {
        if (i == 0) Text(
            stringResource(R.string.hw_display_hint), color = Color.Gray, style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.align(Alignment.Center).padding(32.dp),
        )
    }
}

// ---- touch: draws every finger, counts the most fingers seen at once ----

@Composable
private fun TouchTest(onExit: () -> Unit) {
    val points: SnapshotStateList<Offset> = remember { mutableStateListOf() }
    var fingers by remember { mutableIntStateOf(0) }
    var most by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Canvas(
            Modifier.fillMaxSize().pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val e = awaitPointerEvent()
                        val down = e.changes.filter { it.pressed }
                        fingers = down.size
                        if (down.size > most) most = down.size
                        down.forEach { c -> if (points.size < 2500) points.add(c.position) }
                        e.changes.forEach { it.consume() }
                    } while (e.changes.any { it.pressed })
                    fingers = 0
                }
            },
        ) {
            val dot = Color(0xFF8FA8FF)
            points.forEach { drawCircle(dot, 14f, it) }
        }
        Column(Modifier.statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.hw_touch_max, fingers, most), color = Color.White, style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { points.clear(); most = 0 }) { Text(stringResource(R.string.hw_reset)) }
                Button(onClick = onExit) { Text(stringResource(R.string.close)) }
            }
        }
    }
}

// ---- sound: a real 1 kHz tone through the media stream ----

@Composable
private fun SoundTest() {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    fun play(l: Boolean, r: Boolean) {
        if (busy) return
        busy = true
        scope.launch { withContext(Dispatchers.IO) { runCatching { tone(l, r) } }; busy = false }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { play(true, false) }, enabled = !busy) { Text(stringResource(R.string.hw_left)) }
        Button(onClick = { play(true, true) }, enabled = !busy) { Text(stringResource(R.string.hw_both)) }
        Button(onClick = { play(false, true) }, enabled = !busy) { Text(stringResource(R.string.hw_right)) }
    }
    Note(R.string.hw_sound_note)
}

private suspend fun tone(left: Boolean, right: Boolean) {
    val sr = 44100
    val n = sr
    val buf = ShortArray(n * 2)
    for (i in 0 until n) {
        val fade = minOf(1f, i / 2000f, (n - i) / 2000f)
        val v = (sin(2.0 * PI * 1000.0 * i / sr) * 0.35 * Short.MAX_VALUE * fade).toInt().toShort()
        buf[2 * i] = if (left) v else 0
        buf[2 * i + 1] = if (right) v else 0
    }
    val track = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
        .setBufferSizeInBytes(buf.size * 2)
        .setTransferMode(AudioTrack.MODE_STATIC)
        .build()
    try {
        track.write(buf, 0, buf.size)
        track.play()
        delay(1150)
    } finally {
        runCatching { track.release() }
    }
}

// ---- vibration ----

@Composable
private fun VibrationTest() {
    val ctx = LocalContext.current
    val vib: Vibrator? = remember {
        if (Build.VERSION.SDK_INT >= 31) (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        else @Suppress("DEPRECATION") ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
    if (vib == null || !vib.hasVibrator()) { Note(R.string.hw_vib_none); return }
    val amp = Build.VERSION.SDK_INT >= 26 && vib.hasAmplitudeControl()
    Button(onClick = { runCatching { vib.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE)) } }) { Text(stringResource(R.string.hw_vib_run)) }
    OutlinedButton(onClick = { runCatching { vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 120, 100, 120, 100, 400), -1)) } }) { Text(stringResource(R.string.hw_vib_pattern)) }
    Note(if (amp) R.string.hw_vib_amp_yes else R.string.hw_vib_amp_no)
}

// ---- flashlight ----

@Composable
private fun FlashTest() {
    val ctx = LocalContext.current
    val cm = remember { ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    val id = remember { runCatching { cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } }.getOrNull() }
    var on by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { id?.let { runCatching { cm.setTorchMode(it, false) } } } }
    if (id == null) { Note(R.string.hw_flash_none); return }
    Row(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(20.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(stringResource(R.string.hw_flash_on), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = on, onCheckedChange = { v -> if (runCatching { cm.setTorchMode(id, v) }.isSuccess) on = v })
    }
}

// ---- hardware keys ----

@Composable
private fun KeysTest() {
    val seen = remember { mutableStateListOf<Int>() }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Column(
        Modifier.fillMaxWidth().focusRequester(focus).focusable().onPreviewKeyEvent { e ->
            val code = e.key.nativeKeyCode
            val volume = code == android.view.KeyEvent.KEYCODE_VOLUME_UP || code == android.view.KeyEvent.KEYCODE_VOLUME_DOWN
            if (volume && e.type == KeyEventType.KeyDown && code !in seen) seen.add(code)
            volume
        },
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Note(R.string.hw_press_keys)
        listOf(android.view.KeyEvent.KEYCODE_VOLUME_UP to "Volume +", android.view.KeyEvent.KEYCODE_VOLUME_DOWN to "Volume −").forEach { (code, name) ->
            val ok = code in seen
            Row(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(20.dp)).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, style = MaterialTheme.typography.bodyLarge)
                Text(if (ok) "✓" else "—", style = MaterialTheme.typography.titleMedium, color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ---- camera: hands over to the system camera, so the app needs no camera permission ----

@Composable
private fun CameraTest() {
    val ctx = LocalContext.current
    Button(onClick = { runCatching { ctx.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) {
        Text(stringResource(R.string.hw_open_camera))
    }
}

@Composable
private fun Note(res: Int) {
    Text(stringResource(res), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}
