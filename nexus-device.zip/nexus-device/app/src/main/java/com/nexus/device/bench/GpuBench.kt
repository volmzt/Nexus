package com.nexus.device.bench

import android.opengl.EGL14
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

data class GpuMeasure(val aluFps: Double, val fillGpix: Double, val geometryMtri: Double, val renderer: String)

/**
 * Three OpenGL ES 3.0 tests drawn into an off-screen 1280 x 720 buffer, so the display's refresh rate does not cap the result:
 * heavy shader maths, texture reads with blending (fill rate) and a large number of small triangles.
 */
object GpuBench {
    private const val W = 1280
    private const val H = 720

    private const val FULLSCREEN_VS = """#version 300 es
out vec2 uv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    uv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}"""

    private const val ALU_FS = """#version 300 es
precision highp float;
in vec2 uv;
out vec4 o;
uniform float t;
void main() {
    vec2 c = (uv - 0.5) * 3.0 + vec2(-0.5, 0.0);
    vec2 z = vec2(0.0);
    float n = 0.0;
    for (int i = 0; i < 160; i++) {
        z = vec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y) + c + vec2(sin(t) * 0.01, 0.0);
        if (dot(z, z) > 16.0) break;
        n += 1.0;
    }
    o = vec4(vec3(n / 160.0), 1.0);
}"""

    private const val FILL_FS = """#version 300 es
precision mediump float;
in vec2 uv;
out vec4 o;
uniform sampler2D tex;
uniform float t;
void main() {
    vec2 p = uv * 3.0 + vec2(t * 0.01, 0.0);
    vec4 a = texture(tex, p) + texture(tex, p * 1.7 + 0.3) + texture(tex, p * 2.9 + 0.7) + texture(tex, p * 4.1 + 0.1);
    o = vec4(a.rgb * 0.25, 0.35);
}"""

    private const val GEO_VS = """#version 300 es
uniform float t;
out vec3 col;
void main() {
    int tri = gl_VertexID / 3;
    int corner = gl_VertexID - tri * 3;
    float id = float(gl_InstanceID);
    float a = id * 0.37 + float(tri) * 0.11 + t;
    vec2 center = vec2(sin(a * 1.3), cos(a * 0.9)) * 0.9;
    float ox = corner == 0 ? -1.0 : (corner == 1 ? 1.0 : 0.0);
    float oy = corner == 2 ? 1.0 : -1.0;
    gl_Position = vec4(center + vec2(ox, oy) * 0.02, 0.0, 1.0);
    col = vec3(fract(id * 0.07), fract(float(tri) * 0.13), 0.5);
}"""

    private const val GEO_FS = """#version 300 es
precision mediump float;
in vec3 col;
out vec4 o;
void main() { o = vec4(col, 1.0); }"""

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) error("shader: " + GLES30.glGetShaderInfoLog(s))
        return s
    }

    private fun program(vs: String, fs: String): Int {
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, compile(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(p, compile(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) error("link: " + GLES30.glGetProgramInfoLog(p))
        return p
    }

    /** Shows the off-screen picture on the real screen; set while a test runs, null otherwise. */
    private var present: (() -> Unit)? = null

    /** Runs [draw] in batches for [budgetMs]; returns the number of draws and the seconds they took. */
    private fun timed(budgetMs: Long, batch: Int, draw: () -> Unit): Pair<Long, Double> {
        repeat(2) { draw() }
        GLES30.glFinish()
        var n = 0L
        val start = System.nanoTime()
        val end = start + budgetMs * 1_000_000L
        var now = start
        var shown = start
        while (now < end) {
            for (k in 0 until batch) draw()
            GLES30.glFinish()
            n += batch
            now = System.nanoTime()
            // About 30 pictures a second are enough to watch the test without disturbing the measurement.
            if (now - shown > 33_000_000L) { present?.invoke(); shown = System.nanoTime() }
        }
        return n to (now - start) / 1e9
    }

    /** Must be called on the GL thread with a current ES 3.0 context. */
    fun run(screenW: Int, screenH: Int): GpuMeasure {
        val version = GLES30.glGetString(GLES30.GL_VERSION).orEmpty()
        if (!version.startsWith("OpenGL ES 3")) error("OpenGL ES 3.0 is not available ($version)")
        val renderer = GLES30.glGetString(GLES30.GL_RENDERER).orEmpty()

        val tex = IntArray(1)
        val fbo = IntArray(1)
        val noise = IntArray(1)
        GLES30.glGenTextures(1, tex, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[0])
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, W, H, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glGenFramebuffers(1, fbo, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[0])
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, tex[0], 0)
        if (GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER) != GLES30.GL_FRAMEBUFFER_COMPLETE) error("off-screen buffer is incomplete")
        GLES30.glViewport(0, 0, W, H)

        val display = EGL14.eglGetCurrentDisplay()
        val surface = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW)
        if (screenW > 0 && screenH > 0 && surface != EGL14.EGL_NO_SURFACE) {
            EGL14.eglSwapInterval(display, 0)
            present = {
                GLES30.glBindFramebuffer(GLES30.GL_READ_FRAMEBUFFER, fbo[0])
                GLES30.glBindFramebuffer(GLES30.GL_DRAW_FRAMEBUFFER, 0)
                GLES30.glBlitFramebuffer(0, 0, W, H, 0, 0, screenW, screenH, GLES30.GL_COLOR_BUFFER_BIT, GLES30.GL_LINEAR)
                EGL14.eglSwapBuffers(display, surface)
                GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo[0])
            }
        }

        val programs = mutableListOf<Int>()
        try {
            // 1. Shader maths
            val alu = program(FULLSCREEN_VS, ALU_FS).also { programs.add(it) }
            GLES30.glUseProgram(alu)
            val aluT = GLES30.glGetUniformLocation(alu, "t")
            var t = 0f
            val (aluN, aluS) = timed(2500, 2) {
                t += 0.01f
                GLES30.glUniform1f(aluT, t)
                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            }

            // 2. Fill rate: four texture reads per pixel, blended over each other
            GLES30.glGenTextures(1, noise, 0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, noise[0])
            val pixels = ByteBuffer.allocateDirect(256 * 256 * 4).order(ByteOrder.nativeOrder())
            var x = 1
            for (k in 0 until 256 * 256 * 4) {
                x = x * 1664525 + 1013904223
                pixels.put((x ushr 24).toByte())
            }
            pixels.position(0)
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, 256, 256, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, pixels)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
            GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
            val fill = program(FULLSCREEN_VS, FILL_FS).also { programs.add(it) }
            GLES30.glUseProgram(fill)
            GLES30.glUniform1i(GLES30.glGetUniformLocation(fill, "tex"), 0)
            val fillT = GLES30.glGetUniformLocation(fill, "t")
            GLES30.glEnable(GLES30.GL_BLEND)
            GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
            t = 0f
            val (fillN, fillS) = timed(2500, 8) {
                t += 0.01f
                GLES30.glUniform1f(fillT, t)
                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
            }
            GLES30.glDisable(GLES30.GL_BLEND)

            // 3. Geometry: 400 instances of 500 small triangles = 200 000 triangles per call
            val geo = program(GEO_VS, GEO_FS).also { programs.add(it) }
            GLES30.glUseProgram(geo)
            val geoT = GLES30.glGetUniformLocation(geo, "t")
            t = 0f
            val (geoN, geoS) = timed(2500, 2) {
                t += 0.01f
                GLES30.glUniform1f(geoT, t)
                GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, 1500, 400)
            }

            return GpuMeasure(
                aluFps = aluN / aluS,
                fillGpix = fillN.toDouble() * W * H / 1e9 / fillS,
                geometryMtri = geoN * 200_000.0 / 1e6 / geoS,
                renderer = renderer,
            )
        } finally {
            present = null
            programs.forEach { GLES30.glDeleteProgram(it) }
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glDeleteFramebuffers(1, fbo, 0)
            GLES30.glDeleteTextures(1, tex, 0)
            if (noise[0] != 0) GLES30.glDeleteTextures(1, noise, 0)
        }
    }
}

/** Runs [GpuBench] once, on the first frame of a GLSurfaceView, and reports the result or the reason it failed. */
class GpuBenchRenderer(private val onDone: (GpuMeasure?, String?) -> Unit) : GLSurfaceView.Renderer {
    private var started = false
    private var width = 0
    private var height = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {}

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        this.width = width
        this.height = height
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClearColor(0f, 0f, 0f, 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        if (started) return
        started = true
        try {
            onDone(GpuBench.run(width, height), null)
        } catch (t: Throwable) {
            onDone(null, t.message ?: t.javaClass.simpleName)
        }
    }
}
