package com.nexus.device.presentation.battery

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.nexus.device.presentation.components.cardSurface
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.nexus.device.R
import com.nexus.device.core.Availability
import com.nexus.device.core.Fmt
import com.nexus.device.core.Spec
import com.nexus.device.core.TempUnit
import com.nexus.device.core.di.AppContainer
import com.nexus.device.database.BatterySampleEntity
import com.nexus.device.presentation.SpecGroup
import com.nexus.device.presentation.components.LineChart
import com.nexus.device.presentation.device.DetailHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn

/** What the battery reports right now. Anything the phone does not report stays null. */
data class BatteryLive(
    val health: String?,
    val cycles: Int?,
    val voltageV: Float?,
    val capacityMah: Int?,
    val tempC: Float?,
)

class BatteryHealthViewModel(private val c: AppContainer) : ViewModel() {
    val history: StateFlow<List<BatterySampleEntity>> =
        c.database.batteryDao().observeSince(System.currentTimeMillis() - 24L * 3600 * 1000)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val live: StateFlow<BatteryLive?> = flow {
        while (true) { emit(read(c.context)); delay(5000) }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private fun read(ctx: Context): BatteryLive {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        val t = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val v = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        return BatteryLive(
            health = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
                BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
                else -> null
            },
            cycles = i?.getIntExtra("android.os.extra.CYCLE_COUNT", -1)?.takeIf { it > 0 },
            voltageV = v.takeIf { it > 0 }?.let { it / 1000f },
            // Charge counter divided by level: only meaningful between 5 and 100 percent.
            capacityMah = if (counter > 0 && level in 5..100) (counter * 100 / level / 1000).toInt() else null,
            tempC = if (t == Int.MIN_VALUE || t <= 0) null else t / 10f,
        )
    }
}

@Composable
fun BatteryHealthScreen(vm: BatteryHealthViewModel, unit: TempUnit, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val live by vm.live.collectAsStateWithLifecycle()
    val hist by vm.history.collectAsStateWithLifecycle()
    val na = "—"
    val specs = listOf(
        live?.health.let { Spec("Health", it ?: na, if (it == null) Availability.UNAVAILABLE else Availability.AVAILABLE) },
        live?.cycles.let { Spec("Charge cycles", it?.toString() ?: na, if (it == null) Availability.UNAVAILABLE else Availability.AVAILABLE) },
        live?.capacityMah.let { Spec("Estimated full capacity", it?.let { v -> "$v mAh" } ?: na, if (it == null) Availability.UNAVAILABLE else Availability.APPROXIMATE) },
        live?.voltageV.let { Spec("Voltage", it?.let { v -> Fmt.one(v.toDouble()) + " V" } ?: na, if (it == null) Availability.UNAVAILABLE else Availability.AVAILABLE) },
        live?.tempC.let { Spec("Temperature", it?.let { v -> Fmt.temp(v, unit) } ?: na, if (it == null) Availability.UNAVAILABLE else Availability.AVAILABLE) },
    )
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { DetailHeader(stringResource(R.string.bh_title), onBack) }
        item { SpecGroup(specs) }
        item {
            Column(
                Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(stringResource(R.string.bh_hist_title), style = MaterialTheme.typography.titleMedium)
                if (hist.size < 3) {
                    Text(stringResource(R.string.bh_no_data), color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text(stringResource(R.string.bh_level), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LineChart(listOf(hist.map { it.level.toFloat() }), Modifier.fillMaxWidth().height(90.dp), maxPoints = hist.size.coerceAtLeast(60))
                    val temps = hist.mapNotNull { it.tempC }
                    if (temps.size >= 3) {
                        Text(stringResource(R.string.bh_temp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        LineChart(listOf(temps.map { Fmt.tempValue(it, unit) }), Modifier.fillMaxWidth().height(90.dp), maxPoints = temps.size.coerceAtLeast(60))
                        Text(stringResource(R.string.bh_max_temp, Fmt.temp(temps.max(), unit)), style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Text(stringResource(R.string.bh_hist_note), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { Text(stringResource(R.string.bh_note), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 8.dp)) }
        item { Spacer(Modifier.height(40.dp)) }
    }
}
