package com.nexus.device.hardware

import java.io.File

/**
 * Reads thermal zones from sysfs. Many phones block these files for normal apps (SELinux);
 * then every function returns null / empty and the UI says the value is not provided.
 */
object ThermalReader {
    data class Zone(val name: String, val tempC: Float)

    private val cpuNames = Regex("cpu|soc|tsens|mtktscpu|cpuss|big|little|apc|ap_|cluster|core", RegexOption.IGNORE_CASE)

    fun zones(): List<Zone> {
        val base = File("/sys/class/thermal")
        val dirs = runCatching { base.listFiles { f -> f.name.startsWith("thermal_zone") }?.sortedBy { it.name.removePrefix("thermal_zone").toIntOrNull() ?: 0 } }
            .getOrNull().orEmpty()
        return dirs.mapNotNull { d ->
            runCatching {
                val type = File(d, "type").readText().trim()
                val raw = File(d, "temp").readText().trim().toFloat()
                val c = if (raw > 1000f || raw < -1000f) raw / 1000f else raw
                if (c in 5f..130f) Zone(type, c) else null
            }.getOrNull()
        }
    }

    /** Hottest zone whose name looks like a CPU/SoC sensor, or null if none is readable. */
    fun cpuTempC(): Float? = zones().filter { cpuNames.containsMatchIn(it.name) }.maxOfOrNull { it.tempC }
}
