package com.nexus.device.hardware

import java.io.File

/**
 * Thermal zones from sysfs. Many phones block these files for normal apps (SELinux).
 * When the app has Shizuku or root, [TempReader] reads the same files through the shell.
 */
object ThermalReader {
    data class Zone(val name: String, val tempC: Float)

    private val cpuNames = Regex("cpu|soc|tsens|mtktscpu|cpuss|big|little|apc|cluster|core|gpuss|nsp", RegexOption.IGNORE_CASE)

    /** One shell command that prints "type temp" for every zone. */
    const val DUMP_CMD = "for z in /sys/class/thermal/thermal_zone*; do echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done"

    /** Parses lines of "name value" where value is in millidegrees or degrees. */
    fun parse(text: String): List<Zone> = text.lines().mapNotNull { line ->
        val t = line.trim()
        val i = t.lastIndexOf(' ')
        if (i <= 0) return@mapNotNull null
        val raw = t.substring(i + 1).toFloatOrNull() ?: return@mapNotNull null
        val c = if (raw > 1000f || raw < -1000f) raw / 1000f else raw
        if (c in 5f..130f) Zone(t.substring(0, i).trim(), c) else null
    }

    /** Direct read, no extra rights. Empty when Android hides the files. */
    fun zones(): List<Zone> {
        val dirs = runCatching { File("/sys/class/thermal").listFiles { f -> f.name.startsWith("thermal_zone") }?.toList() }.getOrNull().orEmpty()
        val lines = dirs.mapNotNull { d ->
            runCatching { File(d, "type").readText().trim() + " " + File(d, "temp").readText().trim() }.getOrNull()
        }
        return parse(lines.joinToString("\n"))
    }

    private val coreSensor = Regex("^cpu-?\\d+(-\\d+)?(-usr|-lowf)?$", RegexOption.IGNORE_CASE)

    /**
     * One steady CPU figure. Individual core sensors jump by several degrees from moment to moment,
     * so the value is the average of the core sensors (or, failing that, of the CPU-like sensors),
     * not the hottest single one.
     */
    fun cpuOf(zones: List<Zone>): Float? {
        val cores = zones.filter { coreSensor.containsMatchIn(it.name) }
        val pick = cores.ifEmpty { zones.filter { cpuNames.containsMatchIn(it.name) } }
        return if (pick.isEmpty()) null else pick.map { it.tempC }.average().toFloat()
    }

    /** Exponential moving average used for display, so a spike on one sensor does not look like a real change. */
    class Smoother(private val alpha: Float = 0.3f) {
        private var value: Float? = null
        fun push(v: Float?): Float? {
            if (v == null) return value
            val prev = value
            val next = if (prev == null || kotlin.math.abs(v - prev) > 8f) v else prev + alpha * (v - prev)
            value = next
            return next
        }
    }

    fun cpuTempC(): Float? = cpuOf(zones())
}
