@file:Suppress("DEPRECATION")

package com.nexus.device.hardware

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaCodecList
import android.os.Build
import com.nexus.device.core.Availability
import com.nexus.device.core.Spec
import com.nexus.device.core.spec
import com.nexus.device.domain.Category
import com.nexus.device.domain.SpecProvider
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import java.util.Locale

class SensorsProvider(private val context: Context) : SpecProvider {
    override val category = Category.SENSORS

    override fun read(): List<Spec> {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val list = sm.getSensorList(Sensor.TYPE_ALL)
        if (list.isEmpty()) return listOf(Spec("Sensors", "No sensors visible to apps on this device", Availability.UNAVAILABLE))
        return list.map { s ->
            Spec(s.name, describe(s))
        }
    }

    companion object {
        fun describe(s: Sensor): String {
            val rate = if (s.minDelay > 0) String.format(Locale.US, "%.0f Hz max", 1_000_000.0 / s.minDelay) else if (s.minDelay == 0) "on change" else "one-shot"
            return "${s.vendor} · ${s.stringType.substringAfterLast('.')} · v${s.version} · range ${s.maximumRange} · resolution ${s.resolution} · ${s.power} mA · $rate"
        }

        fun events(sm: SensorManager, sensor: Sensor): Flow<FloatArray> = callbackFlow {
            val l = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) { trySend(e.values.clone()) }
                override fun onAccuracyChanged(s: Sensor?, a: Int) {}
            }
            sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_UI)
            awaitClose { sm.unregisterListener(l) }
        }.conflate()
    }
}

class CameraProvider(private val context: Context) : SpecProvider {
    override val category = Category.CAMERA

    override fun read(): List<Spec> {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val ids = try { cm.cameraIdList.toList() } catch (e: Exception) { emptyList() }
        if (ids.isEmpty()) return listOf(Spec("Cameras", "No cameras visible to apps", Availability.UNAVAILABLE))
        val out = mutableListOf<Spec>()
        for (id in ids) {
            val c = try { cm.getCameraCharacteristics(id) } catch (e: Exception) {
                out += Spec("Camera $id", "Cannot read characteristics", Availability.UNAVAILABLE); continue
            }
            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            out += Spec("Camera $id · facing", when (c.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_FRONT -> "Front"
                CameraCharacteristics.LENS_FACING_BACK -> "Back"
                CameraCharacteristics.LENS_FACING_EXTERNAL -> "External"
                else -> "Unknown"
            })
            out += spec("Camera $id · max resolution") {
                map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width.toLong() * it.height }?.let { s ->
                    "${s.width} × ${s.height} (${String.format(Locale.US, "%.1f", s.width.toLong() * s.height / 1e6)} MP)"
                }
            }
            out += spec("Camera $id · JPEG sizes") { map?.getOutputSizes(ImageFormat.JPEG)?.sortedByDescending { it.width.toLong() * it.height }?.take(8)?.joinToString { "${it.width}×${it.height}" } }
            out += spec("Camera $id · FPS ranges") { c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.joinToString { "${it.lower}–${it.upper}" } }
            out += spec("Camera $id · focal length") { c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString { "$it mm" } }
            out += spec("Camera $id · ISO range") { c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let { "${it.lower}–${it.upper}" } }
            out += spec("Camera $id · exposure range") { c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let { "${it.lower / 1000} µs – ${it.upper / 1_000_000} ms" } }
            out += spec("Camera $id · autofocus modes") {
                c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)?.joinToString { m ->
                    when (m) {
                        0 -> "off"
                        1 -> "auto"
                        2 -> "macro"
                        3 -> "continuous video"
                        4 -> "continuous picture"
                        5 -> "EDOF"
                        else -> "mode $m"
                    }
                }
            }
            out += spec("Camera $id · flash") { c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)?.let { if (it) "Yes" else "No" } }
            out += spec("Camera $id · output formats") { map?.outputFormats?.joinToString { formatName(it) } }
        }
        return out
    }

    private fun formatName(f: Int): String = when (f) {
        ImageFormat.JPEG -> "JPEG"
        ImageFormat.YUV_420_888 -> "YUV_420_888"
        ImageFormat.RAW_SENSOR -> "RAW_SENSOR"
        ImageFormat.PRIVATE -> "PRIVATE"
        0x48454946 -> "HEIC"
        ImageFormat.NV21 -> "NV21"
        else -> "0x" + Integer.toHexString(f)
    }
}

class CodecsProvider : SpecProvider {
    override val category = Category.CODECS

    override fun read(): List<Spec> = CodecRepository.load().map { c ->
        Spec(c.name, "${if (c.encoder) "Encoder" else "Decoder"} · ${if (c.video) "video" else "audio"} · ${c.types.joinToString()}")
    }
}

data class CodecItem(
    val name: String,
    val encoder: Boolean,
    val video: Boolean,
    val types: List<String>,
    val vendor: String,
    val details: List<String>,
)

object CodecRepository {
    fun load(): List<CodecItem> {
        val infos = try { MediaCodecList(MediaCodecList.ALL_CODECS).codecInfos } catch (e: Exception) { return emptyList() }
        return infos.map { info ->
            val details = mutableListOf<String>()
            var video = false
            for (t in info.supportedTypes) {
                if (t.startsWith("video/")) video = true
                try {
                    val caps = info.getCapabilitiesForType(t)
                    caps.videoCapabilities?.let { v ->
                        details += "$t: ${v.supportedWidths.upper}×${v.supportedHeights.upper} px, ${v.supportedFrameRates.lower}–${v.supportedFrameRates.upper} fps"
                    }
                    caps.audioCapabilities?.let { a ->
                        details += "$t: ${a.maxInputChannelCount} ch, ${a.bitrateRange.lower}–${a.bitrateRange.upper} bps"
                    }
                    val pl = caps.profileLevels.take(6).joinToString { "p${it.profile}/l${it.level}" }
                    if (pl.isNotBlank()) details += "$t profiles: $pl"
                } catch (e: Exception) {
                    details += "$t: capabilities unavailable"
                }
            }
            val vendor = if (Build.VERSION.SDK_INT >= 29) {
                if (info.isVendor) "vendor" else if (info.isSoftwareOnly) "software" else "platform"
            } else "unknown"
            val hw = if (Build.VERSION.SDK_INT >= 29) (if (info.isHardwareAccelerated) "hardware" else "software") else null
            CodecItem(info.name, info.isEncoder, video, info.supportedTypes.toList(), listOfNotNull(vendor, hw).joinToString(" · "), details)
        }.sortedBy { it.name }
    }
}

data class AppItem(
    val label: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val installTime: Long,
    val category: String,
    val system: Boolean,
)

object AppsRepository {
    fun load(context: Context): List<AppItem> {
        val pm = context.packageManager
        val infos: List<PackageInfo> = try { pm.getInstalledPackages(0) } catch (e: Exception) { emptyList() }
        return infos.mapNotNull { p ->
            val ai = p.applicationInfo ?: return@mapNotNull null
            AppItem(
                label = ai.loadLabel(pm).toString(),
                packageName = p.packageName,
                versionName = p.versionName ?: "—",
                versionCode = if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong(),
                installTime = p.firstInstallTime,
                category = categoryName(ai.category),
                system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
            )
        }
    }

    private fun categoryName(c: Int): String = when (c) {
        ApplicationInfo.CATEGORY_GAME -> "Game"
        ApplicationInfo.CATEGORY_AUDIO -> "Audio"
        ApplicationInfo.CATEGORY_VIDEO -> "Video"
        ApplicationInfo.CATEGORY_IMAGE -> "Image"
        ApplicationInfo.CATEGORY_SOCIAL -> "Social"
        ApplicationInfo.CATEGORY_NEWS -> "News"
        ApplicationInfo.CATEGORY_MAPS -> "Maps"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
        else -> "Undefined"
    }
}

class AppsProvider(private val context: Context) : SpecProvider {
    override val category = Category.APPS

    override fun read(): List<Spec> {
        val apps = AppsRepository.load(context)
        return listOf(
            Spec("Visible apps", apps.size.toString()),
            Spec("Package visibility", "Android lists only launchable apps for this app; the rest are hidden by the system", Availability.APPROXIMATE),
        )
    }
}

/** Used to check the manifest permission list at runtime in the report; kept tiny on purpose. */
fun Context.hasPermission(p: String): Boolean = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
