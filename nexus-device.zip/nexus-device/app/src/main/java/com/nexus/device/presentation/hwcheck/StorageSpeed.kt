package com.nexus.device.presentation.hwcheck

import android.system.Os
import android.system.OsConstants
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.nexus.device.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Random

/** Writes and reads back a 256 MB file in the app's own cache folder and reports the real speed. Nothing is simulated. */
@Composable
fun StorageSpeedTest() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var write by remember { mutableStateOf<Double?>(null) }
    var read by remember { mutableStateOf<Double?>(null) }
    var failed by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.ss_note), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(
            enabled = !running,
            onClick = {
                scope.launch {
                    running = true; failed = false; write = null; read = null
                    val r = withContext(Dispatchers.IO) { runCatching { measure(ctx.cacheDir) }.getOrNull() }
                    if (r == null) failed = true else { write = r.first; read = r.second }
                    running = false
                }
            },
        ) { Text(stringResource(if (running) R.string.ss_running else R.string.ss_run)) }
        write?.let { Text(stringResource(R.string.ss_write) + ": " + it.toInt() + " MB/s", style = MaterialTheme.typography.headlineSmall) }
        read?.let { Text(stringResource(R.string.ss_read) + ": " + it.toInt() + " MB/s", style = MaterialTheme.typography.headlineSmall) }
        if (failed) Text(stringResource(R.string.ss_failed), color = MaterialTheme.colorScheme.error)
    }
}

private fun measure(dir: File): Pair<Double, Double> {
    val f = File(dir, "speedtest.bin")
    val mb = 256
    val buf = ByteArray(1 shl 20).also { Random(1).nextBytes(it) }
    try {
        val t0 = System.nanoTime()
        FileOutputStream(f).use { o -> repeat(mb) { o.write(buf) }; o.flush(); o.fd.sync() }
        val w = mb / ((System.nanoTime() - t0) / 1e9)
        // Ask the system to forget the file, so the read comes from storage and not from memory.
        runCatching { FileInputStream(f).use { i -> Os.posix_fadvise(i.fd, 0L, 0L, OsConstants.POSIX_FADV_DONTNEED) } }
        val t1 = System.nanoTime()
        FileInputStream(f).use { i -> while (i.read(buf) > 0) { } }
        val r = mb / ((System.nanoTime() - t1) / 1e9)
        return w to r
    } finally { f.delete() }
}
