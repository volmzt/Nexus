package com.nexus.device.presentation.hwcheck

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.nexus.device.R
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.groupShape

/**
 * Screens that exist inside the system but have no button in the menus. Each one is a real activity of this phone:
 * an entry is offered only when the system confirms it is installed here, otherwise it is shown as not found.
 */
private class Hidden(
    val title: Int,
    val desc: Int,
    /** Opened by action (always present on Android) or by component (a vendor screen that may be missing). */
    val action: String? = null,
    val component: ComponentName? = null,
)

private fun c(pkg: String, cls: String) = ComponentName(pkg, cls)

private val Screens = listOf(
    Hidden(R.string.hid_dev, R.string.hid_dev_d, action = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
    Hidden(R.string.hid_about, R.string.hid_about_d, action = Settings.ACTION_DEVICE_INFO_SETTINGS),
    Hidden(R.string.hid_power, R.string.hid_power_d, action = Intent.ACTION_POWER_USAGE_SUMMARY),
    Hidden(R.string.hid_radio, R.string.hid_radio_d, component = c("com.android.phone", "com.android.phone.settings.RadioInfo")),
    Hidden(R.string.hid_testing, R.string.hid_testing_d, component = c("com.android.settings", "com.android.settings.TestingSettings")),
    Hidden(R.string.hid_cit, R.string.hid_cit_d, component = c("com.miui.cit", "com.miui.cit.CitEntryActivity")),
    Hidden(R.string.hid_autostart, R.string.hid_autostart_d, component = c("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
    Hidden(R.string.hid_battery_ui, R.string.hid_battery_ui_d, component = c("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")),
    Hidden(R.string.hid_pm, R.string.hid_pm_d, component = c("com.miui.securitycenter", "com.miui.powercenter.PowerMainActivity")),
)

private fun Context.exists(h: Hidden): Boolean {
    val comp = h.component ?: return true
    return try {
        packageManager.getActivityInfo(comp, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    } catch (_: RuntimeException) {
        false
    }
}

private fun Context.open(h: Hidden) {
    val intent = if (h.component != null) Intent().setComponent(h.component) else Intent(h.action)
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(this, R.string.hid_missing, Toast.LENGTH_SHORT).show()
    } catch (_: SecurityException) {
        // The system keeps some of these for itself.
        Toast.makeText(this, R.string.hid_denied, Toast.LENGTH_SHORT).show()
    }
}

@Composable
internal fun HiddenScreens() {
    val ctx = LocalContext.current
    val found = remember { Screens.map { ctx.exists(it) } }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(stringResource(R.string.hid_note), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        Screens.forEachIndexed { i, h ->
            val ok = found[i]
            ItemRow(
                stringResource(h.title),
                if (ok) stringResource(h.desc) else stringResource(R.string.hid_missing),
                shape = groupShape(i, Screens.size),
                onClick = { if (ok) ctx.open(h) else Toast.makeText(ctx, R.string.hid_missing, Toast.LENGTH_SHORT).show() },
                chevron = ok,
            )
        }
        Spacer(Modifier.height(40.dp))
    }
}
