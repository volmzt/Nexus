package com.nexus.device.core.di

import android.content.Context
import androidx.room.Room
import com.nexus.device.data.SettingsRepository
import com.nexus.device.database.NexusDatabase
import com.nexus.device.diagnostics.BenchmarkRunner
import com.nexus.device.domain.DeviceRepository
import com.nexus.device.domain.SpecProvider
import com.nexus.device.hardware.AppsProvider
import com.nexus.device.hardware.BatteryProvider
import com.nexus.device.hardware.CameraProvider
import com.nexus.device.hardware.CodecsProvider
import com.nexus.device.hardware.CpuProvider
import com.nexus.device.hardware.DisplayProvider
import com.nexus.device.hardware.GpuProvider
import com.nexus.device.hardware.MemoryProvider
import com.nexus.device.hardware.NetworkProvider
import com.nexus.device.hardware.SensorsProvider
import com.nexus.device.hardware.StorageProvider
import com.nexus.device.hardware.SystemProvider
import com.nexus.device.monitoring.SystemSampler

/** Manual dependency injection: one place builds every dependency and hands them to view models by constructor. */
class AppContainer(val context: Context) {
    val settings = SettingsRepository(context)
    val database: NexusDatabase by lazy { Room.databaseBuilder(context, NexusDatabase::class.java, "nexus.db").build() }
    val sampler = SystemSampler(context)

    private val providers: List<SpecProvider> by lazy {
        listOf(
            CpuProvider(), GpuProvider(context), MemoryProvider(context), StorageProvider(context), SystemProvider(context),
            DisplayProvider(context), BatteryProvider(context), NetworkProvider(context), SensorsProvider(context),
            CameraProvider(context), CodecsProvider(), AppsProvider(context),
        )
    }
    val devices: DeviceRepository by lazy { DeviceRepository(providers) }
    val benchmark: BenchmarkRunner by lazy { BenchmarkRunner(context, sampler) }
}
