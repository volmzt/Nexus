package com.nexus.device.diagnostics

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class LatencyResult(val url: String, val millis: Long?, val code: Int?, val error: String?, val at: Long)

/** Runs only when the user presses "Run". One HTTP HEAD request per call, no background tests. */
object LatencyTester {
    suspend fun ping(rawUrl: String): LatencyResult = withContext(Dispatchers.IO) {
        val url = if (rawUrl.startsWith("http")) rawUrl else "https://$rawUrl"
        val start = System.nanoTime()
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.instanceFollowRedirects = false
            val code = c.responseCode
            c.disconnect()
            LatencyResult(url, (System.nanoTime() - start) / 1_000_000, code, null, System.currentTimeMillis())
        } catch (e: Exception) {
            LatencyResult(url, null, null, e.javaClass.simpleName + (e.message?.let { ": $it" } ?: ""), System.currentTimeMillis())
        }
    }
}
