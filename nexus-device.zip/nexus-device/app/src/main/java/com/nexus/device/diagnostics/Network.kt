// Intentionally empty: the network latency test (the app no longer needs the INTERNET permission) was removed in 0.4.0. This file can be deleted from the repository.
