package com.nexus.device.diagnostics

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.nexus.device.monitoring.SystemSampler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicInteger

data class BenchTest(val id: String, val name: String, val unit: String, val note: String)

data class BenchResult(val test: BenchTest, val value: Double?, val message: String? = null)

class ThermalAbort(val tempC: Float) : Exception("Battery temperature reached $tempC °C")

/**
 * Safe, time-boxed tests. Each test is capped at about one second and the battery temperature is checked
 * before every test, so a hot device stops instead of being pushed further. Nothing is compared with invented references.
 */
class BenchmarkRunner(private val context: Context, private val sampler: SystemSampler) {
    companion object {
        const val MAX_TEMP_C = 42f
        val tests = listOf(
            BenchTest("cpu_single", "CPU single-thread", "Mops/s", "Integer arithmetic loop on one thread, 0.8 s"),
            BenchTest("cpu_multi", "CPU multi-thread", "Mops/s", "Same loop on every core at once, 0.8 s"),
            BenchTest("mem_bw", "Memory bandwidth", "MB/s", "Copies a 16 MB buffer repeatedly, 0.8 s"),
            BenchTest("mem_alloc", "Memory allocation", "k alloc/s", "Allocates and fills 1 KB arrays, 0.8 s"),
            BenchTest("storage_write", "Storage write", "MB/s", "Writes 32 MB to the app cache and syncs"),
            BenchTest("storage_read", "Storage read", "MB/s", "Reads the same file back (may be served from the page cache)"),
            BenchTest("graphics", "Canvas rendering", "fps", "Software Canvas drawing into a bitmap. It measures CPU-side 2D drawing, not the GPU"),
            BenchTest("sensor_rate", "Sensor response", "Hz", "Real accelerometer event rate over 1 s (Android caps it near 200 Hz without a special permission)"),
        )
    }

    @Volatile private var sink = 0L

    private fun guard() {
        val t = sampler.batteryTempC()
        if (t != null && t >= MAX_TEMP_C) throw ThermalAbort(t)
    }

    suspend fun run(id: String): List<BenchResult> = withContext(Dispatchers.Default) {
        guard()
        when (id) {
            "cpu_single" -> listOf(result(id, cpuWork(800) / 0.8 / 1e6))
            "cpu_multi" -> {
                val n = Runtime.getRuntime().availableProcessors()
                val total = coroutineScope { (0 until n).map { async(Dispatchers.Default) { cpuWork(800) } }.awaitAll().sum() }
                listOf(result(id, total / 0.8 / 1e6))
            }
            "mem_bw" -> listOf(result(id, memoryBandwidth()))
            "mem_alloc" -> listOf(result(id, allocRate()))
            "storage_write", "storage_read" -> storage().filter { it.test.id == id }
            "graphics" -> listOf(result(id, canvasFps()))
            "sensor_rate" -> listOf(sensorRate())
            else -> emptyList()
        }
    }

    private fun result(id: String, v: Double) = BenchResult(tests.first { it.id == id }, v)

    private fun cpuWork(ms: Long): Long {
        var x = 1L
        var ops = 0L
        val end = System.nanoTime() + ms * 1_000_000
        while (System.nanoTime() < end) {
            for (i in 0 until 50_000) {
                x = x * 6364136223846793005L + 1442695040888963407L
                x = x xor (x ushr 29)
            }
            ops += 50_000
        }
        sink = x
        return ops
    }

    private fun memoryBandwidth(): Double {
        val a = ByteArray(16 shl 20)
        val b = ByteArray(16 shl 20)
        var bytes = 0L
        val start = System.nanoTime()
        val end = start + 800_000_000L
        while (System.nanoTime() < end) {
            a[0] = (a[0] + 1).toByte()
            System.arraycopy(a, 0, b, 0, a.size)
            bytes += a.size
        }
        sink = b[1].toLong()
        return bytes / 1e6 / ((System.nanoTime() - start) / 1e9)
    }

    private fun allocRate(): Double {
        var n = 0L
        val start = System.nanoTime()
        val end = start + 800_000_000L
        var keep: IntArray? = null
        while (System.nanoTime() < end) {
            for (i in 0 until 200) {
                val arr = IntArray(256)
                arr[i % 256] = i
                keep = arr
            }
            n += 200
        }
        sink = (keep?.sum() ?: 0).toLong()
        return n / 1e3 / ((System.nanoTime() - start) / 1e9)
    }

    private fun storage(): List<BenchResult> {
        val file = File(context.cacheDir, "nexus_bench.bin")
        return try {
            val chunk = ByteArray(1 shl 20) { (it * 31).toByte() }
            val mb = 32
            val w0 = System.nanoTime()
            FileOutputStream(file).use { out ->
                repeat(mb) { out.write(chunk) }
                out.fd.sync()
            }
            val w = mb / ((System.nanoTime() - w0) / 1e9)
            val buf = ByteArray(1 shl 20)
            val r0 = System.nanoTime()
            var total = 0L
            FileInputStream(file).use { inp ->
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    total += n
                }
            }
            val r = total / 1e6 / ((System.nanoTime() - r0) / 1e9)
            listOf(result("storage_write", w), result("storage_read", r))
        } catch (e: Exception) {
            listOf(
                BenchResult(tests.first { it.id == "storage_write" }, null, "Failed: ${e.message}"),
                BenchResult(tests.first { it.id == "storage_read" }, null, "Failed: ${e.message}"),
            )
        } finally {
            file.delete()
        }
    }

    private fun canvasFps(): Double {
        val bmp = Bitmap.createBitmap(540, 960, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var frames = 0
        val start = System.nanoTime()
        val end = start + 800_000_000L
        while (System.nanoTime() < end) {
            c.drawColor(Color.BLACK)
            for (i in 0 until 120) {
                p.color = Color.rgb((i * 7 + frames) % 255, (i * 13) % 255, (i * 29) % 255)
                c.drawCircle(((i * 37 + frames * 3) % 540).toFloat(), ((i * 61) % 960).toFloat(), 30f, p)
            }
            frames++
        }
        bmp.recycle()
        return frames / ((System.nanoTime() - start) / 1e9)
    }

    private suspend fun sensorRate(): BenchResult {
        val test = tests.first { it.id == "sensor_rate" }
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            ?: return BenchResult(test, null, "No accelerometer on this device")
        val count = AtomicInteger(0)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { count.incrementAndGet() }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.registerListener(l, s, 5000 /* 200 Hz: the fastest rate allowed without HIGH_SAMPLING_RATE_SENSORS */)
        try { delay(1000) } finally { sm.unregisterListener(l) }
        return BenchResult(test, count.get().toDouble())
    }
}
