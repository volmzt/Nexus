package com.nexus.device.monitoring

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.nexus.device.database.BatteryDao
import com.nexus.device.database.BatterySampleEntity

/**
 * Stores one battery reading per minute at most, and only while the app or the temperature notification is running.
 * Readings older than a week are removed. There is no background collection beyond those two cases.
 */
object BatteryRecorder {
    private const val MIN_GAP_MS = 60_000L
    private const val KEEP_MS = 7L * 24 * 3600 * 1000
    @Volatile private var lastAt = 0L

    suspend fun record(context: Context, dao: BatteryDao) {
        val now = System.currentTimeMillis()
        if (now - lastAt < MIN_GAP_MS) return
        val i: Intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return
        lastAt = now
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val v = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        dao.insert(
            BatterySampleEntity(
                timestamp = now, level = level * 100 / scale,
                tempC = if (t == Int.MIN_VALUE || t <= 0) null else t / 10f,
                voltageMv = v.takeIf { it > 0 },
                charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            ),
        )
        dao.prune(now - KEEP_MS)
    }
}
