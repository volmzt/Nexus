package com.nexus.device.presentation.bench

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.device.R
import com.nexus.device.bench.BenchGroup
import com.nexus.device.bench.BenchRun
import com.nexus.device.bench.Catalog
import com.nexus.device.bench.CpuBench
import com.nexus.device.bench.GpuMeasure
import com.nexus.device.bench.MemBench
import com.nexus.device.bench.Scoring
import com.nexus.device.bench.TestScore
import com.nexus.device.bench.UxBench
import com.nexus.device.core.di.AppContainer
import com.nexus.device.monitoring.TempReader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Runs the NEXUS test in order: CPU, memory and storage, GPU, then everyday use.
 * The GPU test and the smoothness test need a screen, so the bench page hosts them and hands the result back here.
 */
class BenchViewModel(private val c: AppContainer) : ViewModel() {
    enum class Stage { IDLE, CPU, MEM, GPU, UX, DONE }
    enum class Host { NONE, GPU, SMOOTH }

    data class Ui(
        val stage: Stage = Stage.IDLE,
        @StringRes val step: Int? = null,
        val progress: Float = 0f,
        val host: Host = Host.NONE,
        val notes: List<String> = emptyList(),
        val hotC: Float? = null,
        val finished: BenchRun? = null,
        val saved: Boolean = false,
    ) {
        val running: Boolean get() = stage != Stage.IDLE && stage != Stage.DONE
    }

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    val history: StateFlow<List<BenchRun>> = c.bench.runs.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var job: Job? = null
    private var gpuWait: CompletableDeferred<GpuMeasure?>? = null
    private var smoothWait: CompletableDeferred<Double?>? = null
    private var gpuError: String? = null

    /** Called by the page that hosts the GPU test. */
    fun onGpu(result: GpuMeasure?, error: String?) {
        gpuError = error
        gpuWait?.complete(result)
    }

    /** Called by the page that hosts the smoothness test. [percent] is null when it could not run. */
    fun onSmooth(percent: Double?) { smoothWait?.complete(percent) }

    fun cancel() {
        job?.cancel()
        gpuWait?.complete(null)
        smoothWait?.complete(null)
    }

    fun start() {
        if (job != null) return
        job = viewModelScope.launch {
            val app = c.context
            val scores = mutableListOf<TestScore>()
            val notes = mutableListOf<String>()
            val before = TempReader.read(app)
            val totalSteps = Catalog.defs.size
            var done = 0
            var hot: Float? = null

            fun stageOf(g: BenchGroup) = when (g) {
                BenchGroup.CPU -> Stage.CPU
                BenchGroup.MEM -> Stage.MEM
                BenchGroup.GPU -> Stage.GPU
                BenchGroup.UX -> Stage.UX
            }

            fun show(stage: Stage, @StringRes name: Int, host: Host = Host.NONE) {
                _ui.update { it.copy(stage = stage, step = name, host = host, progress = done / totalSteps.toFloat()) }
            }

            fun add(id: String, value: Double?) {
                val def = Catalog.get(id) ?: return
                if (value == null) {
                    notes.add(app.getString(R.string.bench_skip, app.getString(def.name)))
                } else {
                    scores.add(TestScore(id, value, Scoring.points(value, def.reference)))
                }
            }

            /** Stops the run when the battery is hot. */
            suspend fun cool(): Boolean {
                val b = TempReader.read(app).batteryC
                if (b != null && b >= HOT_C) hot = b
                return hot == null
            }

            suspend fun step(id: String, block: () -> Double?) {
                val def = Catalog.get(id) ?: return
                show(stageOf(def.group), def.name)
                val v = withContext(Dispatchers.Default) {
                    try { block() } catch (e: OutOfMemoryError) { null } catch (e: Exception) { null }
                }
                currentCoroutineContext().ensureActive()
                add(id, v)
                done++
            }

            _ui.value = Ui(stage = Stage.CPU)
            try {
                val cpuSteps: List<Pair<String, () -> Double?>> = listOf(
                    "cpu_int" to { CpuBench.integer() },
                    "cpu_float" to { CpuBench.float() },
                    "cpu_crypto" to { CpuBench.crypto() },
                    "cpu_zip" to { CpuBench.zip() },
                    "cpu_multi" to { CpuBench.multi() },
                )
                for ((id, block) in cpuSteps) {
                    if (!cool()) break
                    step(id, block)
                }

                if (cool()) step("mem_copy") { MemBench.copy() }
                if (cool()) step("mem_lat") { MemBench.latency() }
                if (cool()) {
                    show(Stage.MEM, R.string.bench_t_write)
                    val st = withContext(Dispatchers.Default) { try { MemBench.storage(app.cacheDir) } catch (e: Exception) { null } }
                    currentCoroutineContext().ensureActive()
                    add("st_write", st?.writeMBs)
                    add("st_read", st?.readMBs)
                    add("st_rand", st?.randomIops)
                    done += 3
                }

                if (cool()) {
                    show(Stage.GPU, R.string.bench_t_alu, Host.GPU)
                    val wait = CompletableDeferred<GpuMeasure?>()
                    gpuError = null
                    gpuWait = wait
                    val m = withTimeoutOrNull(60_000L) { wait.await() }
                    gpuWait = null
                    currentCoroutineContext().ensureActive()
                    if (m == null) notes.add(app.getString(R.string.bench_gpu_fail, gpuError ?: "timeout"))
                    add("gpu_alu", m?.aluFps)
                    add("gpu_fill", m?.fillGpix)
                    add("gpu_geo", m?.geometryMtri)
                    done += 3
                }

                if (cool()) step("ux_json") { UxBench.json() }
                if (cool()) step("ux_image") { UxBench.image() }
                if (cool()) {
                    show(Stage.UX, R.string.bench_t_smooth, Host.SMOOTH)
                    val wait = CompletableDeferred<Double?>()
                    smoothWait = wait
                    val p = withTimeoutOrNull(20_000L) { wait.await() }
                    smoothWait = null
                    currentCoroutineContext().ensureActive()
                    add("ux_smooth", p)
                    done++
                }

                val after = TempReader.read(app)
                val run = BenchRun(System.currentTimeMillis(), scores.toList(), before.batteryC, after.batteryC, before.cpuC, after.cpuC)
                // Only a complete run is stored, because a total with missing tests could not be compared with the others.
                val complete = scores.size == Catalog.defs.size
                if (complete) c.bench.add(run) else notes.add(app.getString(R.string.bench_incomplete))
                _ui.value = Ui(stage = Stage.DONE, progress = 1f, notes = notes.toList(), hotC = hot, finished = run, saved = complete)
            } catch (e: CancellationException) {
                _ui.value = Ui()
                throw e
            } finally {
                gpuWait = null
                smoothWait = null
                job = null
            }
        }
    }

    private companion object {
        const val HOT_C = 46f
    }
}
