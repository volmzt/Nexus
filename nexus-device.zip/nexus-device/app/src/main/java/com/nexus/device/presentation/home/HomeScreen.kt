package com.nexus.device.presentation.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.background
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.TempUnit
import com.nexus.device.data.BgPalette
import com.nexus.device.data.HomeBlock
import com.nexus.device.data.HomeBlocks
import com.nexus.device.domain.Category
import com.nexus.device.presentation.HomeViewModel
import com.nexus.device.presentation.bench.BenchViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow

/**
 * The Home screen is a set of blocks the user arranges. A pencil in the corner (or a long press on a block) starts
 * editing: blocks get a shimmering outline, can be dragged, resized, removed, and new ones are added with the plus.
 */
@Composable
fun HomeScreen(
    vm: HomeViewModel,
    unit: TempUnit,
    blocks: List<HomeBlock>,
    editing: Boolean,
    palette: BgPalette,
    bench: BenchViewModel,
    onBench: (Boolean) -> Unit,
    onOpen: (Category) -> Unit,
    onRoute: (String) -> Unit,
    onBlocks: (List<HomeBlock>) -> Unit,
    onEditing: (Boolean) -> Unit,
    plain: Boolean,
    modifier: Modifier = Modifier,
    scroll: ScrollState = rememberScrollState(),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val history by bench.history.collectAsStateWithLifecycle()
    var local by remember { mutableStateOf(blocks) }
    // The lists handed to storage lately. Storage answers a little later, and an answer to an older save must not
    // overwrite what is on screen now (a block would jump back to where it was a second ago).
    val sent = remember { ArrayList<List<HomeBlock>>() }
    val save: (List<HomeBlock>) -> Unit = { l ->
        sent.add(l)
        if (sent.size > 8) sent.removeAt(0)
        onBlocks(l)
    }
    LaunchedEffect(blocks) { if (blocks != local && sent.none { it == blocks }) local = blocks }
    var adding by remember { mutableStateOf(false) }
    val openS by rememberUpdatedState(onOpen)
    val routeS by rememberUpdatedState(onRoute)
    val benchS by rememberUpdatedState(onBench)
    val editS by rememberUpdatedState(onEditing)
    val lastBench = history.firstOrNull()
    // Rebuilt only when something it shows changes, so moving a block does not recompose every block.
    val data = remember(ui, unit, bench, lastBench, editing) {
        HomeData(ui, unit, bench, lastBench, editing, { openS(it) }, { routeS(it) }, { benchS(it) }) { editS(true) }
    }

    var vpCoords by remember { mutableStateOf<androidx.compose.ui.layout.LayoutCoordinates?>(null) }
    Column(modifier.fillMaxSize().onGloballyPositioned { vpCoords = it }.verticalScroll(scroll).padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BigTitle(stringResource(R.string.app_name), Modifier.weight(1f))
            AnimatedContent(
                targetState = editing,
                transitionSpec = {
                    if (plain) androidx.compose.animation.EnterTransition.None togetherWith androidx.compose.animation.ExitTransition.None
                    else (fadeIn(tween(220)) + scaleIn(tween(260), initialScale = 0.7f)) togetherWith (fadeOut(tween(120)) + scaleOut(tween(160), targetScale = 0.7f))
                },
                label = "homeActions",
            ) { e ->
                if (e) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { local = local + HomeBlock("gap:" + System.currentTimeMillis(), HomeBlocks.SMALL); save(local) }) { Text(stringResource(R.string.home_gap)) }
                        IconButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, stringResource(R.string.home_add)) }
                        TextButton(onClick = { onEditing(false) }) { Text(stringResource(R.string.home_done)) }
                    }
                } else {
                    IconButton(onClick = { onEditing(true) }) { Icon(Icons.Filled.Edit, stringResource(R.string.home_edit)) }
                }
            }
        }
        HomeGrid(local, editing, plain, palette, data, onChange = { local = it }, onCommit = { save(local) }, scroll = scroll,
            viewport = { vpCoords?.takeIf { it.isAttached }?.boundsInRoot() ?: androidx.compose.ui.geometry.Rect.Zero })
        Spacer(Modifier.height(120.dp))
    }

    if (adding) {
        AddBlockDialog(
            existing = local.map { it.id }.toSet(),
            onAdd = { id ->
                local = local + HomeBlock(id, HomeBlocks.defaultSize(id))
                save(local)
                adding = false
            },
            onDismiss = { adding = false },
        )
    }
}

/** A search box over the blocks that are not on Home yet. */
@Composable
private fun AddBlockDialog(existing: Set<String>, onAdd: (String) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val names = HashMap<String, String>()
    for (s in HomeCatalog) names[s.id] = stringResource(s.title)
    val list = HomeCatalog.filter { it.id !in existing && (names[it.id] ?: "").contains(query.trim(), ignoreCase = true) }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surfaceContainerHigh).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(stringResource(R.string.home_search)) },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
            )
            if (list.isEmpty()) {
                Text(stringResource(R.string.home_nothing), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(list.size) { i ->
                        val s = list[i]
                        ItemRow(
                            names[s.id] ?: s.id, s.desc?.let { stringResource(it) }, icon = s.icon,
                            shape = RoundedCornerShape(16.dp), onClick = { onAdd(s.id) },
                        )
                    }
                }
            }
        }
    }
}
