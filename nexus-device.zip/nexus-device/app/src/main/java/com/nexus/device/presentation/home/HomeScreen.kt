package com.nexus.device.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.domain.Category
import com.nexus.device.presentation.HomeViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.LineChart

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    unit: TempUnit,
    hidden: Set<String>,
    onOpen: (Category) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val last = ui.last
    val na = stringResource(R.string.st_na)

    fun item(title: String) = ui.summary.firstOrNull { it.title == title }?.value

    LazyColumn(
        modifier.fillMaxWidth().padding(horizontal = 16.dp),
        state = listState,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { BigTitle(stringResource(R.string.app_name)) }

        // Compact device card: who this phone is, in three short lines.
        item {
            val name = listOfNotNull(item("Manufacturer"), item("Model")).joinToString(" ")
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainer)
                    .clickable { onOpen(Category.SYSTEM) }.padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(name.ifBlank { "—" }, style = MaterialTheme.typography.titleLarge)
                Text(
                    listOfNotNull(item("Android"), item("Processor")).joinToString(" · "),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    listOfNotNull(item("RAM")?.let { "RAM $it" }, item("Display")).joinToString(" · "),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // Live tiles. Every figure is a real reading; a missing one is shown as "not provided".
        item {
            val charging = last?.batteryCharging == true
            val batt = last?.batteryLevel?.let { "$it%" } ?: "—"
            val battSmall = listOfNotNull(
                last?.batteryTempC?.let { Fmt.temp(it, unit) },
                if (charging) stringResource(R.string.charging) else null,
            ).joinToString(" · ").ifBlank { na }
            val maxKHz = last?.cpuFreqKHz?.filterNotNull()?.maxOrNull()
            val cpuBig = maxKHz?.let { Fmt.one(it / 1_000_000.0) + " GHz" } ?: "—"
            val cpuSmall = ui.cpuTempC?.let { Fmt.temp(it, unit) } ?: na
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile(stringResource(R.string.battery), batt, battSmall, Modifier.weight(1f)) { onOpen(Category.BATTERY) }
                Tile(stringResource(R.string.cat_cpu), cpuBig, cpuSmall, Modifier.weight(1f)) { onOpen(Category.CPU) }
            }
        }
        item {
            val used = last?.storageUsedPercent
            Tile(
                stringResource(R.string.storage_used),
                used?.let { Fmt.one(it.toDouble()) + "%" } ?: "—",
                stringResource(R.string.storage_note, used?.let { Fmt.one(it.toDouble()) } ?: "—"),
                Modifier.fillMaxWidth(),
            ) { onOpen(Category.STORAGE) }
        }

        // One small history chart, built from the samples taken while this screen is visible.
        if (ui.temp.size >= 2) {
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainer)
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Text(stringResource(R.string.temperature), style = MaterialTheme.typography.bodyLarge)
                    LineChart(listOf(ui.temp.map { Fmt.tempValue(it, unit) }), Modifier.fillMaxWidth().height(56.dp), maxPoints = 30)
                }
            }
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
private fun Tile(title: String, big: String, small: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainer)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(big, style = MaterialTheme.typography.headlineMedium)
        Text(small, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
