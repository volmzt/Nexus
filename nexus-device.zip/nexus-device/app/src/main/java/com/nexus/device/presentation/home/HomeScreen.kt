package com.nexus.device.presentation.home

import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.domain.Category
import com.nexus.device.presentation.HomeViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.LineChart
import com.nexus.device.presentation.components.MeterRow
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.icon
import com.nexus.device.presentation.rememberCopier
import com.nexus.device.presentation.titleRes
import java.text.DateFormat
import java.util.Date

@Composable
fun HomeScreen(vm: HomeViewModel, unit: TempUnit, hidden: Set<String>, onOpen: (Category) -> Unit, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val copy = rememberCopier()
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { BigTitle(stringResource(R.string.app_name)) }
        items(ui.summary.size) { i ->
            val s = ui.summary[i]
            ItemRow(
                title = s.title, subtitle = s.value, icon = s.category.icon(),
                shape = groupShape(i, ui.summary.size), onClick = { copy(s.value) },
            )
        }
        item { Spacer(Modifier.height(12.dp)) }

        val last = ui.last
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                MeterRow(
                    stringResource(R.string.ram), (last?.ramUsedPercent ?: 0f) / 100f,
                    if (last != null) stringResource(R.string.ram_note, Fmt.one(last.ramUsedPercent.toDouble())) else stringResource(R.string.no_reading),
                    groupShape(0, 4),
                )
                MeterRow(
                    stringResource(R.string.battery), (last?.batteryLevel ?: 0) / 100f,
                    when {
                        last?.batteryLevel == null -> stringResource(R.string.no_reading)
                        last.batteryCharging == true -> stringResource(R.string.battery_note_charging, last.batteryLevel)
                        else -> stringResource(R.string.battery_note, last.batteryLevel)
                    },
                    groupShape(1, 4),
                )
                MeterRow(
                    stringResource(R.string.storage_used), (last?.storageUsedPercent ?: 0f) / 100f,
                    if (last != null) stringResource(R.string.storage_note, Fmt.one(last.storageUsedPercent.toDouble())) else stringResource(R.string.no_reading),
                    groupShape(2, 4),
                )
                ItemRow(
                    title = stringResource(R.string.temperature),
                    subtitle = last?.batteryTempC?.let { Fmt.temp(it, unit) } ?: stringResource(R.string.no_temp),
                    shape = groupShape(3, 4),
                )
            }
        }

        item { Spacer(Modifier.height(12.dp)) }
        item {
            // Mini charts built only from the samples collected while this screen is visible.
            Column(
                Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                ChartCard(stringResource(R.string.ram), ui.ram, groupShape(0, 4))
                ChartCard(stringResource(R.string.temperature), ui.temp.map { com.nexus.device.core.Fmt.tempValue(it, unit) }, groupShape(1, 4))
                ChartCard(stringResource(R.string.battery), ui.battery, groupShape(2, 4))
                ChartCard(stringResource(R.string.storage_used), ui.storage, groupShape(3, 4))
            }
        }

        item {
            Spacer(Modifier.height(12.dp))
            Text(
                stringResource(R.string.updated_at, last?.let { DateFormat.getTimeInstance().format(Date(it.timestamp)) } ?: "—"),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.refresh() }) { Text(stringResource(R.string.refresh_all)) }
            Spacer(Modifier.height(16.dp))
        }

        val cats = Category.entries.filter { it.id !in hidden }
        items(cats.size) { i ->
            val c = cats[i]
            ItemRow(stringResource(c.titleRes()), icon = c.icon(), shape = groupShape(i, cats.size), onClick = { onOpen(c) }, chevron = true)
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
private fun ChartCard(title: String, values: List<Float>, shape: androidx.compose.ui.graphics.Shape) {
    Column(
        Modifier.fillMaxWidth().clipAndFill(shape).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        if (values.size < 2) {
            Text(stringResource(R.string.no_reading), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LineChart(listOf(values), Modifier.fillMaxWidth().height(56.dp), maxPoints = 30)
        }
    }
}

@Composable
private fun Modifier.clipAndFill(shape: androidx.compose.ui.graphics.Shape): Modifier =
    this.then(Modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceContainer))
