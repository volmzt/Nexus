package com.nexus.device.presentation.home

import androidx.compose.foundation.background
import com.nexus.device.presentation.components.cardSurface
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import android.os.Environment
import android.os.StatFs
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.domain.Category
import com.nexus.device.presentation.HomeViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.LineChart

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    unit: TempUnit,
    hidden: Set<String>,
    onOpen: (Category) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val last = ui.last
    val na = stringResource(R.string.st_na)

    fun item(title: String) = ui.summary.firstOrNull { it.title == title }?.value

    LazyColumn(
        modifier.fillMaxWidth().padding(horizontal = 16.dp),
        state = listState,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { BigTitle(stringResource(R.string.app_name)) }

        // Compact device card: who this phone is, in three short lines.
        item {
            val name = listOfNotNull(item("Manufacturer"), item("Model")).joinToString(" ")
            Column(
                Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp))
                    .clickable { onOpen(Category.SYSTEM) }.padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(name.ifBlank { "—" }, style = MaterialTheme.typography.titleLarge)
                Text(
                    listOfNotNull(item("Android"), item("Processor")).joinToString(" · "),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    listOfNotNull(item("RAM")?.let { "RAM $it" }, item("Display")).joinToString(" · "),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // Live tiles. Every figure is a real reading; a missing one is shown as "not provided".
        item {
            val charging = last?.batteryCharging == true
            val battSmall = listOfNotNull(
                ui.tempBatt.lastOrNull()?.let { Fmt.temp(it, unit) },
                if (charging) stringResource(R.string.charging) else null,
            ).joinToString(" · ").ifBlank { na }
            val maxKHz = last?.cpuFreqKHz?.filterNotNull()?.maxOrNull()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile(stringResource(R.string.battery), last?.batteryLevel?.let { "$it%" } ?: "—", battSmall, Modifier.weight(1f)) { onOpen(Category.BATTERY) }
                Tile(
                    stringResource(R.string.cat_cpu), maxKHz?.let { Fmt.one(it / 1_000_000.0) + " GHz" } ?: "—",
                    ui.cpuTempC?.let { Fmt.temp(it, unit) } ?: na, Modifier.weight(1f),
                ) { onOpen(Category.CPU) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile(
                    stringResource(R.string.ram), last?.let { Fmt.one(it.ramUsedPercent.toDouble()) + "%" } ?: "—",
                    last?.let { stringResource(R.string.ram_free, Fmt.bytes(it.ramAvailBytes)) } ?: na, Modifier.weight(1f),
                ) { onOpen(Category.MEMORY) }
                Tile(
                    stringResource(R.string.load), ui.loadPercent?.let { "$it%" } ?: "—",
                    ui.loadPercent?.let { stringResource(R.string.load_all_cores) } ?: na, Modifier.weight(1f),
                ) { onOpen(Category.CPU) }
            }
        }
        item {
            val st = remember(last?.timestamp) {
                runCatching { StatFs(Environment.getDataDirectory().absolutePath).let { it.totalBytes to it.availableBytes } }.getOrNull()
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile(
                    stringResource(R.string.storage_used),
                    last?.let { Fmt.one(it.storageUsedPercent.toDouble()) + "%" } ?: "—",
                    st?.let { stringResource(R.string.storage_of, Fmt.bytes(it.first - it.second), Fmt.bytes(it.first)) } ?: na,
                    Modifier.weight(1f),
                ) { onOpen(Category.STORAGE) }
                Tile(
                    stringResource(R.string.cat_gpu), ui.gpuMHz?.let { "$it MHz" } ?: "—",
                    ui.gpuBusy?.let { stringResource(R.string.load) + " $it%" } ?: na, Modifier.weight(1f),
                ) { onOpen(Category.GPU) }
            }
        }

        // Temperature history of the battery and the processor, built from the readings taken while this screen is open.
        if (ui.tempBatt.size >= 2 || ui.tempCpu.size >= 2) {
            item {
                Column(
                    Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp))
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stringResource(R.string.temperature), style = MaterialTheme.typography.bodyLarge)
                        Text(
                            stringResource(R.string.temp_battery) + " · " + stringResource(R.string.temp_cpu),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    LineChart(
                        listOf(ui.tempBatt.map { Fmt.tempValue(it, unit) }, ui.tempCpu.map { Fmt.tempValue(it, unit) }),
                        Modifier.fillMaxWidth().height(72.dp), maxPoints = 40,
                    )
                }
            }
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
private fun Tile(title: String, big: String, small: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.cardSurface(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(big, style = MaterialTheme.typography.headlineMedium)
        Text(small, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
