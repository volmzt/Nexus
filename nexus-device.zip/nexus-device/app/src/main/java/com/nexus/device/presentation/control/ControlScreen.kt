package com.nexus.device.presentation.control

import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.provider.Settings
import android.view.Display
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.access.AccessMode
import com.nexus.device.access.AccessState
import com.nexus.device.control.CpuPolicy
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.presentation.ControlViewModel
import com.nexus.device.presentation.Msg
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.toast

private sealed interface Dlg {
    data class Cpu(val p: CpuPolicy) : Dlg
    data class CpuField(val p: CpuPolicy, val field: Int) : Dlg
    data object Gpu : Dlg
    data class GpuField(val field: Int) : Dlg
    data object Density : Dlg
    data object Size : Dlg
    data object Refresh : Dlg
    data object Anim : Dlg
}

private fun mhz(khz: Long?) = khz?.let { "${it / 1000}" } ?: "—"

@Composable
fun ControlScreen(
    vm: ControlViewModel,
    unit: TempUnit,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val access by vm.access.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val na = stringResource(R.string.st_na)

    // Live values refresh only while this screen is on top.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_START) { vm.refreshAccess(); vm.startLive() }
            if (e == Lifecycle.Event.ON_STOP) vm.stopLive()
        }
        owner.lifecycle.addObserver(obs)
        vm.refreshAccess(); vm.startLive()
        onDispose { owner.lifecycle.removeObserver(obs); vm.stopLive() }
    }

    val okMsg = stringResource(R.string.applied)
    val accMsg = stringResource(R.string.needs_access)
    val rootMsg = stringResource(R.string.needs_root)
    val failFmt = stringResource(R.string.failed_with, "%s")
    LaunchedEffect(Unit) {
        vm.events.collect { m ->
            toast(ctx, when (m) {
                Msg.Ok -> okMsg
                Msg.NeedsAccess -> accMsg
                Msg.NeedsRoot -> rootMsg
                is Msg.Err -> failFmt.replace("%s", m.text)
            })
        }
    }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { BigTitle(stringResource(R.string.tab_control)) }
        item { AccessCard(access, vm::requestShizuku, vm::checkRoot); Spacer(Modifier.height(10.dp)) }

        // Live summary: only real readings.
        item {
            val temps = ui.temps
            val avgLoad = ui.loads.takeIf { it.isNotEmpty() }?.average()?.toInt()
            val lines = listOf(
                stringResource(R.string.load) to (avgLoad?.let { "$it %" } ?: na),
                stringResource(R.string.temp_cpu) to (temps?.cpuC?.let { Fmt.temp(it, unit) } ?: na),
                stringResource(R.string.temp_battery) to (temps?.batteryC?.let { Fmt.temp(it, unit) } ?: na),
            )
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                lines.forEach { (k, v) ->
                    Column {
                        Text(k, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(v, style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        // Processor clusters
        item { SectionTitle(R.string.ctl_cpu) }
        val cpu = ui.cpu
        if (cpu.isEmpty()) {
            item { ItemRow(stringResource(R.string.ctl_cpu), if (ui.loaded) na else "…", shape = groupShape(0, 1)) }
        } else {
            items(cpu.size) { i ->
                val p = cpu[i]
                ItemRow(
                    title = stringResource(R.string.ctl_cluster, p.cores) + " · " + mhz(p.curKHz) + " MHz",
                    subtitle = (p.governor ?: "—") + " · " + mhz(p.minKHz) + "–" + mhz(p.maxKHz) + " MHz",
                    icon = Icons.Filled.Memory, shape = groupShape(i, cpu.size), onClick = { dlg = Dlg.Cpu(p) }, chevron = true,
                )
            }
        }
        item {
            Spacer(Modifier.height(10.dp))
            SectionTitle(R.string.cat_gpu)
            val g = ui.gpu
            ItemRow(
                title = stringResource(R.string.cat_gpu),
                subtitle = if (g == null) na else stringResource(R.string.gpu_freq_busy, g.curHz?.let { "${it / 1_000_000}" } ?: "—", g.busyPercent?.let { "$it %" } ?: "—"),
                shape = groupShape(0, 1), onClick = if (g != null) ({ dlg = Dlg.Gpu }) else null, chevron = g != null,
            )
            Spacer(Modifier.height(10.dp))
        }

        // Display
        item {
            SectionTitle(R.string.ctl_display)
            val d = ui.display
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ItemRow(stringResource(R.string.density), d?.curDpi?.let { "$it DPI" + (if (d.physDpi != null && d.physDpi != it) " (${d.physDpi})" else "") } ?: na, shape = groupShape(0, 4), onClick = { dlg = Dlg.Density }, chevron = true)
                ItemRow(stringResource(R.string.resolution), d?.curSize ?: na, shape = groupShape(1, 4), onClick = { dlg = Dlg.Size }, chevron = true)
                ItemRow(stringResource(R.string.refresh_rate), d?.peakRefresh?.let { it.toFloatOrNull()?.toInt()?.toString() ?: it }?.plus(" Hz") ?: stringResource(R.string.auto), shape = groupShape(2, 4), onClick = { dlg = Dlg.Refresh }, chevron = true)
                ItemRow(stringResource(R.string.animations), d?.animScale?.let { "×$it" } ?: "×1.0", shape = groupShape(3, 4), onClick = { dlg = Dlg.Anim }, chevron = true)
            }
            Spacer(Modifier.height(10.dp))
        }

        // Tweaks
        item {
            SectionTitle(R.string.ctl_tweaks)
            val t = ui.tweaks
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ItemRow(stringResource(R.string.tw_stay_awake), shape = groupShape(0, 3), onClick = { vm.setStayAwake(!(t?.stayAwake ?: false)) },
                    trailing = { Switch(checked = t?.stayAwake ?: false, onCheckedChange = { vm.setStayAwake(it) }) })
                ItemRow(stringResource(R.string.tw_show_touches), shape = groupShape(1, 3), onClick = { vm.setShowTouches(!(t?.showTouches ?: false)) },
                    trailing = { Switch(checked = t?.showTouches ?: false, onCheckedChange = { vm.setShowTouches(it) }) })
                ItemRow(stringResource(R.string.tw_pointer), shape = groupShape(2, 3), onClick = { vm.setPointer(!(t?.pointer ?: false)) },
                    trailing = { Switch(checked = t?.pointer ?: false, onCheckedChange = { vm.setPointer(it) }) })
            }
            Spacer(Modifier.height(10.dp))
        }

        item {
            SectionTitle(R.string.ctl_more)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ItemRow(stringResource(R.string.terminal), icon = Icons.Filled.Tune, shape = groupShape(0, 2), onClick = { onOpen("terminal") }, chevron = true)
                ItemRow(stringResource(R.string.dev_options), shape = groupShape(1, 2), chevron = true, onClick = {
                    runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                })
            }
            Spacer(Modifier.height(120.dp))
        }
    }

    // ---- dialogs ----
    when (val d = dlg) {
        null -> {}
        is Dlg.Cpu -> {
            val p = ui.cpu.firstOrNull { it.id == d.p.id } ?: d.p
            AlertDialog(
                onDismissRequest = { dlg = null },
                title = { Text(stringResource(R.string.ctl_cluster, p.cores)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        ItemRow(stringResource(R.string.governor), p.governor ?: "—", shape = groupShape(0, 3), onClick = { dlg = Dlg.CpuField(p, 0) }, chevron = true)
                        ItemRow(stringResource(R.string.min_freq), mhz(p.minKHz) + " MHz", shape = groupShape(1, 3), onClick = { dlg = Dlg.CpuField(p, 1) }, chevron = true)
                        ItemRow(stringResource(R.string.max_freq), mhz(p.maxKHz) + " MHz", shape = groupShape(2, 3), onClick = { dlg = Dlg.CpuField(p, 2) }, chevron = true)
                    }
                },
                confirmButton = { TextButton(onClick = { dlg = null }) { Text(stringResource(R.string.close)) } },
            )
        }
        is Dlg.CpuField -> {
            val p = d.p
            val freqs = p.freqs.ifEmpty {
                val hi = p.hwMaxKHz ?: p.maxKHz ?: 0L
                listOf(0.25, 0.5, 0.75, 1.0).map { (hi * it / 1000).toLong() * 1000 }.filter { it > 0 }
            }
            when (d.field) {
                0 -> ChoiceDialog(stringResource(R.string.governor), p.governors.map { it to it }, p.governor, { dlg = Dlg.Cpu(p) }) { vm.setCpu(p, it, null, null); dlg = null }
                1 -> ChoiceDialog(stringResource(R.string.min_freq), freqs.map { (mhz(it) + " MHz") to it }, p.minKHz, { dlg = Dlg.Cpu(p) }) { vm.setCpu(p, null, it, null); dlg = null }
                else -> ChoiceDialog(stringResource(R.string.max_freq), freqs.map { (mhz(it) + " MHz") to it }, p.maxKHz, { dlg = Dlg.Cpu(p) }) { vm.setCpu(p, null, null, it); dlg = null }
            }
        }
        Dlg.Gpu -> {
            val g = ui.gpu
            AlertDialog(
                onDismissRequest = { dlg = null },
                title = { Text(stringResource(R.string.cat_gpu)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        ItemRow(stringResource(R.string.governor), g?.governor ?: "—", shape = groupShape(0, 2), onClick = { dlg = Dlg.GpuField(0) }, chevron = true)
                        ItemRow(stringResource(R.string.max_freq), (g?.maxHz?.let { "${it / 1_000_000}" } ?: "—") + " MHz", shape = groupShape(1, 2), onClick = { dlg = Dlg.GpuField(1) }, chevron = true)
                    }
                },
                confirmButton = { TextButton(onClick = { dlg = null }) { Text(stringResource(R.string.close)) } },
            )
        }
        is Dlg.GpuField -> {
            val g = ui.gpu
            if (g != null) {
                if (d.field == 0) ChoiceDialog(stringResource(R.string.governor), g.governors.map { it to it }, g.governor, { dlg = Dlg.Gpu }) { vm.setGpu(it, null); dlg = null }
                else ChoiceDialog(stringResource(R.string.max_freq), g.freqsHz.map { ("${it / 1_000_000} MHz") to it }, g.maxHz, { dlg = Dlg.Gpu }) { vm.setGpu(null, it); dlg = null }
            } else LaunchedEffect(Unit) { dlg = null }
        }
        Dlg.Density -> {
            val phys = ui.display?.physDpi
            val presets = phys?.let { p -> listOf(0.75, 0.85, 1.0, 1.15).map { (p * it / 10).toInt() * 10 }.distinct().filter { it >= 100 } } ?: emptyList()
            ValueDialog(
                title = stringResource(R.string.density), initial = (ui.display?.curDpi ?: phys)?.toString() ?: "",
                presets = presets.map { "$it" to "$it" }, number = true,
                onReset = { vm.setDensity(null); dlg = null }, onDismiss = { dlg = null },
                onApply = { v -> v.toIntOrNull()?.takeIf { it in 72..1000 }?.let { vm.setDensity(it) }; dlg = null },
            )
        }
        Dlg.Size -> {
            val phys = ui.display?.physSize
            val wh = phys?.split('x')?.mapNotNull { it.toIntOrNull() }
            val presets = if (wh != null && wh.size == 2) listOf(100, 90, 80, 70).map { pct ->
                val w = wh[0] * pct / 100 / 2 * 2
                val h = wh[1] * pct / 100 / 2 * 2
                "$pct %  ·  ${w}x$h" to "${w}x$h"
            } else emptyList()
            ValueDialog(
                title = stringResource(R.string.resolution), initial = ui.display?.curSize ?: "",
                presets = presets, number = false,
                onReset = { vm.setSize(null); dlg = null }, onDismiss = { dlg = null },
                onApply = { v -> if (Regex("\\d{3,5}x\\d{3,5}").matches(v.trim())) vm.setSize(v.trim()); dlg = null },
            )
        }
        Dlg.Refresh -> {
            val rates = remember { supportedRates(ctx) }
            ChoiceDialog(
                stringResource(R.string.refresh_rate),
                listOf(stringResource(R.string.auto) to 0) + rates.map { "$it Hz" to it },
                ui.display?.peakRefresh?.toFloatOrNull()?.toInt() ?: 0, { dlg = null },
            ) { vm.setRefresh(if (it == 0) null else it); dlg = null }
        }
        Dlg.Anim -> {
            val cur = ui.display?.animScale?.toFloatOrNull() ?: 1f
            ChoiceDialog(
                stringResource(R.string.animations),
                listOf(stringResource(R.string.anim_off) to 0f, "×0.5" to 0.5f, "×1" to 1f, "×1.5" to 1.5f, "×2" to 2f),
                cur, { dlg = null },
            ) { vm.setAnim(it); dlg = null }
        }
    }
}

private fun supportedRates(ctx: Context): List<Int> = runCatching {
    val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    dm.getDisplay(Display.DEFAULT_DISPLAY).supportedModes.map { Math.round(it.refreshRate) }.distinct().sorted()
}.getOrDefault(emptyList())

@Composable
private fun SectionTitle(res: Int) {
    Text(stringResource(res), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
}

@Composable
private fun AccessCard(a: AccessState, onShizuku: () -> Unit, onRoot: () -> Unit) {
    val modeName = when (a.mode) {
        AccessMode.ROOT -> R.string.acc_mode_root
        AccessMode.SHIZUKU -> R.string.acc_mode_shizuku
        AccessMode.NONE -> R.string.acc_mode_none
    }
    val desc = when {
        a.rootAvailable -> R.string.acc_root_ok
        a.shizukuRunning && a.shizukuGranted -> R.string.acc_shizuku_ok
        a.shizukuRunning -> R.string.acc_shizuku_perm
        else -> R.string.acc_shizuku_off
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(stringResource(R.string.ctl_access) + " · " + stringResource(modeName), style = MaterialTheme.typography.titleMedium)
        Text(stringResource(desc), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (a.mode == AccessMode.NONE) Text(stringResource(R.string.acc_none_desc), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (a.shizukuRunning && !a.shizukuGranted) Button(onClick = onShizuku) { Text(stringResource(R.string.btn_grant)) }
            if (!a.rootAvailable) FilledTonalButton(onClick = onRoot) { Text(stringResource(R.string.btn_check_root)) }
        }
    }
}

@Composable
private fun <T> ChoiceDialog(title: String, options: List<Pair<String, T>>, selected: T?, onDismiss: () -> Unit, onPick: (T) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                items(options.size) { i ->
                    val (label, v) = options[i]
                    Row(Modifier.fillMaxWidth().clickable { onPick(v) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = v == selected, onClick = { onPick(v) })
                        Text(label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ValueDialog(
    title: String, initial: String, presets: List<Pair<String, String>>, number: Boolean,
    onReset: () -> Unit, onDismiss: () -> Unit, onApply: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    presets.forEach { (label, v) -> FilterChip(selected = text == v, onClick = { text = v }, label = { Text(label) }) }
                }
                TextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    label = { Text(stringResource(R.string.custom_value)) },
                    keyboardOptions = if (number) androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number) else androidx.compose.foundation.text.KeyboardOptions.Default,
                )
            }
        },
        confirmButton = { TextButton(onClick = { onApply(text) }) { Text(stringResource(R.string.apply)) } },
        dismissButton = {
            Row {
                TextButton(onClick = onReset) { Text(stringResource(R.string.reset)) }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        },
    )
}
