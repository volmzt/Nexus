package com.nexus.device.presentation.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.luminance
import com.nexus.device.data.VisualStyle
import com.nexus.device.presentation.theme.LocalVisualStyle
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.remember
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BigTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.displaySmall.copy(fontSize = 34.sp, fontWeight = FontWeight.Normal),
        color = MaterialTheme.colorScheme.onBackground,
        modifier = modifier.statusBarsPadding().padding(top = 28.dp, bottom = 16.dp),
    )
}

/**
 * Background of every card, chosen by the Visual Style setting.
 * GLASS: translucent gradient with a thin light edge. TRANSLUCENT: see-through flat colour. OPAQUE: solid, no blending.
 * Compose has no cheap backdrop blur, so "glass" is built from translucency, a sheen and an edge, not a real blur.
 */
@Composable
fun Modifier.cardSurface(shape: Shape): Modifier {
    val base = MaterialTheme.colorScheme.surfaceContainer
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return when (LocalVisualStyle.current) {
        VisualStyle.OPAQUE -> clip(shape).background(base)
        VisualStyle.TRANSLUCENT -> clip(shape).background(base.copy(alpha = 0.72f))
        VisualStyle.GLASS -> {
            val top = if (dark) Color.White.copy(alpha = 0.15f) else Color.White.copy(alpha = 0.85f)
            val bottom = if (dark) Color.White.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.55f)
            val edge = if (dark) Color.White.copy(alpha = 0.14f) else Color.Black.copy(alpha = 0.08f)
            clip(shape).background(Brush.verticalGradient(listOf(top, bottom))).border(1.dp, edge, shape)
        }
    }
}

fun groupShape(index: Int, size: Int): Shape {
    val big = 24.dp
    val small = 4.dp
    return RoundedCornerShape(
        topStart = if (index == 0) big else small, topEnd = if (index == 0) big else small,
        bottomStart = if (index == size - 1) big else small, bottomEnd = if (index == size - 1) big else small,
    )
}

/** Icon + title + subtitle row, the basic unit of every list in the app. Tap and long-press are separate actions. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ItemRow(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    shape: Shape = RoundedCornerShape(4.dp),
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    chevron: Boolean = false,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .cardSurface(shape)
            .then(
                if (onClick != null || onLongClick != null) Modifier.combinedClickable(onClick = onClick ?: {}, onLongClick = onLongClick)
                else Modifier,
            )
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (icon != null) Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(24.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing?.invoke()
        if (chevron) Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun StatusText(text: String, color: Color) {
    Text(text, style = MaterialTheme.typography.labelSmall, color = color)
}

/** Progress bar that animates from its previous value. */
@Composable
fun MeterRow(label: String, fraction: Float, note: String, shape: Shape, modifier: Modifier = Modifier) {
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(900), label = "meter")
    Column(
        modifier.fillMaxWidth().cardSurface(shape).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            Text(note, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
            Box(Modifier.fillMaxWidth(f).height(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
        }
    }
}

@Composable
fun LineChart(
    series: List<List<Float>>,
    modifier: Modifier = Modifier,
    colors: List<Color> = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary, MaterialTheme.colorScheme.tertiary),
    maxPoints: Int = 60,
) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier) {
        val all = series.flatten()
        if (all.isEmpty()) return@Canvas
        var lo = all.min()
        var hi = all.max()
        if (hi - lo < 1e-3f) { hi += 1f; lo -= 1f }
        val pad = (hi - lo) * 0.12f
        lo -= pad
        hi += pad
        for (g in 1..3) {
            val y = size.height * g / 4f
            drawLine(grid, Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
        }
        series.forEachIndexed { si, s ->
            if (s.size < 2) return@forEachIndexed
            val color = colors[si % colors.size]
            val line = Path()
            var firstX = 0f
            var lastX = 0f
            s.forEachIndexed { i, v ->
                val x = size.width * (i + maxPoints - s.size) / (maxPoints - 1).toFloat()
                val y = size.height * (1f - (v - lo) / (hi - lo))
                if (i == 0) { line.moveTo(x, y); firstX = x } else line.lineTo(x, y)
                lastX = x
            }
            if (series.size == 1) {
                val area = Path().apply {
                    addPath(line)
                    lineTo(lastX, size.height)
                    lineTo(firstX, size.height)
                    close()
                }
                drawPath(area, color.copy(alpha = 0.14f))
            }
            drawPath(line, color, style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

data class NavTab(val label: String, val icon: ImageVector)

/** Floating pill navigation. The highlight slides between tabs instead of jumping. */
@Composable
fun NexusNavBar(tabs: List<NavTab>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxWidth().cardSurface(RoundedCornerShape(32.dp))) {
        BoxWithConstraints(Modifier.padding(6.dp)) {
            val itemWidth: Dp = maxWidth / tabs.size
            val offset by animateDpAsState(
                targetValue = itemWidth * selected,
                animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
                label = "indicator",
            )
            Box(
                Modifier.offset(x = offset).width(itemWidth).height(60.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
            )
            Row(Modifier.fillMaxWidth()) {
                tabs.forEachIndexed { i, t ->
                    val on = i == selected
                    Column(
                        // No ripple on purpose: the sliding highlight is the only feedback.
                        Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(26.dp)).clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { onSelect(i) },
                        ),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(
                            t.icon, t.label, modifier = Modifier.size(24.dp),
                            tint = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            t.label, style = MaterialTheme.typography.labelSmall,
                            color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}

/** Equal-width text tabs in a pill. The selected one gets a soft highlight; there is no ripple. */
@Composable
fun SegmentedTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().cardSurface(CircleShape).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        labels.forEachIndexed { i, l ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(CircleShape)
                    .background(if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else Color.Transparent)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    l, style = MaterialTheme.typography.labelLarge, maxLines = 1,
                    color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
