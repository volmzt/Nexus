package com.nexus.device.presentation.control

import androidx.compose.foundation.background
import com.nexus.device.presentation.components.cardSurface
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.nexus.device.R
import com.nexus.device.access.AccessMode
import com.nexus.device.access.Privileged
import com.nexus.device.presentation.device.DetailHeader
import com.nexus.device.presentation.rememberCopier
import kotlinx.coroutines.launch

private val QUICK = listOf(
    "uname -a", "getprop ro.product.model", "cat /proc/cpuinfo", "cat /proc/meminfo", "df -h", "dumpsys battery",
    "ls /sys/class/thermal", "settings list global", "wm size; wm density", "pm list packages -3", "ip addr", "top -n 1 -b | head -20",
)

/** A command runner, not a full terminal emulator: one command in, its output out. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TerminalScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val access by Privileged.state.collectAsState()
    var cmd by rememberSaveable { mutableStateOf("") }
    var output by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var mode by rememberSaveable { mutableStateOf("auto") }
    val scope = rememberCoroutineScope()
    val copy = rememberCopier()

    fun run(c: String) {
        if (c.isBlank() || busy) return
        busy = true
        val m = when (mode) {
            "normal" -> AccessMode.NONE
            "shizuku" -> AccessMode.SHIZUKU
            "root" -> AccessMode.ROOT
            else -> null
        }
        scope.launch {
            val r = Privileged.exec(c, m)
            output = ("$ $c\n" + r.out + (if (r.err.isNotBlank()) "\n" + r.err else "") + "\n\n" + output).take(100_000)
            busy = false
        }
    }

    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        DetailHeader(stringResource(R.string.terminal), onBack)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = mode == "auto", onClick = { mode = "auto" }, label = { Text("Auto") })
            FilterChip(selected = mode == "normal", onClick = { mode = "normal" }, label = { Text(stringResource(R.string.mode_normal)) })
            if (access.shizukuGranted) FilterChip(selected = mode == "shizuku", onClick = { mode = "shizuku" }, label = { Text("Shizuku") })
            if (access.rootAvailable) FilterChip(selected = mode == "root", onClick = { mode = "root" }, label = { Text("Root") })
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            TextField(
                value = cmd, onValueChange = { cmd = it }, singleLine = true, modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.terminal_hint)) },
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
            )
            Button(onClick = { run(cmd) }, enabled = !busy) { Text(stringResource(R.string.run)) }
        }
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.quick_cmds), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            QUICK.forEach { q -> AssistChip(onClick = { cmd = q; run(q) }, label = { Text(q, maxLines = 1) }) }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { copy(output) }, enabled = output.isNotBlank()) { Text(stringResource(R.string.copy_output)) }
            OutlinedButton(onClick = { output = "" }, enabled = output.isNotBlank()) { Text(stringResource(R.string.net_clear)) }
        }
        Spacer(Modifier.height(8.dp))
        SelectionContainer(Modifier.weight(1f).fillMaxWidth().cardSurface(RoundedCornerShape(16.dp))) {
            Text(
                output.ifBlank { stringResource(R.string.term_empty) },
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                color = if (output.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
