package com.nexus.device.hardware

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import com.nexus.device.core.Spec
import com.nexus.device.core.spec
import com.nexus.device.domain.Category
import com.nexus.device.domain.SpecProvider

object GlInfoReader {
    class Info(
        val vendor: String?,
        val renderer: String?,
        val version: String?,
        val glsl: String?,
        val extensions: List<String>,
    )

    @Volatile private var cache: Info? = null

    /** Creates a 1x1 offscreen EGL context, reads GL strings, and releases it. Does not terminate the shared EGL display. */
    fun query(): Info? {
        cache?.let { return it }
        val info = tryContext(3) ?: tryContext(2)
        cache = info
        return info
    }

    private fun tryContext(major: Int): Info? {
        var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
        var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
        var surf: EGLSurface = EGL14.EGL_NO_SURFACE
        try {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (display == EGL14.EGL_NO_DISPLAY) return null
            val ver = IntArray(2)
            if (!EGL14.eglInitialize(display, ver, 0, ver, 1)) return null
            val renderable = if (major >= 3) 0x0040 else EGL14.EGL_OPENGL_ES2_BIT // EGL_OPENGL_ES3_BIT_KHR
            val attrs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, renderable,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE,
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val num = IntArray(1)
            if (!EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, num, 0) || num[0] == 0) return null
            val cfg = configs[0] ?: return null
            ctx = EGL14.eglCreateContext(
                display, cfg, EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, major, EGL14.EGL_NONE), 0,
            )
            if (ctx == EGL14.EGL_NO_CONTEXT) return null
            surf = EGL14.eglCreatePbufferSurface(
                display, cfg, intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0,
            )
            if (!EGL14.eglMakeCurrent(display, surf, surf, ctx)) return null
            val ext = GLES20.glGetString(GLES20.GL_EXTENSIONS)?.split(" ")?.filter { it.isNotBlank() }?.sorted().orEmpty()
            return Info(
                vendor = GLES20.glGetString(GLES20.GL_VENDOR),
                renderer = GLES20.glGetString(GLES20.GL_RENDERER),
                version = GLES20.glGetString(GLES20.GL_VERSION),
                glsl = GLES20.glGetString(GLES20.GL_SHADING_LANGUAGE_VERSION),
                extensions = ext,
            )
        } catch (e: Throwable) {
            return null
        } finally {
            if (display != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surf)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, ctx)
            }
        }
    }
}

class GpuProvider(private val context: Context) : SpecProvider {
    override val category = Category.GPU

    override fun read(): List<Spec> {
        val gl = GlInfoReader.query()
        val pm = context.packageManager
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val out = mutableListOf<Spec>()
        out += spec("Renderer (GPU)") { gl?.renderer }
        out += spec("Vendor") { gl?.vendor }
        out += spec("OpenGL ES (device max)") { am.deviceConfigurationInfo.glEsVersion }
        out += spec("OpenGL ES (context)") { gl?.version }
        out += spec("GLSL version") { gl?.glsl }
        out += spec("Vulkan API version") {
            pm.systemAvailableFeatures.firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION }?.let {
                val v = it.version
                "${v shr 22}.${(v shr 12) and 0x3ff}.${v and 0xfff}"
            }
        }
        out += spec("Vulkan hardware level") {
            pm.systemAvailableFeatures.firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL }?.version?.toString()
        }
        out += spec("OpenGL extensions") { gl?.extensions?.size?.takeIf { it > 0 }?.let { "$it (see list)" } }
        out += spec("Driver version", reason = "Android does not expose driver versions to apps") { null }
        return out
    }
}
