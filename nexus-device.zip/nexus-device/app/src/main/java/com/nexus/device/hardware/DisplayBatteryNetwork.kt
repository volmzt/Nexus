@file:Suppress("DEPRECATION")

package com.nexus.device.hardware

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.util.DisplayMetrics
import android.view.Display
import com.nexus.device.core.Availability
import com.nexus.device.core.Spec
import com.nexus.device.core.spec
import com.nexus.device.domain.Category
import com.nexus.device.domain.SpecProvider
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import kotlin.math.sqrt

class DisplayProvider(private val context: Context) : SpecProvider {
    override val category = Category.DISPLAY

    override fun read(): List<Spec> {
        val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
        val real = DisplayMetrics().also { display.getRealMetrics(it) }
        val res = context.resources.displayMetrics
        val out = mutableListOf<Spec>()
        out += Spec("Physical resolution", "${real.widthPixels} × ${real.heightPixels} px")
        out += Spec("Logical resolution", "${(res.widthPixels / res.density).toInt()} × ${(res.heightPixels / res.density).toInt()} dp")
        out += Spec("Density", "${res.densityDpi} dpi (scale ${String.format(Locale.US, "%.2f", res.density)})")
        out += spec("Measured pixel density") {
            if (real.xdpi > 0 && real.ydpi > 0) String.format(Locale.US, "%.0f × %.0f dpi", real.xdpi, real.ydpi) else null
        }
        out += spec("Diagonal", approximate = true, reason = "Panel size cannot be determined reliably") {
            if (real.xdpi > 50 && real.ydpi > 50) {
                val w = real.widthPixels / real.xdpi
                val h = real.heightPixels / real.ydpi
                String.format(Locale.US, "%.1f in (estimated from reported dpi)", sqrt(w * w + h * h))
            } else null
        }
        out += Spec("Refresh rate (current)", String.format(Locale.US, "%.1f Hz", display.refreshRate))
        val modes = display.supportedModes
        out += Spec("Refresh rate (max)", String.format(Locale.US, "%.1f Hz", modes.maxOf { it.refreshRate }))
        out += Spec("Supported modes", modes.joinToString("; ") { "${it.physicalWidth}×${it.physicalHeight}@${String.format(Locale.US, "%.0f", it.refreshRate)}" })
        val cfg = context.resources.configuration
        out += Spec("Orientation", if (cfg.orientation == Configuration.ORIENTATION_LANDSCAPE) "Landscape" else "Portrait")
        out += Spec("Aspect ratio", String.format(Locale.US, "%.2f : 1", maxOf(real.widthPixels, real.heightPixels).toDouble() / minOf(real.widthPixels, real.heightPixels)))
        out += Spec("Wide colour gamut", if (display.isWideColorGamut) "Yes" else "No")
        out += spec("HDR types") {
            val t = display.hdrCapabilities?.supportedHdrTypes
            if (t == null || t.isEmpty()) "None reported" else t.joinToString { hdrName(it) }
        }
        return out
    }

    private fun hdrName(t: Int): String = when (t) {
        1 -> "Dolby Vision"
        2 -> "HDR10"
        3 -> "HLG"
        4 -> "HDR10+"
        else -> "type $t"
    }
}

class BatteryProvider(private val context: Context) : SpecProvider {
    override val category = Category.BATTERY

    private fun BatteryManager.prop(id: Int): Int? = getIntProperty(id).takeIf { it != Int.MIN_VALUE && it != 0 }

    override fun read(): List<Spec> {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val out = mutableListOf<Spec>()
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else null
        out += spec("Level") { pct?.let { "$it %" } }
        out += spec("Status") {
            when (i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
                BatteryManager.BATTERY_STATUS_FULL -> "Full"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not charging"
                else -> null
            }
        }
        out += spec("Power source") {
            when (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)) {
                0 -> "Battery"
                BatteryManager.BATTERY_PLUGGED_AC -> "AC adapter"
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                null, -1 -> null
                else -> "Other"
            }
        }
        out += spec("Voltage") { i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)?.takeIf { it > 0 }?.let { "$it mV" } }
        out += spec("Temperature") {
            i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)?.takeIf { it != Int.MIN_VALUE }?.let { String.format(Locale.US, "%.1f °C", it / 10f) }
        }
        out += spec("Technology") { i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.takeIf { it.isNotBlank() } }
        out += spec("Health") {
            when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage"
                BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure"
                else -> null
            }
        }
        out += spec("Charge cycles", reason = "Not reported by this device (Android 14+ and vendor support needed)") {
            i?.getIntExtra("android.os.extra.CYCLE_COUNT", -1)?.takeIf { it > 0 }?.toString()
        }
        val counter = bm.prop(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        out += spec("Remaining charge") { counter?.let { "${it / 1000} mAh" } }
        out += spec("Estimated full capacity", approximate = true, reason = "Needs the charge counter and a level between 5 and 100 %") {
            if (counter != null && pct != null && pct in 5..100) "${counter * 100L / pct / 1000} mAh (software estimate, not a factory value)" else null
        }
        out += spec("Current now") { bm.prop(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)?.let { "${it / 1000} mA" } }
        out += Spec("Design capacity", "Android does not expose the factory capacity to apps", Availability.UNAVAILABLE)
        return out
    }
}

class NetworkProvider(private val context: Context) : SpecProvider {
    override val category = Category.NETWORK

    override fun read(): List<Spec> {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork
        val caps = net?.let { cm.getNetworkCapabilities(it) }
        val lp = net?.let { cm.getLinkProperties(it) }
        val out = mutableListOf<Spec>()
        out += Spec("Connection", if (net == null) "Offline" else "Connected")
        out += spec("Transport") {
            caps?.let {
                listOfNotNull(
                    "Wi-Fi".takeIf { _ -> it.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) },
                    "Cellular".takeIf { _ -> it.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) },
                    "Ethernet".takeIf { _ -> it.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) },
                    "VPN".takeIf { _ -> it.hasTransport(NetworkCapabilities.TRANSPORT_VPN) },
                    "Bluetooth".takeIf { _ -> it.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) },
                ).joinToString(", ").ifBlank { null }
            }
        }
        out += Spec(
            "Internet validated by Android",
            if (caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true) "Yes" else "No",
        )
        out += spec("Metered") { caps?.let { if (it.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) "No" else "Yes" } }
        out += spec("Downstream bandwidth (estimate)", approximate = true) { caps?.linkDownstreamBandwidthKbps?.takeIf { it > 0 }?.let { "${it / 1000} Mbps" } }
        out += spec("Upstream bandwidth (estimate)", approximate = true) { caps?.linkUpstreamBandwidthKbps?.takeIf { it > 0 }?.let { "${it / 1000} Mbps" } }
        out += spec("Interface") { lp?.interfaceName }
        out += spec("DNS servers") { lp?.dnsServers?.joinToString { it.hostAddress ?: "" }?.ifBlank { null } }
        out += spec("Local IP addresses", sensitive = true) {
            lp?.linkAddresses?.joinToString { it.address.hostAddress ?: "" }?.ifBlank { null }
        }
        out += spec("Network interfaces", sensitive = false) {
            NetworkInterface.getNetworkInterfaces()?.toList()?.filter { it.isUp && !it.isLoopback }
                ?.joinToString { ni -> ni.name + (ni.inetAddresses.toList().filterIsInstance<Inet4Address>().firstOrNull()?.let { " (IPv4)" } ?: "") }
        }
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val wi = if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) wm.connectionInfo else null
        out += spec("Wi-Fi frequency") { wi?.frequency?.takeIf { it > 0 }?.let { "$it MHz" } }
        out += spec("Wi-Fi link speed") { wi?.linkSpeed?.takeIf { it > 0 }?.let { "$it Mbps" } }
        out += spec("Wi-Fi signal (RSSI)") { wi?.rssi?.takeIf { it > -127 }?.let { "$it dBm" } }
        out += Spec("Wi-Fi SSID / BSSID", "Android hides these without the location permission, which this app does not request", Availability.PERMISSION)
        out += Spec("Mobile network type", "Needs the phone-state permission, which this app does not request", Availability.PERMISSION)
        return out
    }
}
