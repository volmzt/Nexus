package com.nexus.device.presentation.monitor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.presentation.SettingsViewModel
import com.nexus.device.presentation.ThrottleViewModel
import com.nexus.device.presentation.components.LineChart
import com.nexus.device.presentation.components.cardSurface
import com.nexus.device.presentation.device.DetailHeader
import kotlin.math.max

private val Good = Color(0xFF5BE37A)

/** The throttling test: all cores at full load, a graph of speed over time and a frequency graph for every core. */
@Composable
fun ThrottleScreen(
    thr: ThrottleViewModel,
    settingsVm: SettingsViewModel,
    unit: TempUnit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val t by thr.ui.collectAsStateWithLifecycle()
    val s by settingsVm.settings.collectAsStateWithLifecycle()

    // The screen stays on while the test runs, otherwise Android would put the phone to sleep.
    val view = LocalView.current
    DisposableEffect(t.running) {
        view.keepScreenOn = t.running
        onDispose { view.keepScreenOn = false }
    }

    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), state = rememberLazyListState(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { DetailHeader(stringResource(R.string.throttle), onBack) }

        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (!t.running) Button(onClick = { thr.start() }, Modifier.weight(1f)) { Text(stringResource(R.string.thr_start)) }
                else OutlinedButton(onClick = { thr.stop() }, Modifier.weight(1f)) { Text(stringResource(R.string.thr_stop)) }
                Text(
                    clock(t.seconds), style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.weight(1f),
                )
            }
        }

        item {
            Column(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.thr_graph), style = MaterialTheme.typography.titleMedium)
                PerformanceGraph(t.percent, Modifier.fillMaxWidth().height(180.dp))
                Text(
                    stringResource(R.string.thr_performance, Fmt.one(t.gops.toDouble())),
                    style = MaterialTheme.typography.titleLarge, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                )
                t.dropPercent?.let {
                    Text(
                        stringResource(R.string.thr_drop, Fmt.one(it.toDouble())),
                        style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                    )
                }
                t.stoppedHot?.let { Text(stringResource(R.string.thr_auto_stop, Fmt.one(it.toDouble())), color = MaterialTheme.colorScheme.error) }
            }
        }

        item {
            Column(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.thr_cores), style = MaterialTheme.typography.titleMedium)
                if (t.cores.isEmpty()) {
                    Text(
                        stringResource(if (t.running || t.seconds > 0) R.string.thr_cores_hidden else R.string.thr_cores_idle),
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    t.cores.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { c -> CoreGraph(c, t.maxGhz, Modifier.weight(1f)) }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    if (t.maxGhz > 0f) Text(stringResource(R.string.thr_max_clock, Fmt.one(t.maxGhz.toDouble())), color = Good, style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        item {
            Column(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.thr_temp_chart), style = MaterialTheme.typography.titleMedium)
                if (t.battery.size >= 2 || t.cpu.size >= 2) {
                    val b = t.battery.map { Fmt.tempValue(it, unit) }
                    val c = t.cpu.map { Fmt.tempValue(it, unit) }
                    LineChart(listOf(b, c), Modifier.fillMaxWidth().height(100.dp), maxPoints = max(60, max(b.size, c.size)))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        t.battery.lastOrNull()?.let { Text(stringResource(R.string.temp_battery) + " " + Fmt.temp(it, unit), style = MaterialTheme.typography.bodyMedium) }
                        t.cpu.lastOrNull()?.let { Text(stringResource(R.string.temp_cpu) + " " + Fmt.temp(it, unit), style = MaterialTheme.typography.bodyMedium) }
                    }
                } else {
                    Text(stringResource(R.string.thr_cores_idle), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item {
            Column(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.thr_limit), style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(40, 43, 45, 48, 50).forEach { v ->
                        FilterChip(selected = s.stopTempC == v, onClick = { settingsVm.setStopTemp(v) }, label = { Text("$v°") })
                    }
                }
                Text(stringResource(R.string.throttle_desc), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { Spacer(Modifier.height(100.dp)) }
    }
}

private fun clock(seconds: Int): String = "%02d:%02d".format(seconds / 60, seconds % 60)

/** Speed as a share of the best second. Starts at the left and grows to the right; every 10th second has a line. */
@Composable
private fun PerformanceGraph(percent: List<Float>, modifier: Modifier) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    val label = MaterialTheme.colorScheme.onSurfaceVariant
    Row(modifier) {
        Column(Modifier.height(180.dp).padding(end = 6.dp), verticalArrangement = Arrangement.SpaceBetween) {
            listOf("100%", "50%", "0").forEach { Text(it, style = MaterialTheme.typography.labelSmall, color = label) }
        }
        Canvas(Modifier.weight(1f).fillMaxSize()) {
            for (g in 0..4) {
                val y = size.height * g / 4f
                drawLine(grid, Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
            }
            val window = max(60, percent.size)
            for (g in 1 until 6) {
                val x = size.width * g / 6f
                drawLine(grid.copy(alpha = 0.5f), Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
            }
            if (percent.size < 2) return@Canvas
            val line = Path()
            percent.forEachIndexed { i, v ->
                val x = size.width * i / (window - 1).toFloat()
                val y = size.height * (1f - v.coerceIn(0f, 100f) / 100f)
                if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
            }
            val lastX = size.width * (percent.size - 1) / (window - 1).toFloat()
            val area = Path().apply { addPath(line); lineTo(lastX, size.height); lineTo(0f, size.height); close() }
            drawPath(area, Brush.verticalGradient(listOf(Good.copy(alpha = 0.75f), Good.copy(alpha = 0.12f))))
            drawPath(line, Good, style = Stroke(2.dp.toPx()))
        }
    }
}

/** One core: its frequency in GHz and a small graph scaled to the highest clock on the chip. */
@Composable
private fun CoreGraph(history: List<Float>, maxGhz: Float, modifier: Modifier) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            history.lastOrNull()?.let { Fmt.one(it.toDouble()) + " GHz" } ?: "—",
            style = MaterialTheme.typography.labelMedium, color = Good, maxLines = 1,
        )
        Box(Modifier.fillMaxWidth().height(56.dp).cardSurface(RoundedCornerShape(8.dp))) {
            Canvas(Modifier.fillMaxSize()) {
                drawLine(grid, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), 1.dp.toPx())
                if (history.size < 2 || maxGhz <= 0f) return@Canvas
                val line = Path()
                history.forEachIndexed { i, v ->
                    val x = size.width * (i + 60 - history.size) / 59f
                    val y = size.height * (1f - (v / maxGhz).coerceIn(0f, 1f))
                    if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
                }
                drawPath(line, Good, style = Stroke(2.dp.toPx()))
            }
        }
    }
}
