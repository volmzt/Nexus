package com.nexus.device.bench

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.benchStore by preferencesDataStore(name = "nexus_bench")

/** The last 30 complete runs, newest first. Stored on this device only. */
class BenchStore(private val context: Context) {
    private val key = stringPreferencesKey("runs")

    val runs: Flow<List<BenchRun>> = context.benchStore.data.map { decode(it[key]) }

    suspend fun add(run: BenchRun) {
        context.benchStore.edit { p -> p[key] = encode((listOf(run) + decode(p[key])).take(30)) }
    }

    suspend fun clear() {
        context.benchStore.edit { it.remove(key) }
    }

    private fun encode(list: List<BenchRun>): String {
        val arr = JSONArray()
        list.forEach { r ->
            val o = JSONObject().put("t", r.time)
            r.battStartC?.let { o.put("bs", it.toDouble()) }
            r.battEndC?.let { o.put("be", it.toDouble()) }
            r.cpuStartC?.let { o.put("cs", it.toDouble()) }
            r.cpuEndC?.let { o.put("ce", it.toDouble()) }
            val tests = JSONArray()
            r.scores.forEach { tests.put(JSONObject().put("id", it.id).put("v", it.value).put("p", it.points)) }
            arr.put(o.put("s", tests))
        }
        return arr.toString()
    }

    private fun decode(text: String?): List<BenchRun> {
        if (text.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(text)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val s = o.getJSONArray("s")
                fun f(k: String): Float? = if (o.has(k)) o.getDouble(k).toFloat() else null
                BenchRun(
                    time = o.getLong("t"),
                    scores = (0 until s.length()).mapNotNull { j ->
                        val t = s.getJSONObject(j)
                        if (Catalog.get(t.getString("id")) == null) null
                        else TestScore(t.getString("id"), t.getDouble("v"), t.getInt("p"))
                    },
                    battStartC = f("bs"), battEndC = f("be"), cpuStartC = f("cs"), cpuEndC = f("ce"),
                )
            }
        }.getOrDefault(emptyList())
    }
}
