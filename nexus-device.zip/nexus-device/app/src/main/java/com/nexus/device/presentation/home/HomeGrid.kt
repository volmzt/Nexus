package com.nexus.device.presentation.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.nexus.device.R
import com.nexus.device.data.BgPalette
import com.nexus.device.data.HomeBlock
import com.nexus.device.data.HomeBlocks
import com.nexus.device.presentation.theme.LocalCornerScale
import com.nexus.device.presentation.theme.auroraColors
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** Where a block is on screen and how big it currently is, kept outside the composition so it survives a block moving. */
internal class BlockMotion {
    var pos: Offset? = null
    var size: IntSize = IntSize.Zero
    val anim = Animatable(Offset.Zero, Offset.VectorConverter)
    var aw: Animatable<Float, AnimationVector1D>? = null
    var ah: Animatable<Float, AnimationVector1D>? = null
    var tw = 0
    var th = 0
}

/**
 * The blocks of the Home screen. Small blocks share a row two by two, medium and large ones take the whole row.
 * While editing, a block jiggles, can be dragged after a long press (the others glide out of the way), removed
 * with the cross, and resized with the handle in its corner; resizing is a spring, so the neighbours flow around it.
 */
@Composable
internal fun HomeGrid(
    blocks: List<HomeBlock>,
    editing: Boolean,
    palette: BgPalette,
    data: HomeData,
    onChange: (List<HomeBlock>) -> Unit,
    onCommit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val motions = remember { HashMap<String, BlockMotion>() }
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    val cur by rememberUpdatedState(blocks)
    val change by rememberUpdatedState(onChange)
    val commit by rememberUpdatedState(onCommit)

    // One clock for the outline shimmer and the jiggle. It only ticks while editing, so Home is idle otherwise.
    val tick = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(editing) {
        if (editing) {
            val t0 = withFrameNanos { it }
            while (true) withFrameNanos { n -> tick.floatValue = (n - t0) / 1_000_000_000f }
        }
    }
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val colors = remember(palette, dark) {
        // Bright, but still the hue of the chosen background, so the outline is visible without clashing with it.
        auroraColors(palette, true).map { if (dark) lerp(it, Color.White, 0.55f) else lerp(it, Color.Black, 0.2f) }
    }

    Layout(
        content = {
            blocks.forEach { b ->
                key(b.id) {
                    val motion = motions.getOrPut(b.id) { BlockMotion() }
                    Frame(
                        block = b, editing = editing, dragging = dragId == b.id, motion = motion, tick = tick, colors = colors, data = data,
                        dragOffset = { dragTotal + dragStart - (motion.pos ?: dragStart) },
                        onDragStart = { dragId = b.id; dragTotal = Offset.Zero; dragStart = motion.pos ?: Offset.Zero },
                        onDrag = { delta ->
                            dragTotal += delta
                            val centre = dragStart + dragTotal + Offset(motion.size.width / 2f, motion.size.height / 2f)
                            val list = cur
                            val from = list.indexOfFirst { it.id == b.id }
                            val to = list.indexOfFirst { o ->
                                val m = motions[o.id]
                                val p = m?.pos
                                o.id != b.id && m != null && p != null &&
                                    centre.x >= p.x && centre.x <= p.x + m.size.width && centre.y >= p.y && centre.y <= p.y + m.size.height
                            }
                            if (from >= 0 && to >= 0) {
                                val moved = list.toMutableList()
                                moved.add(to, moved.removeAt(from))
                                change(moved)
                            }
                        },
                        onDragEnd = { dragId = null; commit() },
                        onRemove = { change(cur.filter { it.id != b.id }); commit() },
                        onResize = { step -> change(cur.map { if (it.id == b.id) it.copy(size = (it.size + step).coerceIn(HomeBlocks.SMALL, HomeBlocks.LARGE)) else it }) },
                        onResizeEnd = { commit() },
                    )
                }
            }
        },
        modifier = modifier.fillMaxWidth(),
    ) { measurables, constraints ->
        val gap = 8.dp.roundToPx()
        val full = constraints.maxWidth
        val half = (full - gap) / 2
        // Blocks get a loose width and size themselves (they animate between sizes).
        val loose = Constraints(maxWidth = full)
        val placed = ArrayList<Triple<Placeable, Int, Int>>()
        var y = 0
        var i = 0
        while (i < measurables.size) {
            if (blocks[i].size == HomeBlocks.SMALL) {
                val a = measurables[i].measure(loose)
                val pairWith = i + 1 < measurables.size && blocks[i + 1].size == HomeBlocks.SMALL
                val b = if (pairWith) measurables[i + 1].measure(loose) else null
                placed.add(Triple(a, 0, y))
                if (b != null) placed.add(Triple(b, half + gap, y))
                y += max(a.height, b?.height ?: 0) + gap
                i += if (b != null) 2 else 1
            } else {
                val p = measurables[i].measure(loose)
                placed.add(Triple(p, 0, y))
                y += p.height + gap
                i++
            }
        }
        layout(full, (y - gap).coerceAtLeast(0)) { placed.forEach { (p, x, py) -> p.place(x, py) } }
    }
}

@Composable
private fun Frame(
    block: HomeBlock,
    editing: Boolean,
    dragging: Boolean,
    motion: BlockMotion,
    tick: FloatState,
    colors: List<Color>,
    data: HomeData,
    dragOffset: () -> Offset,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onRemove: () -> Unit,
    onResize: (Int) -> Unit,
    onResizeEnd: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val radius = (24 * LocalCornerScale.current).dp
    val dragStartS by rememberUpdatedState(onDragStart)
    val dragS by rememberUpdatedState(onDrag)
    val dragEndS by rememberUpdatedState(onDragEnd)
    val resizeS by rememberUpdatedState(onResize)
    val resizeEndS by rememberUpdatedState(onResizeEnd)
    val small = block.size == HomeBlocks.SMALL
    val seed = remember(block.id) { (block.id.hashCode() and 0xff) / 255f }
    // 0 → 1 when editing starts: the outline fades in, the cross and the handle pop in with a little overshoot.
    val edit = animateFloatAsState(if (editing) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 330f), label = "edit")
    val lift = animateFloatAsState(if (dragging) 1.05f else 1f, spring(dampingRatio = 0.7f, stiffness = 500f), label = "lift")
    val flipThreshold = with(density) { 48.dp.toPx() }
    val sizeSpring = spring<Float>(dampingRatio = 0.82f, stiffness = 420f)

    Layout(
        content = {
            Box {
                AnimatedContent(
                    targetState = block.size,
                    transitionSpec = { (fadeIn(tween(240)) togetherWith fadeOut(tween(140))).using(SizeTransform(clip = false) { _, _ -> snap() }) },
                    label = "blockSize",
                ) { s -> BlockBody(block.id, s, data) }
            }
            Box(Modifier.fillMaxSize()) {
                Canvas(
                    Modifier.fillMaxSize().graphicsLayer { alpha = edit.value.coerceIn(0f, 1f) },
                ) {
                    if (edit.value > 0.01f) {
                        val w = size.width
                        val x0 = (tick.floatValue / 3.2f % 1f) * w * 2f
                        val brush = Brush.linearGradient(colors, start = Offset(x0 - w, 0f), end = Offset(x0, size.height), tileMode = TileMode.Mirror)
                        drawRoundRect(brush, cornerRadius = CornerRadius(radius.toPx()), style = Stroke(2.dp.toPx()))
                    }
                }
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp).size(26.dp)
                        .graphicsLayer { val e = edit.value; scaleX = e; scaleY = e; alpha = e.coerceIn(0f, 1f) }
                        .clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .border(1.dp, colors.first(), CircleShape)
                        .clickable(enabled = editing, onClickLabel = stringResource(R.string.home_remove), onClick = onRemove),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Close, stringResource(R.string.home_remove), Modifier.size(14.dp)) }

                val handle = colors.last()
                Canvas(
                    Modifier.align(Alignment.BottomEnd).padding(6.dp).size(30.dp)
                        .graphicsLayer { alpha = edit.value.coerceIn(0f, 1f) }
                        .then(
                            if (editing) Modifier.pointerInput(block.id) {
                                var acc = 0f
                                detectDragGestures(
                                    onDragStart = { acc = 0f },
                                    onDragEnd = { resizeEndS() },
                                    onDragCancel = { resizeEndS() },
                                ) { change, amount ->
                                    change.consume()
                                    acc += amount.x + amount.y
                                    val step = 56.dp.toPx()
                                    if (acc > step) { resizeS(1); acc = 0f } else if (acc < -step) { resizeS(-1); acc = 0f }
                                }
                            } else Modifier,
                        ),
                ) {
                    // A quarter circle in the corner, like the resize handle of a HyperOS folder.
                    drawArc(
                        handle, startAngle = 0f, sweepAngle = 90f, useCenter = false,
                        topLeft = Offset(-size.width * 0.9f, -size.height * 0.9f), size = Size(size.width * 1.8f, size.height * 1.8f),
                        style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }
        },
        modifier = Modifier
            .zIndex(if (dragging) 1f else 0f)
            // Measured before graphicsLayer, so the position is the layout position without the animation offset.
            .onGloballyPositioned { c ->
                val p = c.positionInParent()
                val old = motion.pos
                motion.size = c.size
                // Only a real jump (another row or column) is animated; the small shifts of a resize are already smooth.
                if (old != null && !dragging && (old - p).getDistance() > flipThreshold) {
                    scope.launch {
                        motion.anim.snapTo(motion.anim.value + (old - p))
                        motion.anim.animateTo(Offset.Zero, spring(dampingRatio = 0.8f, stiffness = 380f))
                    }
                }
                motion.pos = p
            }
            .pointerInput(editing) {
                if (editing) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { dragStartS() },
                        onDrag = { change, amount -> change.consume(); dragS(amount) },
                        onDragEnd = { dragEndS() },
                        onDragCancel = { dragEndS() },
                    )
                }
            }
            .graphicsLayer {
                val t = motion.anim.value + if (dragging) dragOffset() else Offset.Zero
                translationX = t.x
                translationY = t.y
                scaleX = lift.value
                scaleY = lift.value
                // The little iPhone-style shake: every block has its own phase so they never move in step.
                rotationZ = if (dragging) 0f else sin((tick.floatValue / 0.26f + seed) * 2f * PI.toFloat()) * 0.55f * edit.value.coerceIn(0f, 1f)
            },
    ) { ms, c ->
        val gap = 8.dp.roundToPx()
        val tw = if (small) (c.maxWidth - gap) / 2 else c.maxWidth
        val body = ms[0].measure(Constraints(minWidth = tw, maxWidth = tw))
        val th = body.height
        val aw = motion.aw ?: Animatable(tw.toFloat()).also { motion.aw = it }
        val ah = motion.ah ?: Animatable(th.toFloat()).also { motion.ah = it }
        if (motion.tw != tw || motion.th != th) {
            val first = motion.tw == 0
            motion.tw = tw
            motion.th = th
            if (!first) {
                scope.launch { aw.animateTo(tw.toFloat(), sizeSpring) }
                scope.launch { ah.animateTo(th.toFloat(), sizeSpring) }
            }
        }
        val w = aw.value.roundToInt().coerceIn(1, c.maxWidth)
        val h = ah.value.roundToInt().coerceAtLeast(1)
        val overlay = ms[1].measure(Constraints.fixed(w, h))
        layout(w, h) {
            // The block is laid out at its final size and stretched to the animated one, so the card grows smoothly.
            body.placeWithLayer(0, 0) {
                transformOrigin = TransformOrigin(0f, 0f)
                scaleX = w.toFloat() / max(1, tw)
                scaleY = h.toFloat() / max(1, th)
            }
            overlay.place(0, 0)
        }
    }
}
