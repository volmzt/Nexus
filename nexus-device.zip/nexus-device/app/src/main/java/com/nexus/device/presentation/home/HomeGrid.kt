package com.nexus.device.presentation.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.nexus.device.R
import com.nexus.device.data.BgPalette
import com.nexus.device.data.HomeBlock
import com.nexus.device.data.HomeBlocks
import com.nexus.device.presentation.theme.LocalCornerScale
import com.nexus.device.presentation.theme.auroraColors
import kotlinx.coroutines.launch
import kotlin.math.max

/** Where a block is on screen, kept outside the composition so it survives a block moving to another row. */
internal class BlockMotion {
    var pos: Offset? = null
    var size: IntSize = IntSize.Zero
    val anim = Animatable(Offset.Zero, Offset.VectorConverter)
}

/**
 * The blocks of the Home screen. Small blocks share a row two by two, medium and large ones take the whole row.
 * While editing, a block can be dragged after a long press (the others glide out of the way), removed with the
 * cross, and resized with the handle in its corner.
 */
@Composable
internal fun HomeGrid(
    blocks: List<HomeBlock>,
    editing: Boolean,
    palette: BgPalette,
    data: HomeData,
    onChange: (List<HomeBlock>) -> Unit,
    onCommit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val motions = remember { HashMap<String, BlockMotion>() }
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    val cur by rememberUpdatedState(blocks)
    val change by rememberUpdatedState(onChange)
    val commit by rememberUpdatedState(onCommit)

    val phase = rememberInfiniteTransition(label = "outline").animateFloat(
        0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "outlinePhase",
    )
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val colors = remember(palette, dark) {
        // Bright, but still the hue of the chosen background, so the outline is visible without clashing with it.
        auroraColors(palette, true).map { if (dark) lerp(it, Color.White, 0.55f) else lerp(it, Color.Black, 0.2f) }
    }

    Layout(
        content = {
            blocks.forEach { b ->
                key(b.id) {
                    val motion = motions.getOrPut(b.id) { BlockMotion() }
                    Frame(
                        block = b, editing = editing, dragging = dragId == b.id, motion = motion, phase = phase, colors = colors, data = data,
                        dragOffset = { dragTotal + dragStart - (motion.pos ?: dragStart) },
                        onDragStart = { dragId = b.id; dragTotal = Offset.Zero; dragStart = motion.pos ?: Offset.Zero },
                        onDrag = { delta ->
                            dragTotal += delta
                            val centre = dragStart + dragTotal + Offset(motion.size.width / 2f, motion.size.height / 2f)
                            val list = cur
                            val from = list.indexOfFirst { it.id == b.id }
                            val to = list.indexOfFirst { o ->
                                val m = motions[o.id]
                                val p = m?.pos
                                o.id != b.id && m != null && p != null &&
                                    centre.x >= p.x && centre.x <= p.x + m.size.width && centre.y >= p.y && centre.y <= p.y + m.size.height
                            }
                            if (from >= 0 && to >= 0) {
                                val moved = list.toMutableList()
                                moved.add(to, moved.removeAt(from))
                                change(moved)
                            }
                        },
                        onDragEnd = { dragId = null; commit() },
                        onRemove = { change(cur.filter { it.id != b.id }); commit() },
                        onResize = { step -> change(cur.map { if (it.id == b.id) it.copy(size = (it.size + step).coerceIn(HomeBlocks.SMALL, HomeBlocks.LARGE)) else it }) },
                        onResizeEnd = { commit() },
                    )
                }
            }
        },
        modifier = modifier.fillMaxWidth(),
    ) { measurables, constraints ->
        val gap = 8.dp.roundToPx()
        val full = constraints.maxWidth
        val half = (full - gap) / 2
        val placed = ArrayList<Triple<Placeable, Int, Int>>()
        var y = 0
        var i = 0
        while (i < measurables.size) {
            if (blocks[i].size == HomeBlocks.SMALL) {
                val a = measurables[i].measure(Constraints(minWidth = half, maxWidth = half))
                val pairWith = i + 1 < measurables.size && blocks[i + 1].size == HomeBlocks.SMALL
                val b = if (pairWith) measurables[i + 1].measure(Constraints(minWidth = half, maxWidth = half)) else null
                placed.add(Triple(a, 0, y))
                if (b != null) placed.add(Triple(b, half + gap, y))
                y += max(a.height, b?.height ?: 0) + gap
                i += if (b != null) 2 else 1
            } else {
                val p = measurables[i].measure(Constraints(minWidth = full, maxWidth = full))
                placed.add(Triple(p, 0, y))
                y += p.height + gap
                i++
            }
        }
        layout(full, (y - gap).coerceAtLeast(0)) { placed.forEach { (p, x, py) -> p.place(x, py) } }
    }
}

@Composable
private fun Frame(
    block: HomeBlock,
    editing: Boolean,
    dragging: Boolean,
    motion: BlockMotion,
    phase: State<Float>,
    colors: List<Color>,
    data: HomeData,
    dragOffset: () -> Offset,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onRemove: () -> Unit,
    onResize: (Int) -> Unit,
    onResizeEnd: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val radius = (24 * LocalCornerScale.current).dp
    val dragStartS by rememberUpdatedState(onDragStart)
    val dragS by rememberUpdatedState(onDrag)
    val dragEndS by rememberUpdatedState(onDragEnd)
    val resizeS by rememberUpdatedState(onResize)
    val resizeEndS by rememberUpdatedState(onResizeEnd)

    Box(
        Modifier
            .zIndex(if (dragging) 1f else 0f)
            // Measured before graphicsLayer, so the position is the layout position without the animation offset.
            .onGloballyPositioned { c ->
                val p = c.positionInParent()
                val old = motion.pos
                motion.size = c.size
                if (old != null && !dragging && (old - p).getDistance() > 1f) {
                    scope.launch {
                        motion.anim.snapTo(motion.anim.value + (old - p))
                        motion.anim.animateTo(Offset.Zero, spring(dampingRatio = 0.8f, stiffness = 380f))
                    }
                }
                motion.pos = p
            }
            .pointerInput(editing) {
                if (editing) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { dragStartS() },
                        onDrag = { change, amount -> change.consume(); dragS(amount) },
                        onDragEnd = { dragEndS() },
                        onDragCancel = { dragEndS() },
                    )
                }
            }
            .graphicsLayer {
                val t = motion.anim.value + if (dragging) dragOffset() else Offset.Zero
                translationX = t.x
                translationY = t.y
                val s = if (dragging) 1.04f else 1f
                scaleX = s
                scaleY = s
            },
    ) {
        Box(
            Modifier.fillMaxWidth().drawWithContent {
                drawContent()
                if (editing) {
                    val w = size.width
                    val x0 = phase.value * w * 2f
                    val brush = Brush.linearGradient(colors, start = Offset(x0 - w, 0f), end = Offset(x0, size.height), tileMode = TileMode.Mirror)
                    drawRoundRect(brush, cornerRadius = CornerRadius(radius.toPx()), style = Stroke(2.dp.toPx()))
                }
            },
        ) {
            AnimatedContent(
                targetState = block.size,
                transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
                label = "blockSize",
            ) { s -> BlockBody(block.id, s, data) }

            if (editing) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp).size(26.dp)
                        .clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .border(1.dp, colors.first(), CircleShape)
                        .clickable(onClickLabel = stringResource(R.string.home_remove), onClick = onRemove),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Close, stringResource(R.string.home_remove), Modifier.size(14.dp)) }

                val handle = colors.last()
                Canvas(
                    Modifier.align(Alignment.BottomEnd).padding(6.dp).size(30.dp)
                        .pointerInput(block.id) {
                            var acc = 0f
                            detectDragGestures(
                                onDragStart = { acc = 0f },
                                onDragEnd = { resizeEndS() },
                                onDragCancel = { resizeEndS() },
                            ) { change, amount ->
                                change.consume()
                                acc += amount.x + amount.y
                                val step = 90.dp.toPx()
                                if (acc > step) { resizeS(1); acc = 0f } else if (acc < -step) { resizeS(-1); acc = 0f }
                            }
                        },
                ) {
                    // A quarter circle in the corner, like the resize handle of a HyperOS folder.
                    drawArc(
                        handle, startAngle = 0f, sweepAngle = 90f, useCenter = false,
                        topLeft = Offset(-size.width * 0.9f, -size.height * 0.9f), size = Size(size.width * 1.8f, size.height * 1.8f),
                        style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }
        }
    }
}
