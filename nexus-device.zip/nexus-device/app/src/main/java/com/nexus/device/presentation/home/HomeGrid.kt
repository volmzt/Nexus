package com.nexus.device.presentation.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.nexus.device.R
import com.nexus.device.data.BgPalette
import com.nexus.device.data.HomeBlock
import com.nexus.device.data.HomeBlocks
import com.nexus.device.presentation.theme.LocalCornerScale
import com.nexus.device.presentation.theme.auroraColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

// One timing for everything that moves, so a block that grows and the blocks that make room for it travel together.
private const val MOVE_MS = 140
private val MoveEasing = FastOutSlowInEasing
private val GAP = 8.dp
private val UNIT = 112.dp

/** Height of one cell; it grows with the text size so bigger text still fits. */
private fun Density.unitPx(): Float = UNIT.toPx() * fontScale.coerceIn(1f, 1.4f)

/** Where a block is on screen and how big it currently is, kept outside the composition so it survives a block moving. */
internal class BlockMotion {
    /** The cell the block belongs to (where the grid wants it), used to find the block under a dragged one. */
    var pos: Offset? = null
    var size: IntSize = IntSize.Zero
    var resizing = false

    // The glide from one cell to another. It is worked out at the moment the grid is laid out, so a block never shows up
    // for a frame at its new place before it starts to travel there.
    var from = Offset.Zero
    var to = Offset.Zero
    var t0 = 0L
    var placedOnce = false
    var releaseFrom: Offset? = null
    /** How far the block is pushed down (or pulled up) by a block above it that is being resized. */
    var pushY = 0f
    /** The block was widened over its left neighbour with the left handle: it stays anchored to the right edge until it is shrunk again. */
    var anchorRight = false
    /** The block it stood after before it was widened, so shrinking puts it back in the right column. */
    var afterId: String? = null
    /** Held while the handle of a right-hand block is dragged: the right edge stays on the screen edge. */
    var mirror = false
    /** Whether the block sits in the right column and is one cell wide, so its handle goes to the left corner. */
    var rightCol by mutableStateOf(false)

    fun at(now: Long): Offset {
        val p = ((now - t0) / (MOVE_MS * 1_000_000f)).coerceIn(0f, 1f)
        return from + (to - from) * MoveEasing.transform(p)
    }

    fun moving(now: Long): Boolean = now - t0 < MOVE_MS * 1_000_000L
    var aw: Animatable<Float, AnimationVector1D>? = null
    var ah: Animatable<Float, AnimationVector1D>? = null
    var tw = 0
    var th = 0
}

/**
 * The blocks of the Home screen. Small blocks share a row two by two, medium and large ones take the whole row.
 * While editing, a block jiggles, can be dragged after a long press (the others glide out of the way), removed
 * with the cross, and resized with the handle in its corner; resizing is a spring, so the neighbours flow around it.
 */
@Composable
internal fun HomeGrid(
    blocks: List<HomeBlock>,
    editing: Boolean,
    plain: Boolean,
    palette: BgPalette,
    data: HomeData,
    onChange: (List<HomeBlock>) -> Unit,
    onCommit: () -> Unit,
    scroll: androidx.compose.foundation.ScrollState,
    viewport: () -> androidx.compose.ui.geometry.Rect,
    modifier: Modifier = Modifier,
) {
    val motions = remember { HashMap<String, BlockMotion>() }
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    val swapMark = remember { floatArrayOf(Float.NaN, Float.NaN) }
    val swappedWith = remember { arrayOf<String?>(null) }
    // The block the dragged one hovers over and since when: a swap needs a short, steady hover, so passing over a block does not reflow the grid.
    val hoverId = remember { arrayOf<String?>(null) }
    val hoverT = remember { longArrayOf(0L) }
    val swapGap = with(LocalDensity.current) { 44.dp.toPx() }
    val halfGap = with(LocalDensity.current) { GAP.toPx() } / 2f
    val cur by rememberUpdatedState(blocks)
    val scope = rememberCoroutineScope()
    // Frame clock for the glides. It runs only while some block is travelling.
    val clock = remember { mutableLongStateOf(0L) }
    val clockRunning = remember { booleanArrayOf(false) }
    fun kick() {
        if (clockRunning[0]) return
        clockRunning[0] = true
        scope.launch {
            try {
                while (true) {
                    val n = withFrameNanos { it }
                    clock.longValue = n
                    if (motions.values.none { it.moving(n) }) break
                }
            } finally {
                clockRunning[0] = false
            }
        }
    }
    val change by rememberUpdatedState(onChange)
    val commit by rememberUpdatedState(onCommit)

    // One step of a drag: the block follows the finger and trades places with whichever block its centre is over.
    fun drag(b: HomeBlock, motion: BlockMotion, delta: Offset) {
                dragTotal += delta
                val centre = dragStart + dragTotal + Offset(motion.size.width / 2f, motion.size.height / 2f)
                val list = cur
                val from = list.indexOfFirst { it.id == b.id }
                val to = list.indexOfFirst { o ->
                    val m = motions[o.id]
                    val p = m?.pos
                    o.id != b.id && m != null && p != null &&
                        // The whole cell counts, plus half of the gap around it: with a dead strip between blocks a
                        // drag through the middle found nothing to swap with.
                        centre.x >= p.x - halfGap && centre.x <= p.x + m.size.width + halfGap &&
                        centre.y >= p.y - halfGap && centre.y <= p.y + m.size.height + halfGap
                }
                // After a swap the finger has to travel a little before the next one, or fast drags make blocks flicker back and forth.
                val toId = list.getOrNull(to)?.id
                // Swapping straight back with the block just swapped needs a real move; any other block is taken at once.
                // After any swap the blocks reflow, and the centre can land on yet another block (a wide block moves its neighbours a
                // whole row); the finger has to travel before the next swap, whichever block it is over, or they stick like a magnet.
                val settled = swapMark[0].isNaN() || (centre - Offset(swapMark[0], swapMark[1])).getDistance() > swapGap
                val nowH = System.nanoTime()
                if (toId != hoverId[0]) { hoverId[0] = toId; hoverT[0] = nowH }
                val dwelled = nowH - hoverT[0] >= 90_000_000L
                if (from >= 0 && to >= 0 && settled && dwelled) {
                    hoverId[0] = null
                    swapMark[0] = centre.x; swapMark[1] = centre.y; swappedWith[0] = toId
                    val moved = list.toMutableList()
                    if (list[from].size == list[to].size) {
                        // Same shape: the two simply trade cells, nothing else on the screen moves.
                        moved[from] = list[to]; moved[to] = list[from]
                    } else {
                        moved.add(to, moved.removeAt(from))
                    }
                    change(moved)
                }
    }

    // Dragging a block to the edge of the screen scrolls the page. The speed grows smoothly with how far the block has gone
    // into the edge zone and drops to nothing the moment it leaves, so the page never runs away. The block stays under
    // the finger because every step of the scroll is added to the drag.
    val gridCoords = remember { arrayOfNulls<androidx.compose.ui.layout.LayoutCoordinates>(1) }
    val density = LocalDensity.current
    LaunchedEffect(dragId) {
        val id = dragId ?: return@LaunchedEffect
        val zone = with(density) { 96.dp.toPx() }
        val navH = with(density) { 112.dp.toPx() }
        val vmax = with(density) { 820.dp.toPx() }
        var last = withFrameNanos { it }
        while (true) {
            val n = withFrameNanos { it }
            val dt = ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
            last = n
            val m = motions[id] ?: continue
            // Every frame, so a swap also happens when the finger rests on a block for the hover time.
            drag(cur.firstOrNull { it.id == id } ?: continue, m, Offset.Zero)
            val c = gridCoords[0]
            if (c == null || !c.isAttached) continue
            val vp = viewport()
            if (vp.height <= 0f) continue
            val top = c.positionInRoot().y + dragStart.y + dragTotal.y
            val bottom = top + m.size.height
            val effBottom = vp.bottom - navH
            val down = ((bottom - (effBottom - zone)) / zone).coerceIn(0f, 1f)
            val up = (((vp.top + zone) - top) / zone).coerceIn(0f, 1f)
            val k = if (down > up) down else -up
            if (k == 0f) continue
            val ease = kotlin.math.abs(k).let { it * it }
            val used = scroll.scrollBy(vmax * ease * dt * (if (k < 0f) -1f else 1f))
            if (used != 0f) drag(cur.firstOrNull { it.id == id } ?: continue, m, Offset(0f, used))
        }
    }

    // One clock for the outline shimmer and the jiggle. It only ticks while editing, so Home is idle otherwise.
    val tick = remember { mutableFloatStateOf(0f) }
    // The outline shimmer is slow, so it is redrawn at 20 fps; the jiggle needs every frame.
    val shimmer = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(editing, plain) {
        if (editing && !plain) {
            val t0 = withFrameNanos { it }
            var lastShimmer = 0L
            while (true) withFrameNanos { n ->
                val t = (n - t0) / 1_000_000_000f
                tick.floatValue = t
                if (n - lastShimmer > 50_000_000L) { shimmer.floatValue = t; lastShimmer = n }
            }
        }
    }
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val colors = remember(palette, dark) {
        // Bright, but still the hue of the chosen background, so the outline is visible without clashing with it.
        auroraColors(palette, true).map { if (dark) lerp(it, Color.White, 0.55f) else lerp(it, Color.Black, 0.2f) }
    }

    Layout(
        content = {
            blocks.forEach { b ->
                key(b.id) {
                    val motion = motions.getOrPut(b.id) { BlockMotion() }
                    if (HomeBlocks.isGap(b.id)) GapCell(b, motion, editing) { change(cur.filter { it.id != b.id }); commit() } else Frame(
                        block = b, editing = editing, dragging = dragId == b.id, calm = dragId != null, plain = plain, motion = motion, tick = tick, shimmer = shimmer, colors = colors, data = data,
                        onDragStart = { dragId = b.id; dragTotal = Offset.Zero; dragStart = motion.at(System.nanoTime()); swapMark[0] = Float.NaN; swappedWith[0] = null; hoverId[0] = null },
                        onDrag = { delta -> drag(b, motion, delta) },
                        onDragEnd = { motion.releaseFrom = dragStart + dragTotal; dragId = null; commit() },
                        onRemove = { change(cur.filter { it.id != b.id }); commit() },
                        onResize = { size, mirror ->
                            val list = cur
                            val idx = list.indexOfFirst { it.id == b.id }
                            if (idx >= 0 && list[idx].size != size) {
                                var out = list.map { if (it.id == b.id) it.copy(size = size) else it }
                                if (mirror) {
                                    val wide = HomeBlocks.cols(size) == 2
                                    val mo = motions[b.id]
                                    if (mo != null && wide && !mo.anchorRight) {
                                        // Widening to the left takes the whole row: the block goes in front of the one it covers.
                                        val me = mo.pos
                                        val j = (idx - 1 downTo 0).firstOrNull { k ->
                                            val p = motions[list[k].id]?.pos
                                            p != null && me != null && p.x == 0f && p.y == me.y && HomeBlocks.cols(list[k].size) == 1
                                        }
                                        if (j != null) {
                                            mo.anchorRight = true; mo.afterId = list[j].id
                                            val m = out.toMutableList(); m.add(j, m.removeAt(idx)); out = m
                                        }
                                    } else if (mo != null && !wide && mo.anchorRight) {
                                        // Shrinking again puts the block back after the one it had covered, in the right column.
                                        val m = out.toMutableList()
                                        val at = m.indexOfFirst { it.id == b.id }
                                        val me = m.removeAt(at)
                                        val after = m.indexOfFirst { it.id == mo.afterId }
                                        m.add(if (after >= 0) after + 1 else at.coerceAtMost(m.size), me); out = m
                                        mo.anchorRight = false; mo.afterId = null
                                    }
                                }
                                change(out)
                            }
                        },
                        onResizeEnd = { commit() },
                    )
                }
            }
        },
        modifier = modifier.fillMaxWidth().onGloballyPositioned { gridCoords[0] = it },
    ) { measurables, constraints ->
        val gap = GAP.roundToPx()
        val unit = unitPx().roundToInt()
        val full = constraints.maxWidth
        val colW = (full - gap) / 2
        // Blocks size themselves (they animate between sizes); here only the cells they occupy are decided.
        val loose = Constraints(maxWidth = full)
        // Two columns of cells. Each block takes the first free spot that fits it, scanning row by row.
        val taken = ArrayList<BooleanArray>()
        fun free(r: Int, c: Int, w: Int, h: Int): Boolean {
            for (rr in r until r + h) for (cc in c until c + w) if (rr < taken.size && taken[rr][cc]) return false
            return true
        }
        val placed = ArrayList<Pair<Placeable, BlockMotion>>()
        val colOf = IntArray(measurables.size)
        val rowOf = IntArray(measurables.size)
        val targetOf = Array(measurables.size) { Offset.Zero }
        val grabbedId = dragId
        var rowsUsed = 0
        measurables.forEachIndexed { i, m ->
            val w = HomeBlocks.cols(blocks[i].size)
            val h = HomeBlocks.rows(blocks[i].size)
            var r = 0
            var col = -1
            while (col < 0) {
                for (c in 0..(2 - w)) if (free(r, c, w, h)) { col = c; break }
                if (col < 0) r++
            }
            while (taken.size < r + h) taken.add(BooleanArray(2))
            for (rr in r until r + h) for (cc in col until col + w) taken[rr][cc] = true
            rowsUsed = max(rowsUsed, r + h)
            colOf[i] = col; rowOf[i] = r
            val target = Offset((col * (colW + gap)).toFloat(), (r * (unit + gap)).toFloat())
            val mo = motions.getOrPut(blocks[i].id) { BlockMotion() }
            targetOf[i] = target
            val rc = w == 1 && col == 1
            if (mo.rightCol != rc) mo.rightCol = rc
            mo.pos = target
            placed.add(Pair(m.measure(loose), mo))
        }
        // A block being resized pushes the blocks below it in its columns by exactly as much as it has grown past its cell (or
        // pulls them up as much as it has shrunk), so the space between them stays the same as when everything stands still.
        var extra = 0f
        placed.forEach { it.second.pushY = 0f }
        placed.forEachIndexed { i, (_, mo) ->
            if (!mo.resizing || blocks[i].id == grabbedId || plain) return@forEachIndexed
            val wR = HomeBlocks.cols(blocks[i].size)
            val hR = HomeBlocks.rows(blocks[i].size)
            val push = mo.size.height - (hR * unit + (hR - 1) * gap).toFloat()
            if (kotlin.math.abs(push) < 0.5f) return@forEachIndexed
            placed.forEachIndexed { j, (_, other) ->
                if (j == i || blocks[j].id == grabbedId) return@forEachIndexed
                val wJ = HomeBlocks.cols(blocks[j].size)
                val sameColumns = colOf[j] < colOf[i] + wR && colOf[i] < colOf[j] + wJ
                if (sameColumns && rowOf[j] >= rowOf[i] + hR) other.pushY += push
            }
        }
        placed.forEach { extra = max(extra, it.second.pushY) }
        // A block that is being pushed is placed exactly at its cell plus the push: the push already moves in step with the
        // block that causes it, so gliding on top of it would only shoot the block past its place.
        placed.forEachIndexed { i, (_, mo) ->
            val target = targetOf[i]
            val nowN = System.nanoTime()
            val rel = mo.releaseFrom
            when {
                plain -> { mo.from = target; mo.to = target; mo.t0 = 0L; mo.releaseFrom = null }
                mo.pushY != 0f && rel == null -> { mo.from = target; mo.to = target; mo.t0 = 0L }
                rel != null -> { mo.from = rel; mo.to = target; mo.t0 = nowN; mo.releaseFrom = null; kick() }
                !mo.placedOnce || blocks[i].id == grabbedId -> { mo.from = target; mo.to = target; mo.t0 = 0L }
                mo.to != target -> { mo.from = mo.at(nowN); mo.to = target; mo.t0 = nowN; kick() }
            }
            mo.placedOnce = true
        }
        layout(full, (if (rowsUsed == 0) 0 else rowsUsed * (unit + gap) - gap) + extra.roundToInt()) {
            val now = clock.longValue
            placed.forEachIndexed { i, (p, mo) ->
                if (grabbedId != null && blocks[i].id == grabbedId) {
                    // The block under the finger is placed straight at the finger, so it follows without a frame of delay.
                    val d = dragStart + dragTotal
                    p.place(d.x.roundToInt(), d.y.roundToInt(), 2f)
                } else {
                    val o = mo.at(now)
                    val px = if (mo.mirror && mo.resizing) full - p.width else o.x.roundToInt()
                    p.place(px, (o.y + mo.pushY).roundToInt(), if (mo.resizing) 2f else if (mo.moving(now)) 1f else 0f)
                }
            }
        }
    }
}

@Composable
private fun Frame(
    block: HomeBlock,
    editing: Boolean,
    dragging: Boolean,
    calm: Boolean,
    plain: Boolean,
    motion: BlockMotion,
    tick: FloatState,
    shimmer: FloatState,
    colors: List<Color>,
    data: HomeData,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onRemove: () -> Unit,
    onResize: (Int, Boolean) -> Unit,
    onResizeEnd: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val backing = MaterialTheme.colorScheme.surfaceContainerHigh
    var live by remember { mutableStateOf<IntSize?>(null) }
    var lock by remember { mutableStateOf<Boolean?>(null) }
    val left = lock ?: ((motion.rightCol && HomeBlocks.cols(block.size) == 1) || (motion.anchorRight && HomeBlocks.cols(block.size) == 2))
    val leftNow by rememberUpdatedState(left)
    val density = LocalDensity.current
    val radius = (24 * LocalCornerScale.current).dp
    val dragStartS by rememberUpdatedState(onDragStart)
    val dragS by rememberUpdatedState(onDrag)
    val dragEndS by rememberUpdatedState(onDragEnd)
    val resizeS by rememberUpdatedState(onResize)
    val resizeEndS by rememberUpdatedState(onResizeEnd)
    val blockNow by rememberUpdatedState(block)
    val seed = remember(block.id) { (block.id.hashCode() and 0xff) / 255f }
    // 0 → 1 when editing starts: the outline fades in, the cross and the handle pop in with a little overshoot.
    val edit = animateFloatAsState(if (editing) 1f else 0f, if (plain) snap() else spring(dampingRatio = 0.6f, stiffness = 330f), label = "edit")
    val lift = animateFloatAsState(if (dragging && !plain) 1.05f else 1f, if (plain) snap() else spring(dampingRatio = 0.7f, stiffness = 500f), label = "lift")
    val sizeSpec: AnimationSpec<Float> = if (plain) snap() else tween(MOVE_MS, easing = MoveEasing)
    // What the block shows follows the size it has right now, not the one it is heading to, so the content never
    // looks squeezed into a frame meant for something else; it changes once, half way through the move.
    val gapPx = with(density) { GAP.roundToPx() }
    val cellPx = density.unitPx()
    val shown by remember {
        derivedStateOf {
            val tw = motion.tw
            val target = blockNow.size
            if (tw == 0) target else {
                val l = live
                val w = l?.width?.toFloat() ?: motion.aw?.value ?: tw.toFloat()
                val h = l?.height?.toFloat() ?: motion.ah?.value ?: motion.th.toFloat()
                val full = if (HomeBlocks.cols(target) == 2) tw.toFloat() else tw * 2f + gapPx
                val col = (full - gapPx) / 2f
                HomeBlocks.make(if (w > (col + full) / 2f) 2 else 1, ((h + gapPx) / (cellPx + gapPx)).roundToInt())
            }
        }
    }
    val calmAmp = animateFloatAsState(if (calm) 0f else 1f, tween(160), label = "calm")
    // While editing, a press needs only a moment before the block can be dragged.
    val vc = LocalViewConfiguration.current
    val quick = remember(vc) { object : ViewConfiguration by vc { override val longPressTimeoutMillis: Long get() = 160L } }

    CompositionLocalProvider(LocalViewConfiguration provides (if (editing) quick else vc)) {
    Layout(
        content = {
            Box(
                Modifier.clipToBounds().drawBehind {
                    // While editing every block has a solid backing, so blocks sliding over each other never show through one another.
                    // It fades in with the edit mode instead of switching on and off while blocks move, which looked like flicker.
                    val e = edit.value
                    if (e > 0.01f) drawRoundRect(backing, cornerRadius = CornerRadius(radius.toPx()), alpha = e.coerceIn(0f, 1f))
                },
            ) {
                BlockBody(block.id, shown, data)
            }
            Box(Modifier.fillMaxSize()) {
                Canvas(
                    Modifier.fillMaxSize().graphicsLayer { alpha = edit.value.coerceIn(0f, 1f) },
                ) {
                    if (edit.value > 0.01f) {
                        val w = size.width
                        val x0 = (shimmer.floatValue / 3.2f % 1f) * w * 2f
                        val brush = Brush.linearGradient(colors, start = Offset(x0 - w, 0f), end = Offset(x0, size.height), tileMode = TileMode.Mirror)
                        drawRoundRect(brush, cornerRadius = CornerRadius(radius.toPx()), style = Stroke(2.dp.toPx()))
                    }
                }
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp).size(26.dp)
                        .graphicsLayer { val e = edit.value; scaleX = e; scaleY = e; alpha = e.coerceIn(0f, 1f) }
                        .clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .border(1.dp, colors.first(), CircleShape)
                        .clickable(enabled = editing, onClickLabel = stringResource(R.string.home_remove), onClick = onRemove),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Close, stringResource(R.string.home_remove), Modifier.size(14.dp)) }

                val handle = colors.last()
                Canvas(
                    Modifier.align(if (left) Alignment.BottomStart else Alignment.BottomEnd).padding(6.dp).size(30.dp)
                        .graphicsLayer { alpha = edit.value.coerceIn(0f, 1f) }
                        .then(
                            if (editing) Modifier.pointerInput(block.id) {
                                val unitPx = unitPx()
                                val gapPx = GAP.toPx()
                                var dx = 0f
                                var dy = 0f
                                var baseW = 0f
                                var baseH = 0f
                                var fullPx = 0f
                                var mirrorNow = false
                                fun finish() {
                                    // On release the block takes the cell size nearest to where the finger left it, so a light
                                    // touch on the handle never changes the size, even if the others had already stepped aside.
                                    live?.let { l ->
                                        val colPx = (fullPx - gapPx) / 2f
                                        val cols = if (l.width > (colPx + fullPx) / 2f) 2 else 1
                                        val rows = (1..3).minByOrNull { r -> kotlin.math.abs(l.height - (r * unitPx + (r - 1) * gapPx)) } ?: 1
                                        resizeS(HomeBlocks.make(cols, rows), mirrorNow)
                                    }
                                    resizeEndS()
                                    scope.launch {
                                        val l = live
                                        val aw = motion.aw
                                        val ah = motion.ah
                                        if (l != null && aw != null && ah != null) {
                                            // Hand over from the finger to the animation at exactly the size the finger left.
                                            aw.snapTo(l.width.toFloat())
                                            ah.snapTo(l.height.toFloat())
                                            live = null
                                            launch { aw.animateTo(motion.tw.toFloat(), sizeSpec) }
                                            ah.animateTo(motion.th.toFloat(), sizeSpec)
                                        } else live = null
                                        // A right-hand block keeps its right edge on the screen edge until it has settled.
                                        delay(MOVE_MS + 80L)
                                        lock = null; motion.mirror = false
                                    }
                                }
                                detectDragGestures(
                                    onDragStart = {
                                        dx = 0f; dy = 0f
                                        mirrorNow = leftNow
                                        lock = leftNow; motion.mirror = leftNow
                                        baseW = motion.size.width.toFloat(); baseH = motion.size.height.toFloat()
                                        fullPx = if (HomeBlocks.cols(blockNow.size) == 2) motion.tw.toFloat() else motion.tw * 2f + gapPx
                                        live = IntSize(baseW.roundToInt(), baseH.roundToInt())
                                    },
                                    onDragEnd = { finish() },
                                    onDragCancel = { finish() },
                                ) { change, amount ->
                                    change.consume()
                                    dx += amount.x; dy += amount.y
                                    // The block follows the finger exactly. The others leave when its edge reaches them (a few dp
                                    // early, so they are already on their way at the moment of contact), and come back a little
                                    // later than they left, so the size does not flicker on the border.
                                    val colPx = (fullPx - gapPx) / 2f
                                    val lw = (baseW + (if (mirrorNow) -dx else dx)).coerceIn(colPx, fullPx)
                                    val lh = (baseH + dy).coerceIn(unitPx, 3 * unitPx + 2 * gapPx)
                                    live = IntSize(lw.roundToInt(), lh.roundToInt())
                                    // The others leave just before the edge touches them. Coming back needs the corner a little
                                    // nearer to the smaller cell than going out did, but still inside what the finger can reach.
                                    val out = gapPx - 3.dp.toPx()
                                    val back = 1.dp.toPx()
                                    val nowCols = HomeBlocks.cols(blockNow.size)
                                    val nowRows = HomeBlocks.rows(blockNow.size)
                                    // Width: the others step aside when the edge touches them, and the block then opens to the full width.
                                    val cols = if (nowCols == 2) (if (lw <= colPx + back) 1 else 2) else (if (lw > colPx + out) 2 else 1)
                                    // Height: the cell count changes only when the block has filled the next cell completely; until then
                                    // the blocks below follow its bottom edge.
                                    fun cellsH(r: Int) = r * unitPx + (r - 1) * gapPx
                                    val snapPx = 2.dp.toPx()
                                    var rows = nowRows
                                    while (rows < 3 && lh >= cellsH(rows + 1) - snapPx) rows++
                                    if (rows == nowRows) while (rows > 1 && lh <= cellsH(rows - 1) + snapPx) rows--
                                    resizeS(HomeBlocks.make(cols, rows), mirrorNow)
                                }
                            } else Modifier,
                        ),
                ) {
                    // A quarter circle in the corner, like the resize handle of a HyperOS folder.
                    scale(if (left) -1f else 1f, 1f, pivot = center) {
                        drawArc(
                            handle, startAngle = 0f, sweepAngle = 90f, useCenter = false,
                            topLeft = Offset(-size.width * 0.9f, -size.height * 0.9f), size = Size(size.width * 1.8f, size.height * 1.8f),
                            style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
                        )
                    }
                }
            }
        },
        modifier = Modifier
            .pointerInput(editing) {
                if (editing) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { dragStartS() },
                        onDrag = { change, amount -> change.consume(); dragS(amount) },
                        onDragEnd = { dragEndS() },
                        onDragCancel = { dragEndS() },
                    )
                }
            }
            .graphicsLayer {
                scaleX = lift.value
                scaleY = lift.value
                // The little iPhone-style shake: every block has its own phase so they never move in step.
                val k = edit.value.coerceIn(0f, 1f) * calmAmp.value
                rotationZ = if (k <= 0.001f) 0f else sin((tick.floatValue / 0.26f + seed) * 2f * PI.toFloat()) * 0.55f * k
            },
    ) { ms, c ->
        val gap = GAP.roundToPx()
        val unit = unitPx().roundToInt()
        val cols = HomeBlocks.cols(block.size)
        val rows = HomeBlocks.rows(block.size)
        val tw = if (cols == 2) c.maxWidth else (c.maxWidth - gap) / 2
        val th = rows * unit + (rows - 1) * gap
        val aw = motion.aw ?: Animatable(tw.toFloat()).also { motion.aw = it }
        val ah = motion.ah ?: Animatable(th.toFloat()).also { motion.ah = it }
        val l = live
        if (motion.tw != tw || motion.th != th) {
            val first = motion.tw == 0
            motion.tw = tw
            motion.th = th
            if (!first && l == null) {
                scope.launch { aw.animateTo(tw.toFloat(), sizeSpec) }
                scope.launch { ah.animateTo(th.toFloat(), sizeSpec) }
            }
        }
        val w = (l?.width ?: aw.value.roundToInt()).coerceIn(1, c.maxWidth)
        val h = (l?.height ?: ah.value.roundToInt()).coerceAtLeast(1)
        // The block is laid out at exactly the size it has right now, so its text and charts re-flow while it grows.
        val body = ms[0].measure(Constraints.fixed(w, h))
        val overlay = ms[1].measure(Constraints.fixed(w, h))
        motion.size = IntSize(w, h)
        motion.resizing = l != null || aw.isRunning || ah.isRunning
        layout(w, h) {
            body.place(0, 0)
            overlay.place(0, 0)
        }
    }
    }
}


/** An empty cell: invisible outside editing, a faint outline while editing (tap to remove it). Blocks can be dragged onto it. */
@Composable
private fun GapCell(block: HomeBlock, motion: BlockMotion, editing: Boolean, onRemove: () -> Unit) {
    val shape = androidx.compose.foundation.shape.RoundedCornerShape((24 * LocalCornerScale.current).dp)
    val line = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val mod = if (editing) Modifier.clip(shape).border(1.dp, line, shape).clickable(onClickLabel = stringResource(R.string.home_remove), onClick = onRemove) else Modifier
    Layout(content = {}, modifier = mod) { _, c ->
        val gap = GAP.roundToPx()
        val unit = unitPx().roundToInt()
        val cols = HomeBlocks.cols(block.size)
        val rows = HomeBlocks.rows(block.size)
        val w = if (cols == 2) c.maxWidth else (c.maxWidth - gap) / 2
        val h = rows * unit + (rows - 1) * gap
        motion.size = IntSize(w, h)
        layout(w, h) {}
    }
}
