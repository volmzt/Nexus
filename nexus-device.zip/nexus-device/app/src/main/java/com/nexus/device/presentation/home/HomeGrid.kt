package com.nexus.device.presentation.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.nexus.device.R
import com.nexus.device.data.BgPalette
import com.nexus.device.data.HomeBlock
import com.nexus.device.data.HomeBlocks
import com.nexus.device.presentation.theme.LocalCornerScale
import com.nexus.device.presentation.theme.auroraColors
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

private val GAP = 8.dp
private val UNIT = 112.dp

/** Where a block is on screen and how big it currently is, kept outside the composition so it survives a block moving. */
internal class BlockMotion {
    var pos: Offset? = null
    var size: IntSize = IntSize.Zero
    val anim = Animatable(Offset.Zero, Offset.VectorConverter)
    var aw: Animatable<Float, AnimationVector1D>? = null
    var ah: Animatable<Float, AnimationVector1D>? = null
    var tw = 0
    var th = 0
}

/**
 * The blocks of the Home screen. Small blocks share a row two by two, medium and large ones take the whole row.
 * While editing, a block jiggles, can be dragged after a long press (the others glide out of the way), removed
 * with the cross, and resized with the handle in its corner; resizing is a spring, so the neighbours flow around it.
 */
@Composable
internal fun HomeGrid(
    blocks: List<HomeBlock>,
    editing: Boolean,
    palette: BgPalette,
    data: HomeData,
    onChange: (List<HomeBlock>) -> Unit,
    onCommit: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val motions = remember { HashMap<String, BlockMotion>() }
    var dragId by remember { mutableStateOf<String?>(null) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    val swapMark = remember { floatArrayOf(Float.NaN, Float.NaN) }
    val swapGap = with(LocalDensity.current) { 44.dp.toPx() }
    val cur by rememberUpdatedState(blocks)
    val change by rememberUpdatedState(onChange)
    val commit by rememberUpdatedState(onCommit)

    // One clock for the outline shimmer and the jiggle. It only ticks while editing, so Home is idle otherwise.
    val tick = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(editing) {
        if (editing) {
            val t0 = withFrameNanos { it }
            while (true) withFrameNanos { n -> tick.floatValue = (n - t0) / 1_000_000_000f }
        }
    }
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val colors = remember(palette, dark) {
        // Bright, but still the hue of the chosen background, so the outline is visible without clashing with it.
        auroraColors(palette, true).map { if (dark) lerp(it, Color.White, 0.55f) else lerp(it, Color.Black, 0.2f) }
    }

    Layout(
        content = {
            blocks.forEach { b ->
                key(b.id) {
                    val motion = motions.getOrPut(b.id) { BlockMotion() }
                    Frame(
                        block = b, editing = editing, dragging = dragId == b.id, calm = dragId != null, motion = motion, tick = tick, colors = colors, data = data,
                        onDragStart = { dragId = b.id; dragTotal = Offset.Zero; dragStart = motion.pos ?: Offset.Zero; swapMark[0] = Float.NaN },
                        onDrag = { delta ->
                            dragTotal += delta
                            val centre = dragStart + dragTotal + Offset(motion.size.width / 2f, motion.size.height / 2f)
                            val list = cur
                            val from = list.indexOfFirst { it.id == b.id }
                            val to = list.indexOfFirst { o ->
                                val m = motions[o.id]
                                val p = m?.pos
                                o.id != b.id && m != null && p != null &&
                                    centre.x >= p.x && centre.x <= p.x + m.size.width && centre.y >= p.y && centre.y <= p.y + m.size.height
                            }
                            // After a swap the finger has to travel a little before the next one, or fast drags make blocks flicker back and forth.
                            val settled = swapMark[0].isNaN() || (centre - Offset(swapMark[0], swapMark[1])).getDistance() > swapGap
                            if (from >= 0 && to >= 0 && settled) {
                                swapMark[0] = centre.x; swapMark[1] = centre.y
                                val moved = list.toMutableList()
                                moved.add(to, moved.removeAt(from))
                                change(moved)
                            }
                        },
                        onDragEnd = { dragId = null; commit() },
                        onRemove = { change(cur.filter { it.id != b.id }); commit() },
                        onResize = { size -> if (cur.any { it.id == b.id && it.size != size }) change(cur.map { if (it.id == b.id) it.copy(size = size) else it }) },
                        onResizeEnd = { commit() },
                    )
                }
            }
        },
        modifier = modifier.fillMaxWidth(),
    ) { measurables, constraints ->
        val gap = GAP.roundToPx()
        val unit = UNIT.roundToPx()
        val full = constraints.maxWidth
        val colW = (full - gap) / 2
        // Blocks size themselves (they animate between sizes); here only the cells they occupy are decided.
        val loose = Constraints(maxWidth = full)
        // Two columns of cells. Each block takes the first free spot that fits it, scanning row by row.
        val taken = ArrayList<BooleanArray>()
        fun free(r: Int, c: Int, w: Int, h: Int): Boolean {
            for (rr in r until r + h) for (cc in c until c + w) if (rr < taken.size && taken[rr][cc]) return false
            return true
        }
        val placed = ArrayList<Triple<Placeable, Int, Int>>()
        var rowsUsed = 0
        measurables.forEachIndexed { i, m ->
            val w = HomeBlocks.cols(blocks[i].size)
            val h = HomeBlocks.rows(blocks[i].size)
            var r = 0
            var col = -1
            while (col < 0) {
                for (c in 0..(2 - w)) if (free(r, c, w, h)) { col = c; break }
                if (col < 0) r++
            }
            while (taken.size < r + h) taken.add(BooleanArray(2))
            for (rr in r until r + h) for (cc in col until col + w) taken[rr][cc] = true
            rowsUsed = max(rowsUsed, r + h)
            placed.add(Triple(m.measure(loose), col * (colW + gap), r * (unit + gap)))
        }
        layout(full, if (rowsUsed == 0) 0 else rowsUsed * (unit + gap) - gap) {
            // The block under the finger is placed straight at the finger, so it follows without a frame of delay.
            val grabbed = dragId
            placed.forEachIndexed { i, (p, x, py) ->
                if (grabbed != null && blocks[i].id == grabbed) {
                    val d = dragStart + dragTotal
                    p.place(d.x.roundToInt(), d.y.roundToInt())
                } else p.place(x, py)
            }
        }
    }
}

@Composable
private fun Frame(
    block: HomeBlock,
    editing: Boolean,
    dragging: Boolean,
    calm: Boolean,
    motion: BlockMotion,
    tick: FloatState,
    colors: List<Color>,
    data: HomeData,
    onDragStart: () -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onRemove: () -> Unit,
    onResize: (Int) -> Unit,
    onResizeEnd: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val backing = MaterialTheme.colorScheme.surfaceContainerHigh
    val density = LocalDensity.current
    val radius = (24 * LocalCornerScale.current).dp
    val dragStartS by rememberUpdatedState(onDragStart)
    val dragS by rememberUpdatedState(onDrag)
    val dragEndS by rememberUpdatedState(onDragEnd)
    val resizeS by rememberUpdatedState(onResize)
    val resizeEndS by rememberUpdatedState(onResizeEnd)
    val blockNow by rememberUpdatedState(block)
    val seed = remember(block.id) { (block.id.hashCode() and 0xff) / 255f }
    // 0 → 1 when editing starts: the outline fades in, the cross and the handle pop in with a little overshoot.
    val edit = animateFloatAsState(if (editing) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 330f), label = "edit")
    val lift = animateFloatAsState(if (dragging) 1.05f else 1f, spring(dampingRatio = 0.7f, stiffness = 500f), label = "lift")
    val sizeSpring = spring<Float>(dampingRatio = 1f, stiffness = 520f)

    Layout(
        content = {
            Box(
                Modifier.clipToBounds().drawBehind {
                    // While a block moves it gets a solid backing, so blocks sliding over each other never show through one another.
                    if (dragging || motion.anim.value.getDistance() > 0.5f) {
                        drawRoundRect(backing, cornerRadius = CornerRadius(radius.toPx()))
                    }
                },
            ) {
                BlockBody(block.id, block.size, data)
            }
            Box(Modifier.fillMaxSize()) {
                Canvas(
                    Modifier.fillMaxSize().graphicsLayer { alpha = edit.value.coerceIn(0f, 1f) },
                ) {
                    if (edit.value > 0.01f) {
                        val w = size.width
                        val x0 = (tick.floatValue / 3.2f % 1f) * w * 2f
                        val brush = Brush.linearGradient(colors, start = Offset(x0 - w, 0f), end = Offset(x0, size.height), tileMode = TileMode.Mirror)
                        drawRoundRect(brush, cornerRadius = CornerRadius(radius.toPx()), style = Stroke(2.dp.toPx()))
                    }
                }
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp).size(26.dp)
                        .graphicsLayer { val e = edit.value; scaleX = e; scaleY = e; alpha = e.coerceIn(0f, 1f) }
                        .clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .border(1.dp, colors.first(), CircleShape)
                        .clickable(enabled = editing, onClickLabel = stringResource(R.string.home_remove), onClick = onRemove),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Close, stringResource(R.string.home_remove), Modifier.size(14.dp)) }

                val handle = colors.last()
                Canvas(
                    Modifier.align(Alignment.BottomEnd).padding(6.dp).size(30.dp)
                        .graphicsLayer { alpha = edit.value.coerceIn(0f, 1f) }
                        .then(
                            if (editing) Modifier.pointerInput(block.id) {
                                var dx = 0f
                                var dy = 0f
                                var startCols = 1
                                var startRows = 1
                                detectDragGestures(
                                    onDragStart = {
                                        dx = 0f; dy = 0f
                                        startCols = HomeBlocks.cols(blockNow.size); startRows = HomeBlocks.rows(blockNow.size)
                                    },
                                    onDragEnd = { resizeEndS() },
                                    onDragCancel = { resizeEndS() },
                                ) { change, amount ->
                                    change.consume()
                                    dx += amount.x; dy += amount.y
                                    // Dragging the corner changes the size cell by cell, like the folders in HyperOS.
                                    val colStep = (motion.tw.coerceAtLeast(1) / startCols).toFloat()
                                    val cols = when {
                                        startCols == 1 && dx > colStep * 0.4f -> 2
                                        startCols == 2 && dx < -colStep * 0.2f -> 1
                                        else -> startCols
                                    }
                                    val rows = (startRows + (dy / (UNIT.toPx() + GAP.toPx())).roundToInt()).coerceIn(1, 3)
                                    resizeS(HomeBlocks.make(cols, rows))
                                }
                            } else Modifier,
                        ),
                ) {
                    // A quarter circle in the corner, like the resize handle of a HyperOS folder.
                    drawArc(
                        handle, startAngle = 0f, sweepAngle = 90f, useCenter = false,
                        topLeft = Offset(-size.width * 0.9f, -size.height * 0.9f), size = Size(size.width * 1.8f, size.height * 1.8f),
                        style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }
        },
        modifier = Modifier
            .zIndex(if (dragging) 1f else 0f)
            // Measured before graphicsLayer, so the position is the layout position without the animation offset.
            .onGloballyPositioned { c ->
                val p = c.positionInParent()
                val old = motion.pos
                motion.size = c.size
                // Every move to another cell glides there on a spring.
                if (old != null && !dragging && (old - p).getDistance() > 1f) {
                    scope.launch {
                        motion.anim.snapTo(motion.anim.value + (old - p))
                        motion.anim.animateTo(Offset.Zero, tween(220, easing = FastOutSlowInEasing))
                    }
                }
                motion.pos = p
            }
            .pointerInput(editing) {
                if (editing) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { dragStartS() },
                        onDrag = { change, amount -> change.consume(); dragS(amount) },
                        onDragEnd = { dragEndS() },
                        onDragCancel = { dragEndS() },
                    )
                }
            }
            .graphicsLayer {
                val t = motion.anim.value
                translationX = t.x
                translationY = t.y
                scaleX = lift.value
                scaleY = lift.value
                // The little iPhone-style shake: every block has its own phase so they never move in step.
                rotationZ = if (dragging || calm) 0f else sin((tick.floatValue / 0.26f + seed) * 2f * PI.toFloat()) * 0.55f * edit.value.coerceIn(0f, 1f)
            },
    ) { ms, c ->
        val gap = GAP.roundToPx()
        val unit = UNIT.roundToPx()
        val cols = HomeBlocks.cols(block.size)
        val rows = HomeBlocks.rows(block.size)
        val tw = if (cols == 2) c.maxWidth else (c.maxWidth - gap) / 2
        val th = rows * unit + (rows - 1) * gap
        val aw = motion.aw ?: Animatable(tw.toFloat()).also { motion.aw = it }
        val ah = motion.ah ?: Animatable(th.toFloat()).also { motion.ah = it }
        if (motion.tw != tw || motion.th != th) {
            val first = motion.tw == 0
            motion.tw = tw
            motion.th = th
            if (!first) {
                scope.launch { aw.animateTo(tw.toFloat(), sizeSpring) }
                scope.launch { ah.animateTo(th.toFloat(), sizeSpring) }
            }
        }
        val w = aw.value.roundToInt().coerceIn(1, c.maxWidth)
        val h = ah.value.roundToInt().coerceAtLeast(1)
        // The block is laid out at exactly the size it has right now, so its text and charts re-flow while it grows.
        val body = ms[0].measure(Constraints.fixed(w, h))
        val overlay = ms[1].measure(Constraints.fixed(w, h))
        layout(w, h) {
            body.place(0, 0)
            overlay.place(0, 0)
        }
    }
}
