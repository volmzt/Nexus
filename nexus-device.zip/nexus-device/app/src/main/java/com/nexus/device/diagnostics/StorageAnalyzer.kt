package com.nexus.device.diagnostics

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.security.MessageDigest

data class FileEntry(val name: String, val size: Long, val ext: String)
data class ExtStat(val ext: String, val count: Int, val bytes: Long)
data class DupGroup(val size: Long, val names: List<String>)
data class AnalysisResult(
    val scanned: Int,
    val totalBytes: Long,
    val largest: List<FileEntry>,
    val extensions: List<ExtStat>,
    val duplicates: List<DupGroup>,
    val truncated: Boolean,
)

/**
 * Works only inside a folder the user picked with the Storage Access Framework.
 * The app never asks for all-files access.
 */
object StorageAnalyzer {
    private const val MAX_FILES = 40_000
    private const val MAX_HASH_BYTES = 200L * 1024 * 1024
    private const val MAX_HASH_GROUPS = 300

    suspend fun analyze(context: Context, tree: Uri, onProgress: (Int) -> Unit): AnalysisResult =
        withContext(Dispatchers.IO) {
            val root = DocumentFile.fromTreeUri(context, tree) ?: throw IllegalStateException("Cannot open this folder")
            val files = ArrayList<DocumentFile>()
            val stack = ArrayDeque<DocumentFile>()
            stack.add(root)
            var truncated = false
            while (stack.isNotEmpty() && !truncated) {
                ensureActive()
                val dir = stack.removeLast()
                for (f in dir.listFiles()) {
                    if (f.isDirectory) stack.add(f) else files.add(f)
                    if (files.size >= MAX_FILES) { truncated = true; break }
                }
                onProgress(files.size)
            }
            val entries = files.map { f ->
                val name = f.name ?: "?"
                FileEntry(name, f.length(), name.substringAfterLast('.', "").lowercase().ifBlank { "(none)" })
            }
            val largest = entries.sortedByDescending { it.size }.take(50)
            val exts = entries.groupBy { it.ext }.map { (e, l) -> ExtStat(e, l.size, l.sumOf { it.size }) }.sortedByDescending { it.bytes }

            // Duplicates: same size first, then SHA-256 for candidates only.
            val bySize = files.indices.groupBy { entries[it].size }.filter { it.key > 0 && it.value.size > 1 && it.key <= MAX_HASH_BYTES }
            val dups = ArrayList<DupGroup>()
            for ((size, idxs) in bySize.entries.sortedByDescending { it.key }.take(MAX_HASH_GROUPS)) {
                ensureActive()
                val byHash = HashMap<String, MutableList<String>>()
                for (i in idxs) {
                    val h = hash(context, files[i].uri) ?: continue
                    byHash.getOrPut(h) { mutableListOf() }.add(entries[i].name)
                }
                byHash.values.filter { it.size > 1 }.forEach { dups.add(DupGroup(size, it)) }
            }
            AnalysisResult(entries.size, entries.sumOf { it.size }, largest, exts, dups.sortedByDescending { it.size * it.names.size }, truncated)
        }

    private fun hash(context: Context, uri: Uri): String? {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val stream = context.contentResolver.openInputStream(uri) ?: return null
            stream.use { inp ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            null
        }
    }
}
