// Intentionally empty: the storage analyzer was removed in 0.4.0. This file can be deleted from the repository.
