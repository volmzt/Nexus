package com.nexus.device.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "benchmark_results")
data class BenchmarkResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val testId: String,
    val value: Double,
    val unit: String,
    val timestamp: Long,
)

@Entity(tableName = "monitor_sessions")
data class MonitorSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAt: Long,
    val durationMs: Long,
    val samples: Int,
    val ramAvg: Double,
    val ramMax: Double,
    val tempMax: Double?,
    val batteryStart: Int?,
    val batteryEnd: Int?,
)

@Entity(tableName = "battery_samples")
data class BatterySampleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val level: Int,
    val tempC: Float?,
    val voltageMv: Int?,
    val charging: Boolean,
)

@Dao
interface BatteryDao {
    @Insert suspend fun insert(s: BatterySampleEntity)
    @Query("SELECT * FROM battery_samples WHERE timestamp >= :since ORDER BY timestamp ASC") fun observeSince(since: Long): Flow<List<BatterySampleEntity>>
    @Query("DELETE FROM battery_samples WHERE timestamp < :before") suspend fun prune(before: Long)
    @Query("DELETE FROM battery_samples") suspend fun clear()
}

@Dao
interface BenchmarkDao {
    @Insert suspend fun insert(r: BenchmarkResultEntity)
    @Query("SELECT * FROM benchmark_results ORDER BY timestamp DESC") fun observeAll(): Flow<List<BenchmarkResultEntity>>
    @Query("DELETE FROM benchmark_results") suspend fun clear()
}

@Dao
interface SessionDao {
    @Insert suspend fun insert(s: MonitorSessionEntity)
    @Query("SELECT * FROM monitor_sessions ORDER BY startedAt DESC") fun observeAll(): Flow<List<MonitorSessionEntity>>
    @Query("DELETE FROM monitor_sessions") suspend fun clear()
}

@Database(entities = [BenchmarkResultEntity::class, MonitorSessionEntity::class, BatterySampleEntity::class], version = 2, exportSchema = false)
abstract class NexusDatabase : RoomDatabase() {
    abstract fun benchmarkDao(): BenchmarkDao
    abstract fun sessionDao(): SessionDao
    abstract fun batteryDao(): BatteryDao
}

/** Adds the battery history table without touching existing benchmark results. */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `battery_samples` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`timestamp` INTEGER NOT NULL, `level` INTEGER NOT NULL, `tempC` REAL, `voltageMv` INTEGER, `charging` INTEGER NOT NULL)",
        )
    }
}
