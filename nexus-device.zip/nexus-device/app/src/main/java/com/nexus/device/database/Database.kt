package com.nexus.device.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "benchmark_results")
data class BenchmarkResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val testId: String,
    val value: Double,
    val unit: String,
    val timestamp: Long,
)

@Entity(tableName = "monitor_sessions")
data class MonitorSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAt: Long,
    val durationMs: Long,
    val samples: Int,
    val ramAvg: Double,
    val ramMax: Double,
    val tempMax: Double?,
    val batteryStart: Int?,
    val batteryEnd: Int?,
)

@Dao
interface BenchmarkDao {
    @Insert suspend fun insert(r: BenchmarkResultEntity)
    @Query("SELECT * FROM benchmark_results ORDER BY timestamp DESC") fun observeAll(): Flow<List<BenchmarkResultEntity>>
    @Query("DELETE FROM benchmark_results") suspend fun clear()
}

@Dao
interface SessionDao {
    @Insert suspend fun insert(s: MonitorSessionEntity)
    @Query("SELECT * FROM monitor_sessions ORDER BY startedAt DESC") fun observeAll(): Flow<List<MonitorSessionEntity>>
    @Query("DELETE FROM monitor_sessions") suspend fun clear()
}

@Database(entities = [BenchmarkResultEntity::class, MonitorSessionEntity::class], version = 1, exportSchema = false)
abstract class NexusDatabase : RoomDatabase() {
    abstract fun benchmarkDao(): BenchmarkDao
    abstract fun sessionDao(): SessionDao
}
