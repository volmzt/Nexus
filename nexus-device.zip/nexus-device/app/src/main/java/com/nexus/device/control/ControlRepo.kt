package com.nexus.device.control

import com.nexus.device.access.Privileged
import com.nexus.device.access.ShellResult

/** One CPU frequency policy (a cluster of cores that share a clock). All values are what the kernel printed. */
data class CpuPolicy(
    val id: String,
    val cores: String,
    val governor: String?,
    val governors: List<String>,
    val minKHz: Long?,
    val maxKHz: Long?,
    val curKHz: Long?,
    val hwMinKHz: Long?,
    val hwMaxKHz: Long?,
    val freqs: List<Long>,
) {
    val path get() = "/sys/devices/system/cpu/cpufreq/$id"
}

data class GpuState(
    val curHz: Long?,
    val busyPercent: Int?,
    val governor: String?,
    val governors: List<String>,
    val maxHz: Long?,
    val freqsHz: List<Long>,
    val path: String,
)

data class DisplayState(
    val physSize: String?, val curSize: String?,
    val physDpi: Int?, val curDpi: Int?,
    val peakRefresh: String?, val minRefresh: String?,
    val animScale: String?,
)

data class Tweaks(val stayAwake: Boolean, val showTouches: Boolean, val pointer: Boolean)

object ControlRepo {
    private const val CPU_DUMP =
        "for p in /sys/devices/system/cpu/cpufreq/policy*; do echo \"== \${p##*/}\"; " +
            "for f in related_cpus scaling_governor scaling_available_governors scaling_min_freq scaling_max_freq " +
            "cpuinfo_min_freq cpuinfo_max_freq scaling_cur_freq scaling_available_frequencies; do " +
            "echo \"\$f=\$(cat \$p/\$f 2>/dev/null)\"; done; done"

    suspend fun cpuPolicies(): List<CpuPolicy> {
        val r = Privileged.exec(CPU_DUMP)
        val out = mutableListOf<CpuPolicy>()
        var id: String? = null
        val kv = HashMap<String, String>()
        fun flush() {
            val i = id ?: return
            fun l(k: String) = kv[k]?.trim()?.toLongOrNull()
            val cores = kv["related_cpus"]?.trim().orEmpty()
            out.add(CpuPolicy(
                id = i, cores = cores.split(' ').filter { it.isNotBlank() }.let { if (it.isEmpty()) i else if (it.size == 1) it.first() else it.first() + "–" + it.last() },
                governor = kv["scaling_governor"]?.trim()?.ifBlank { null },
                governors = kv["scaling_available_governors"].orEmpty().trim().split(' ').filter { it.isNotBlank() },
                minKHz = l("scaling_min_freq") ?: l("cpuinfo_min_freq"),
                maxKHz = l("scaling_max_freq") ?: l("cpuinfo_max_freq"),
                curKHz = l("scaling_cur_freq"),
                hwMinKHz = l("cpuinfo_min_freq"), hwMaxKHz = l("cpuinfo_max_freq"),
                freqs = kv["scaling_available_frequencies"].orEmpty().trim().split(' ').mapNotNull { it.toLongOrNull() }.sorted(),
            ))
        }
        for (line in r.out.lines()) {
            if (line.startsWith("== ")) { flush(); kv.clear(); id = line.removePrefix("== ").trim() }
            else line.indexOf('=').takeIf { it > 0 }?.let { kv[line.substring(0, it)] = line.substring(it + 1) }
        }
        flush()
        return out.filter { it.curKHz != null || it.maxKHz != null }
    }

    suspend fun setCpu(p: CpuPolicy, governor: String?, minKHz: Long?, maxKHz: Long?): ShellResult {
        val cmds = buildList {
            // Raise the max first so a new min above the old max is accepted, then set the rest.
            if (maxKHz != null) add("echo $maxKHz > ${p.path}/scaling_max_freq")
            if (minKHz != null) add("echo $minKHz > ${p.path}/scaling_min_freq")
            if (governor != null) add("echo $governor > ${p.path}/scaling_governor")
        }
        if (cmds.isEmpty()) return ShellResult(true, "", "")
        return Privileged.execRoot(cmds.joinToString("; "))
    }

    private const val GPU = "/sys/class/kgsl/kgsl-3d0"

    suspend fun gpu(): GpuState? {
        val r = Privileged.exec(
            "for f in devfreq/cur_freq gpuclk clock_mhz gpu_busy_percentage gpubusy devfreq/governor devfreq/available_governors devfreq/max_freq devfreq/available_frequencies; do " +
                "echo \"\$f=\$(cat $GPU/\$f 2>/dev/null)\"; done",
        )
        val kv = r.out.lines().mapNotNull { l -> l.indexOf('=').takeIf { it > 0 }?.let { l.substring(0, it) to l.substring(it + 1).trim() } }.toMap()
        // The clock appears under different names depending on the driver version; the first one that parses wins.
        val cur = kv["devfreq/cur_freq"]?.toLongOrNull()
            ?: kv["gpuclk"]?.toLongOrNull()
            ?: kv["clock_mhz"]?.toLongOrNull()?.let { it * 1_000_000 }
        val busy = kv["gpu_busy_percentage"]?.filter { it.isDigit() }?.toIntOrNull()
            ?: kv["gpubusy"]?.split(' ')?.mapNotNull { it.toLongOrNull() }?.takeIf { it.size == 2 && it[1] > 0 }?.let { (100 * it[0] / it[1]).toInt() }
        if (cur == null && busy == null) return null
        return GpuState(
            curHz = cur, busyPercent = busy, governor = kv["devfreq/governor"]?.ifBlank { null },
            governors = kv["devfreq/available_governors"].orEmpty().split(' ').filter { it.isNotBlank() },
            maxHz = kv["devfreq/max_freq"]?.toLongOrNull(),
            freqsHz = kv["devfreq/available_frequencies"].orEmpty().split(' ').mapNotNull { it.toLongOrNull() }.sorted(),
            path = GPU,
        )
    }

    suspend fun setGpu(governor: String?, maxHz: Long?): ShellResult {
        val cmds = buildList {
            if (maxHz != null) add("echo $maxHz > $GPU/devfreq/max_freq")
            if (governor != null) add("echo $governor > $GPU/devfreq/governor")
        }
        if (cmds.isEmpty()) return ShellResult(true, "", "")
        return Privileged.execRoot(cmds.joinToString("; "))
    }

    suspend fun display(): DisplayState {
        val size = Privileged.exec("wm size").out
        val dens = Privileged.exec("wm density").out
        fun s(k: String) = Regex("$k:\\s*(\\S+)").find(size)?.groupValues?.get(1)
        fun d(k: String) = Regex("$k:\\s*(\\d+)").find(dens)?.groupValues?.get(1)?.toIntOrNull()
        suspend fun g(ns: String, key: String) = Privileged.exec("settings get $ns $key").out.trim().takeIf { it.isNotBlank() && it != "null" }
        val phys = s("Physical size")
        val phDpi = d("Physical density")
        return DisplayState(
            physSize = phys, curSize = s("Override size") ?: phys,
            physDpi = phDpi, curDpi = d("Override density") ?: phDpi,
            peakRefresh = g("system", "peak_refresh_rate"), minRefresh = g("system", "min_refresh_rate"),
            animScale = g("global", "window_animation_scale"),
        )
    }

    suspend fun setDensity(dpi: Int?) = Privileged.exec(if (dpi == null) "wm density reset" else "wm density $dpi")
    suspend fun setSize(size: String?) = Privileged.exec(if (size == null) "wm size reset" else "wm size $size")

    suspend fun setRefresh(hz: Int?) = Privileged.exec(
        if (hz == null) "settings delete system peak_refresh_rate; settings delete system min_refresh_rate"
        else "settings put system peak_refresh_rate $hz; settings put system min_refresh_rate $hz",
    )

    suspend fun setAnimScale(scale: Float) = Privileged.exec(
        listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
            .joinToString("; ") { "settings put global $it $scale" },
    )

    suspend fun tweaks(): Tweaks {
        suspend fun on(ns: String, k: String, onValue: String = "1") = Privileged.exec("settings get $ns $k").out.trim().let { it != "null" && it != "0" && it.isNotBlank() && (onValue == "1" || it != "0") }
        return Tweaks(
            stayAwake = on("global", "stay_on_while_plugged_in"),
            showTouches = on("system", "show_touches"),
            pointer = on("system", "pointer_location"),
        )
    }

    suspend fun setStayAwake(v: Boolean) = Privileged.exec("settings put global stay_on_while_plugged_in ${if (v) 3 else 0}")
    suspend fun setShowTouches(v: Boolean) = Privileged.exec("settings put system show_touches ${if (v) 1 else 0}")
    suspend fun setPointer(v: Boolean) = Privileged.exec("settings put system pointer_location ${if (v) 1 else 0}")

    /** Per-core load from two reads of /proc/stat one second apart. Returns percent per core, or empty if unreadable. */
    suspend fun coreLoads(): List<Int> {
        suspend fun snap(): List<Pair<Long, Long>> = Privileged.exec("cat /proc/stat").out.lines()
            .filter { Regex("^cpu\\d+ ").containsMatchIn(it) }
            .map { l ->
                val n = l.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                val idle = n.getOrElse(3) { 0 } + n.getOrElse(4) { 0 }
                n.sum() to idle
            }
        val a = snap()
        if (a.isEmpty()) return emptyList()
        kotlinx.coroutines.delay(700)
        val b = snap()
        return a.indices.mapNotNull { i ->
            val bt = b.getOrNull(i) ?: return@mapNotNull null
            val total = bt.first - a[i].first
            val idle = bt.second - a[i].second
            if (total <= 0) 0 else (100 * (total - idle) / total).toInt().coerceIn(0, 100)
        }
    }
}
