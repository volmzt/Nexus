package com.nexus.device.control

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import com.nexus.device.access.Privileged
import com.nexus.device.access.ShellResult
import kotlinx.coroutines.delay
import java.io.File

/** One CPU frequency policy (a cluster of cores that share a clock). All values are what the kernel printed. */
data class CpuPolicy(
    val id: String,
    val cores: String,
    val governor: String?,
    val governors: List<String>,
    val minKHz: Long?,
    val maxKHz: Long?,
    val curKHz: Long?,
    val hwMinKHz: Long?,
    val hwMaxKHz: Long?,
    val freqs: List<Long>,
) {
    val path get() = "/sys/devices/system/cpu/cpufreq/$id"
}

data class GpuState(
    val curHz: Long?,
    val busyPercent: Int?,
    val governor: String?,
    val governors: List<String>,
    val maxHz: Long?,
    val freqsHz: List<Long>,
)

data class DisplayState(
    val physSize: String?, val curSize: String?,
    val physDpi: Int?, val curDpi: Int?,
    /** What the system setting says (null = automatic), and what the panel is doing right now. */
    val setRefreshHz: Int?, val liveRefreshHz: Float?,
    val animScale: String?,
)

data class Tweaks(val stayAwake: Boolean, val showTouches: Boolean, val pointer: Boolean)

/**
 * Reads and writes the things the Control screen shows.
 * Reads try the file directly first (no process is started) and fall back to the shell only when Android blocks the file.
 * Writes always go through [Privileged].
 */
object ControlRepo {
    private const val CPUFREQ = "/sys/devices/system/cpu/cpufreq"
    private const val GPU = "/sys/class/kgsl/kgsl-3d0"
    private val CPU_KEYS = listOf(
        "related_cpus", "scaling_governor", "scaling_available_governors", "scaling_min_freq", "scaling_max_freq",
        "cpuinfo_min_freq", "cpuinfo_max_freq", "scaling_cur_freq", "scaling_available_frequencies",
    )
    private val GPU_KEYS = listOf(
        "devfreq/cur_freq", "gpuclk", "clock_mhz", "gpu_busy_percentage", "gpubusy",
        "devfreq/governor", "devfreq/available_governors", "devfreq/max_freq", "devfreq/available_frequencies",
    )

    private fun readFile(path: String): String? =
        runCatching { File(path).readText().trim() }.getOrNull()?.ifBlank { null }

    /** Reads a list of files under [base]: directly if possible, otherwise with one shell call. Returns key -> text. */
    private suspend fun readKeys(base: String, keys: List<String>): Map<String, String> {
        val direct = keys.mapNotNull { k -> readFile("$base/$k")?.let { k to it } }.toMap()
        if (direct.isNotEmpty()) return direct
        val cmd = keys.joinToString("; ") { "echo \"$it=\$(cat $base/$it 2>/dev/null)\"" }
        val out = Privileged.exec(cmd).out
        return out.lines().mapNotNull { l -> l.indexOf('=').takeIf { it > 0 }?.let { l.substring(0, it) to l.substring(it + 1).trim() } }
            .filter { it.second.isNotBlank() }.toMap()
    }

    private fun policyFrom(id: String, kv: Map<String, String>): CpuPolicy? {
        fun l(k: String) = kv[k]?.trim()?.toLongOrNull()
        val list = kv["related_cpus"].orEmpty().split(' ').filter { it.isNotBlank() }
        val p = CpuPolicy(
            id = id,
            cores = when (list.size) { 0 -> id; 1 -> list.first(); else -> list.first() + "–" + list.last() },
            governor = kv["scaling_governor"]?.trim()?.ifBlank { null },
            governors = kv["scaling_available_governors"].orEmpty().trim().split(' ').filter { it.isNotBlank() },
            minKHz = l("scaling_min_freq") ?: l("cpuinfo_min_freq"),
            maxKHz = l("scaling_max_freq") ?: l("cpuinfo_max_freq"),
            curKHz = l("scaling_cur_freq"),
            hwMinKHz = l("cpuinfo_min_freq"), hwMaxKHz = l("cpuinfo_max_freq"),
            freqs = kv["scaling_available_frequencies"].orEmpty().trim().split(' ').mapNotNull { it.toLongOrNull() }.sorted(),
        )
        return if (p.curKHz != null || p.maxKHz != null) p else null
    }

    suspend fun cpuPolicies(): List<CpuPolicy> {
        val ids = runCatching { File(CPUFREQ).list { _, n -> n.startsWith("policy") }?.sorted() }.getOrNull().orEmpty()
        if (ids.isNotEmpty()) {
            val direct = ids.mapNotNull { id -> policyFrom(id, CPU_KEYS.mapNotNull { k -> readFile("$CPUFREQ/$id/$k")?.let { k to it } }.toMap()) }
            if (direct.isNotEmpty()) return direct
        }
        // Blocked for the app: one shell call dumps every policy.
        val cmd = "for p in $CPUFREQ/policy*; do echo \"== \${p##*/}\"; " +
            CPU_KEYS.joinToString("; ") { "echo \"$it=\$(cat \$p/$it 2>/dev/null)\"" } + "; done"
        val out = mutableListOf<CpuPolicy>()
        var id: String? = null
        val kv = HashMap<String, String>()
        fun flush() { id?.let { i -> policyFrom(i, kv)?.let { out.add(it) } } }
        for (line in Privileged.exec(cmd).out.lines()) {
            if (line.startsWith("== ")) { flush(); kv.clear(); id = line.removePrefix("== ").trim() }
            else line.indexOf('=').takeIf { it > 0 }?.let { kv[line.substring(0, it)] = line.substring(it + 1) }
        }
        flush()
        return out
    }

    suspend fun setCpu(p: CpuPolicy, governor: String?, minKHz: Long?, maxKHz: Long?): ShellResult {
        val cmds = buildList {
            // Raise the max first so a new min above the old max is accepted, then set the rest.
            if (maxKHz != null) add("echo $maxKHz > ${p.path}/scaling_max_freq")
            if (minKHz != null) add("echo $minKHz > ${p.path}/scaling_min_freq")
            if (governor != null) add("echo $governor > ${p.path}/scaling_governor")
        }
        if (cmds.isEmpty()) return ShellResult(true, "", "")
        return Privileged.execRoot(cmds.joinToString("; "))
    }

    suspend fun gpu(): GpuState? {
        val kv = readKeys(GPU, GPU_KEYS)
        // The clock appears under different names depending on the driver version; the first one that parses wins.
        val cur = kv["devfreq/cur_freq"]?.toLongOrNull()
            ?: kv["gpuclk"]?.toLongOrNull()
            ?: kv["clock_mhz"]?.toLongOrNull()?.let { it * 1_000_000 }
        val busy = kv["gpu_busy_percentage"]?.filter { it.isDigit() }?.toIntOrNull()
            ?: kv["gpubusy"]?.split(' ')?.mapNotNull { it.toLongOrNull() }?.takeIf { it.size == 2 && it[1] > 0 }?.let { (100 * it[0] / it[1]).toInt() }
        if (cur == null && busy == null) return null
        return GpuState(
            curHz = cur, busyPercent = busy, governor = kv["devfreq/governor"],
            governors = kv["devfreq/available_governors"].orEmpty().split(' ').filter { it.isNotBlank() },
            maxHz = kv["devfreq/max_freq"]?.toLongOrNull(),
            freqsHz = kv["devfreq/available_frequencies"].orEmpty().split(' ').mapNotNull { it.toLongOrNull() }.sorted(),
        )
    }

    suspend fun setGpu(governor: String?, maxHz: Long?): ShellResult {
        val cmds = buildList {
            if (maxHz != null) add("echo $maxHz > $GPU/devfreq/max_freq")
            if (governor != null) add("echo $governor > $GPU/devfreq/governor")
        }
        if (cmds.isEmpty()) return ShellResult(true, "", "")
        return Privileged.execRoot(cmds.joinToString("; "))
    }

    // ---- display ----

    /** Refresh rate settings that Android and Xiaomi/HyperOS read. Unknown keys are simply stored and ignored. */
    private val REFRESH_KEYS = listOf("system peak_refresh_rate", "system min_refresh_rate", "system user_refresh_rate", "secure miui_refresh_rate")

    fun liveRefreshHz(context: Context): Float? = runCatching {
        (context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY).refreshRate
    }.getOrNull()

    suspend fun display(context: Context): DisplayState {
        val size = Privileged.exec("wm size").out
        val dens = Privileged.exec("wm density").out
        fun s(k: String) = Regex("$k:\\s*(\\S+)").find(size)?.groupValues?.get(1)
        fun d(k: String) = Regex("$k:\\s*(\\d+)").find(dens)?.groupValues?.get(1)?.toIntOrNull()
        suspend fun g(ns: String, key: String) = Privileged.exec("settings get $ns $key").out.trim().takeIf { it.isNotBlank() && it != "null" }
        val phys = s("Physical size")
        val phDpi = d("Physical density")
        return DisplayState(
            physSize = phys, curSize = s("Override size") ?: phys,
            physDpi = phDpi, curDpi = d("Override density") ?: phDpi,
            setRefreshHz = g("system", "peak_refresh_rate")?.toFloatOrNull()?.toInt(),
            liveRefreshHz = liveRefreshHz(context),
            animScale = g("global", "window_animation_scale"),
        )
    }

    suspend fun setDensity(dpi: Int?) = Privileged.exec(if (dpi == null) "wm density reset" else "wm density $dpi")
    suspend fun setSize(size: String?) = Privileged.exec(if (size == null) "wm size reset" else "wm size $size")

    /**
     * Sets every refresh-rate key, then reads the main one back. Android stores peak/min as floats ("120.0"),
     * so the value is written in that form. [hz] == null returns the phone to automatic.
     */
    suspend fun setRefresh(hz: Int?): ShellResult {
        val cmd = if (hz == null) REFRESH_KEYS.joinToString("; ") { "settings delete $it" }
        else REFRESH_KEYS.joinToString("; ") { k -> "settings put $k " + (if (k.endsWith("peak_refresh_rate") || k.endsWith("min_refresh_rate")) "$hz.0" else "$hz") }
        val r = Privileged.exec(cmd)
        if (!r.ok) return r
        val back = Privileged.exec("settings get system peak_refresh_rate").out.trim().toFloatOrNull()?.toInt()
        return if ((hz == null && back == null) || back == hz) r
        else ShellResult(false, "", "The setting did not stick (read back: ${back ?: "none"})")
    }

    suspend fun setAnimScale(scale: Float) = Privileged.exec(
        listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
            .joinToString("; ") { "settings put global $it $scale" },
    )

    // ---- tweaks ----

    suspend fun tweaks(): Tweaks {
        suspend fun on(ns: String, k: String) = Privileged.exec("settings get $ns $k").out.trim().let { it.isNotBlank() && it != "null" && it != "0" }
        return Tweaks(
            stayAwake = on("global", "stay_on_while_plugged_in"),
            showTouches = on("system", "show_touches"),
            pointer = on("system", "pointer_location"),
        )
    }

    suspend fun setStayAwake(v: Boolean) = Privileged.exec("settings put global stay_on_while_plugged_in ${if (v) 3 else 0}")
    suspend fun setShowTouches(v: Boolean) = Privileged.exec("settings put system show_touches ${if (v) 1 else 0}")
    suspend fun setPointer(v: Boolean) = Privileged.exec("settings put system pointer_location ${if (v) 1 else 0}")

    // ---- load ----

    private suspend fun statSnapshot(): List<Pair<Long, Long>> {
        val text = readFile("/proc/stat") ?: Privileged.exec("cat /proc/stat").out
        return text.lines().filter { Regex("^cpu\\d+ ").containsMatchIn(it) }.map { l ->
            val n = l.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            n.sum() to (n.getOrElse(3) { 0 } + n.getOrElse(4) { 0 })
        }
    }

    /** Per-core load from two reads of /proc/stat 700 ms apart. Empty when the file is unreadable. */
    suspend fun coreLoads(): List<Int> {
        val a = statSnapshot()
        if (a.isEmpty()) return emptyList()
        delay(700)
        val b = statSnapshot()
        return a.indices.mapNotNull { i ->
            val bt = b.getOrNull(i) ?: return@mapNotNull null
            val total = bt.first - a[i].first
            val idle = bt.second - a[i].second
            if (total <= 0) 0 else (100 * (total - idle) / total).toInt().coerceIn(0, 100)
        }
    }
}
