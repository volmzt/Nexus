package com.nexus.device.presentation.tools

import android.hardware.Sensor
import android.hardware.SensorManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.hardware.AppItem
import com.nexus.device.hardware.AppsRepository
import com.nexus.device.hardware.CodecItem
import com.nexus.device.hardware.CodecRepository
import com.nexus.device.hardware.GlInfoReader
import com.nexus.device.hardware.SensorsProvider
import com.nexus.device.presentation.AnalyzerViewModel
import com.nexus.device.presentation.NetDiagViewModel
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.LineChart
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.device.DetailHeader
import com.nexus.device.presentation.rememberCopier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun NetDiagScreen(vm: NetDiagViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var url by remember { mutableStateOf("example.com") }
    val okSeries = ui.history.mapNotNull { it.millis?.toFloat() }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { DetailHeader(stringResource(R.string.net_diag), onBack) }
        item { Text(stringResource(R.string.net_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            TextField(
                value = url, onValueChange = { url = it }, singleLine = true,
                placeholder = { Text(stringResource(R.string.net_url_hint)) }, shape = CircleShape,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.run(url) }, enabled = !ui.running) { Text(stringResource(R.string.run)) }
                OutlinedButton(onClick = { vm.clear() }) { Text(stringResource(R.string.net_clear)) }
            }
        }
        if (okSeries.size >= 2) {
            item {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(stringResource(R.string.net_latency_chart), style = MaterialTheme.typography.bodyLarge)
                    LineChart(listOf(okSeries), Modifier.fillMaxWidth().height(110.dp), maxPoints = 40)
                }
            }
        }
        val rows = ui.history.reversed()
        items(rows.size) { i ->
            val r = rows[i]
            ItemRow(
                title = r.url,
                subtitle = if (r.millis != null && r.code != null) stringResource(R.string.net_ok, r.millis, r.code) else (r.error ?: "—"),
                shape = groupShape(i, rows.size),
                trailing = { Text(DateFormat.getTimeInstance().format(Date(r.at)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) },
            )
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
fun AnalyzerScreen(vm: AnalyzerViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val copy = rememberCopier()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? -> if (uri != null) vm.analyze(uri) }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { DetailHeader(stringResource(R.string.analyzer), onBack) }
        item { Text(stringResource(R.string.analyzer_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Button(onClick = { picker.launch(null) }, enabled = !ui.running) { Text(stringResource(R.string.analyzer_pick)) } }
        if (ui.running) item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { CircularProgressIndicator(); Text(stringResource(R.string.analyzer_scanning, ui.progress)) } }
        ui.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }
        ui.result?.let { r ->
            item {
                Text(stringResource(R.string.analyzer_summary, r.scanned, Fmt.bytes(r.totalBytes)), style = MaterialTheme.typography.titleMedium)
                if (r.truncated) Text(stringResource(R.string.analyzer_truncated), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item { Text(stringResource(R.string.analyzer_largest), style = MaterialTheme.typography.titleMedium) }
            val big = r.largest.take(15)
            items(big.size) { i -> ItemRow(big[i].name, Fmt.bytes(big[i].size), shape = groupShape(i, big.size)) }
            item { Text(stringResource(R.string.analyzer_ext), style = MaterialTheme.typography.titleMedium) }
            val ex = r.extensions.take(15)
            items(ex.size) { i -> ItemRow(".${ex[i].ext}", "${ex[i].count} · ${Fmt.bytes(ex[i].bytes)}", shape = groupShape(i, ex.size)) }
            item { Text(stringResource(R.string.analyzer_dups), style = MaterialTheme.typography.titleMedium) }
            if (r.duplicates.isEmpty()) {
                item { Text(stringResource(R.string.analyzer_no_dups), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                val d = r.duplicates.take(30)
                items(d.size) { i -> ItemRow("${d[i].names.size} × ${Fmt.bytes(d[i].size)}", d[i].names.joinToString(", "), shape = groupShape(i, d.size)) }
            }
            item {
                OutlinedButton(onClick = {
                    copy(buildString {
                        appendLine("Files: ${r.scanned}, ${Fmt.bytes(r.totalBytes)}")
                        appendLine("Largest:"); r.largest.take(50).forEach { appendLine("  ${it.name}  ${Fmt.bytes(it.size)}") }
                        appendLine("Extensions:"); r.extensions.forEach { appendLine("  .${it.ext}  ${it.count}  ${Fmt.bytes(it.bytes)}") }
                        appendLine("Duplicates:"); r.duplicates.forEach { appendLine("  ${Fmt.bytes(it.size)}: ${it.names.joinToString(", ")}") }
                    })
                }) { Text(stringResource(R.string.analyzer_copy_report)) }
            }
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

/** Lists sensors; opening one starts a live graph that stops when you leave the screen. */
@Composable
fun SensorsLiveScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val sm = remember { ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    val sensors = remember { sm.getSensorList(Sensor.TYPE_ALL) }
    var selected by remember { mutableStateOf<Sensor?>(null) }

    val sel = selected
    if (sel != null) {
        SensorDetail(sm, sel, onBack = { selected = null }, modifier)
        return
    }
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { DetailHeader(stringResource(R.string.sensors_live), onBack) }
        if (sensors.isEmpty()) item { Text(stringResource(R.string.sensors_none), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(sensors.size) { i ->
            val s = sensors[i]
            ItemRow(s.name, SensorsProvider.describe(s), shape = groupShape(i, sensors.size), onClick = { selected = s }, chevron = true)
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
private fun SensorDetail(sm: SensorManager, sensor: Sensor, onBack: () -> Unit, modifier: Modifier) {
    var running by remember { mutableStateOf(false) }
    val history = remember { mutableStateListOf<FloatArray>() }
    var latest by remember { mutableStateOf<FloatArray?>(null) }
    val streams = sensor.reportingMode == Sensor.REPORTING_MODE_CONTINUOUS || sensor.reportingMode == Sensor.REPORTING_MODE_ON_CHANGE

    // The listener exists only while the effect is active: Stop, leaving the screen or backgrounding the app all unregister it.
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(running) {
        if (running) {
            owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                SensorsProvider.events(sm, sensor).collect { v ->
                    latest = v
                    history.add(v)
                    if (history.size > 120) history.removeAt(0)
                }
            }
        }
    }

    val axes = latest?.size ?: 1
    val series = (0 until minOf(axes, 3)).map { a -> history.map { it.getOrElse(a) { 0f } } }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { DetailHeader(sensor.name, onBack) }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (series.firstOrNull()?.size ?: 0 >= 2) LineChart(series, Modifier.fillMaxWidth().height(150.dp), maxPoints = 120)
                else Text(if (streams) stringResource(R.string.press_start) else stringResource(R.string.sensor_not_streaming), color = MaterialTheme.colorScheme.onSurfaceVariant)
                latest?.let { Text(it.take(6).joinToString("   ") { v -> Fmt.one(v.toDouble()) }, style = MaterialTheme.typography.titleMedium) }
            }
        }
        item {
            Button(onClick = { if (!running) history.clear(); running = !running }, enabled = streams) {
                Text(stringResource(if (running) R.string.monitor_stop else R.string.monitor_start))
            }
        }
        item { Text(SensorsProvider.describe(sensor), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
fun GpuExtensionsScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    var ext by remember { mutableStateOf<List<String>?>(null) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { ext = withContext(Dispatchers.Default) { GlInfoReader.query()?.extensions.orEmpty() } }
    val copy = rememberCopier()
    val list = ext?.filter { it.contains(q.trim(), ignoreCase = true) }.orEmpty()
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { DetailHeader(stringResource(R.string.gpu_extensions), onBack) }
        item {
            TextField(
                value = q, onValueChange = { q = it }, singleLine = true, shape = CircleShape,
                placeholder = { Text(stringResource(R.string.search_hint)) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
        }
        if (ext == null) item { CircularProgressIndicator() }
        else if (list.isEmpty()) item { Text(stringResource(R.string.nothing_found), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(list.size) { i -> ItemRow(list[i], shape = groupShape(i, list.size), onClick = { copy(list[i]) }) }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
fun CodecsScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    var codecs by remember { mutableStateOf<List<CodecItem>?>(null) }
    var video by remember { mutableStateOf(true) }
    var expanded by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { codecs = withContext(Dispatchers.Default) { CodecRepository.load() } }
    val list = codecs?.filter { it.video == video }.orEmpty()
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { DetailHeader(stringResource(R.string.cat_codecs), onBack) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = video, onClick = { video = true }, label = { Text(stringResource(R.string.codecs_video)) })
                FilterChip(selected = !video, onClick = { video = false }, label = { Text(stringResource(R.string.codecs_audio)) })
            }
            Spacer(Modifier.height(12.dp))
        }
        if (codecs == null) item { CircularProgressIndicator() }
        items(list.size) { i ->
            val c = list[i]
            val open = expanded == c.name
            ItemRow(
                title = c.name,
                subtitle = (if (c.encoder) "Encoder" else "Decoder") + " · " + c.vendor + "\n" + c.types.joinToString() +
                    (if (open) "\n" + c.details.joinToString("\n") else ""),
                shape = groupShape(i, list.size),
                onClick = { expanded = if (open) null else c.name },
            )
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
fun AppsScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var q by remember { mutableStateOf("") }
    var byDate by remember { mutableStateOf(false) }
    var userOnly by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.Default) { AppsRepository.load(ctx) } }
    val copy = rememberCopier()
    val list = apps.orEmpty()
        .filter { (!userOnly || !it.system) && (it.label.contains(q.trim(), true) || it.packageName.contains(q.trim(), true)) }
        .let { if (byDate) it.sortedByDescending { a -> a.installTime } else it.sortedBy { a -> a.label.lowercase() } }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { DetailHeader(stringResource(R.string.cat_apps), onBack) }
        item {
            TextField(
                value = q, onValueChange = { q = it }, singleLine = true, shape = CircleShape,
                placeholder = { Text(stringResource(R.string.apps_search)) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainer,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !byDate, onClick = { byDate = false }, label = { Text(stringResource(R.string.apps_sort_name)) })
                FilterChip(selected = byDate, onClick = { byDate = true }, label = { Text(stringResource(R.string.apps_sort_date)) })
                FilterChip(selected = userOnly, onClick = { userOnly = !userOnly }, label = { Text(stringResource(R.string.apps_user_only)) })
            }
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.apps_visibility), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
        }
        if (apps == null) item { CircularProgressIndicator() }
        items(list.size) { i ->
            val a = list[i]
            ItemRow(
                title = a.label,
                subtitle = a.packageName + "\n" + a.versionName + " (" + a.versionCode + ")" +
                    " · " + DateFormat.getDateInstance().format(Date(a.installTime)) + " · " + a.category,
                shape = groupShape(i, list.size),
                onClick = { copy(a.packageName) },
            )
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}
