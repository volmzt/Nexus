package com.nexus.device.presentation.home

import android.os.Environment
import android.os.StatFs
import androidx.annotation.StringRes
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.device.R
import com.nexus.device.bench.BenchRun
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.data.HomeBlocks
import com.nexus.device.domain.Category
import com.nexus.device.presentation.HomeViewModel
import com.nexus.device.presentation.bench.BenchHomeCard
import com.nexus.device.presentation.bench.BenchViewModel
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.LineChart
import com.nexus.device.presentation.components.cardSurface

/** What the Add dialog and the blocks themselves need to know about one kind of block. */
internal class BlockSpec(
    val id: String,
    @StringRes val title: Int,
    val icon: ImageVector,
    @StringRes val desc: Int?,
    /** Where a tool block leads, null for blocks that open a hardware category. */
    val route: String?,
)

internal val HomeCatalog = listOf(
    BlockSpec("bench", R.string.bench_title, Icons.Filled.Speed, null, null),
    BlockSpec("device", R.string.tile_device, Icons.Filled.Smartphone, null, null),
    BlockSpec("battery", R.string.battery, Icons.Filled.BatteryFull, null, null),
    BlockSpec("cpu", R.string.cat_cpu, Icons.Filled.Memory, null, null),
    BlockSpec("ram", R.string.ram, Icons.Filled.Memory, null, null),
    BlockSpec("load", R.string.load, Icons.Filled.ShowChart, null, null),
    BlockSpec("storage", R.string.storage_used, Icons.Filled.Storage, null, null),
    BlockSpec("gpu", R.string.cat_gpu, Icons.Filled.Tune, null, null),
    BlockSpec("temp", R.string.temperature, Icons.Filled.Thermostat, null, null),
    BlockSpec("fn:throttle", R.string.throttle, Icons.Filled.Thermostat, R.string.thr_row_desc, "throttle"),
    BlockSpec("fn:hwcheck", R.string.hw_title, Icons.Filled.Tune, R.string.hw_desc, "hwcheck"),
    BlockSpec("fn:tests", R.string.tests_title, Icons.Filled.Speed, R.string.benchmarks_desc, "tests"),
    BlockSpec("fn:terminal", R.string.terminal, Icons.Filled.Terminal, R.string.fn_terminal_d, "terminal"),
    BlockSpec("fn:apps", R.string.cat_apps, Icons.Filled.Apps, R.string.fn_apps_d, "cat:apps"),
    BlockSpec("fn:battery_health", R.string.bh_title, Icons.Filled.BatteryFull, R.string.fn_bh_d, "battery_health"),
    BlockSpec("fn:cores", R.string.core_freqs, Icons.Filled.Memory, R.string.core_freqs_desc, "cores"),
    BlockSpec("fn:sensors_live", R.string.sensors_live, Icons.Filled.Sensors, null, "sensors_live"),
    BlockSpec("fn:gpu_ext", R.string.gpu_extensions, Icons.Filled.Tune, null, "gpu_ext"),
    BlockSpec("fn:c_system", R.string.cat_system, Icons.Filled.Info, null, "cat:system"),
    BlockSpec("fn:c_cpu", R.string.cat_cpu, Icons.Filled.Memory, null, "cat:cpu"),
    BlockSpec("fn:c_gpu", R.string.cat_gpu, Icons.Filled.Tune, null, "cat:gpu"),
    BlockSpec("fn:c_memory", R.string.cat_memory, Icons.Filled.Memory, null, "cat:memory"),
    BlockSpec("fn:c_storage", R.string.cat_storage, Icons.Filled.Storage, null, "cat:storage"),
    BlockSpec("fn:c_display", R.string.cat_display, Icons.Filled.PhoneAndroid, null, "cat:display"),
    BlockSpec("fn:c_battery", R.string.cat_battery, Icons.Filled.BatteryFull, null, "cat:battery"),
    BlockSpec("fn:c_network", R.string.cat_network, Icons.Filled.Wifi, null, "cat:network"),
    BlockSpec("fn:c_sensors", R.string.cat_sensors, Icons.Filled.Sensors, null, "cat:sensors"),
    BlockSpec("fn:c_camera", R.string.cat_camera, Icons.Filled.CameraAlt, null, "cat:camera"),
    BlockSpec("fn:c_codecs", R.string.cat_codecs, Icons.Filled.VideoLibrary, null, "cat:codecs"),
)

internal fun specOf(id: String): BlockSpec? = HomeCatalog.firstOrNull { it.id == id }

/** Everything a block may show. A new instance is made on every recomposition, so it is always current. */
internal class HomeData(
    val ui: HomeViewModel.Ui,
    val unit: TempUnit,
    val bench: BenchViewModel,
    val lastBench: BenchRun?,
    val editing: Boolean,
    val onOpen: (Category) -> Unit,
    val onRoute: (String) -> Unit,
    val onBench: (Boolean) -> Unit,
    val onEdit: () -> Unit,
)

/** A figure with a title, drawn as a small tile, a wide row or a wide card depending on the block size. */
private class TileInfo(
    val title: String,
    val big: String,
    val small: String,
    /** 0..1 for the bar, null when the figure has no natural scale. */
    val fraction: Float?,
    val chart: List<Float>,
    val extra: String?,
    val open: Category,
)

@OptIn(ExperimentalFoundationApi::class)
private fun Modifier.tap(click: (() -> Unit)?, long: (() -> Unit)?): Modifier =
    if (click != null || long != null) combinedClickable(onClick = click ?: {}, onLongClick = long) else this

@Composable
private fun tileInfo(id: String, d: HomeData): TileInfo? {
    val ui = d.ui
    val last = ui.last
    val na = stringResource(R.string.st_na)
    fun frac(percent: Float?): Float? = percent?.let { (it.toDouble() / 100.0).toFloat().coerceIn(0f, 1f) }
    return when (id) {
        "battery" -> TileInfo(
            stringResource(R.string.battery), last?.batteryLevel?.let { "$it%" } ?: "—",
            listOfNotNull(
                ui.tempBatt.lastOrNull()?.let { Fmt.temp(it, d.unit) },
                if (last?.batteryCharging == true) stringResource(R.string.charging) else null,
            ).joinToString(" · ").ifBlank { na },
            last?.batteryLevel?.let { it / 100f }, ui.tempBatt.map { Fmt.tempValue(it, d.unit) }, null, Category.BATTERY,
        )
        "cpu" -> {
            val maxKHz = last?.cpuFreqKHz?.filterNotNull()?.maxOrNull()
            TileInfo(
                stringResource(R.string.cat_cpu), maxKHz?.let { Fmt.one(it / 1_000_000.0) + " GHz" } ?: "—",
                ui.cpuTempC?.let { Fmt.temp(it, d.unit) } ?: na, null, ui.tempCpu.map { Fmt.tempValue(it, d.unit) }, null, Category.CPU,
            )
        }
        "ram" -> TileInfo(
            stringResource(R.string.ram), last?.let { Fmt.one(it.ramUsedPercent.toDouble()) + "%" } ?: "—",
            last?.let { stringResource(R.string.ram_free, Fmt.bytes(it.ramAvailBytes)) } ?: na,
            frac(last?.ramUsedPercent), ui.ram, null, Category.MEMORY,
        )
        "load" -> TileInfo(
            stringResource(R.string.load), ui.loadPercent?.let { "$it%" } ?: "—",
            ui.loadPercent?.let { stringResource(R.string.load_all_cores) } ?: na,
            ui.loadPercent?.let { it / 100f }, emptyList(), null, Category.CPU,
        )
        "storage" -> {
            val st = remember(last?.timestamp) {
                runCatching { StatFs(Environment.getDataDirectory().absolutePath).let { it.totalBytes to it.availableBytes } }.getOrNull()
            }
            val write = d.lastBench?.scores?.firstOrNull { it.id == "st_write" }?.value
            val read = d.lastBench?.scores?.firstOrNull { it.id == "st_read" }?.value
            TileInfo(
                stringResource(R.string.storage_used), last?.let { Fmt.one(it.storageUsedPercent.toDouble()) + "%" } ?: "—",
                st?.let { stringResource(R.string.storage_of, Fmt.bytes(it.first - it.second), Fmt.bytes(it.first)) } ?: na,
                frac(last?.storageUsedPercent), emptyList(),
                listOfNotNull(
                    st?.let { stringResource(R.string.ram_free, Fmt.bytes(it.second)) },
                    if (write != null && read != null) stringResource(R.string.storage_speeds, Fmt.one(write), Fmt.one(read)) else null,
                ).joinToString("\n").ifBlank { null },
                Category.STORAGE,
            )
        }
        "gpu" -> TileInfo(
            stringResource(R.string.cat_gpu), ui.gpuMHz?.let { "$it MHz" } ?: "—",
            ui.gpuBusy?.let { stringResource(R.string.load) + " $it%" } ?: na,
            ui.gpuBusy?.let { it / 100f }, emptyList(), null, Category.GPU,
        )
        else -> null
    }
}

/** The inside of one block. Which design is used depends on [size]: 1 small tile, 2 wide, 3 wide with a chart. */
@Composable
internal fun BlockBody(id: String, size: Int, d: HomeData) {
    val go: ((Category) -> Unit)? = if (d.editing) null else d.onOpen
    val long: (() -> Unit)? = if (d.editing) null else d.onEdit
    val spec = specOf(id) ?: return
    val cols = HomeBlocks.cols(size)
    val rows = HomeBlocks.rows(size)
    // The look of a block follows its shape: one cell, one wide row, or something taller.
    val st = if (rows == 1 && cols == 1) HomeBlocks.SMALL else if (rows == 1) HomeBlocks.MEDIUM else HomeBlocks.LARGE

    if (id.startsWith("fn:")) {
        val route = spec.route ?: return
        val click: (() -> Unit)? = if (d.editing) null else ({ d.onRoute(route) })
        if (cols == 1 || rows > 1) {
            Column(
                Modifier.fillMaxSize().cardSurface(RoundedCornerShape(24.dp)).tap(click, long).padding(horizontal = 18.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(spec.icon, null, Modifier.size(if (rows > 1) 44.dp else 28.dp))
                Text(stringResource(spec.title), style = if (rows > 1) MaterialTheme.typography.titleLarge else MaterialTheme.typography.titleMedium, maxLines = 2)
                if (rows > 1) spec.desc?.let { Text(stringResource(it), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        } else {
            ItemRow(
                stringResource(spec.title), spec.desc?.let { stringResource(it) }, icon = spec.icon,
                modifier = Modifier.fillMaxSize(), shape = RoundedCornerShape(24.dp), onClick = click, onLongClick = long, chevron = !d.editing,
            )
        }
        return
    }

    when (id) {
        "bench" -> if (cols == 1 || rows == 1) {
            Column(
                Modifier.fillMaxSize().cardSurface(RoundedCornerShape(24.dp))
                    .tap(if (d.editing) null else ({ d.onBench(false) }), long).padding(horizontal = 18.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(stringResource(R.string.bench_total), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(d.lastBench?.let { com.nexus.device.bench.formatPoints(it.total) } ?: "—", style = MaterialTheme.typography.headlineMedium)
                Text(stringResource(R.string.bench_tap), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            BenchHomeCard(d.bench, { if (!d.editing) d.onBench(false) }, { if (!d.editing) d.onBench(true) }, Modifier.fillMaxSize())
        }

        "device" -> {
            fun item(title: String) = d.ui.summary.firstOrNull { it.title == title }?.value
            if (cols == 1) {
                Column(
                    Modifier.fillMaxSize().cardSurface(RoundedCornerShape(24.dp)).tap(go?.let { g -> { g(Category.SYSTEM) } }, long)
                        .padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(stringResource(R.string.tile_device), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(item("Model") ?: "—", style = MaterialTheme.typography.titleLarge, maxLines = 2)
                    Text(item("Android") ?: "", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                val name = listOfNotNull(item("Manufacturer"), item("Model")).joinToString(" ")
                val more = d.ui.summary.filter { it.title != "Manufacturer" && it.title != "Model" }.map { it.value }
                if (rows == 1) {
                    Column(
                        Modifier.fillMaxSize().cardSurface(RoundedCornerShape(24.dp)).tap(go?.let { g -> { g(Category.SYSTEM) } }, long)
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Text(name.ifBlank { "—" }, style = MaterialTheme.typography.titleLarge)
                        Text(
                            listOfNotNull(item("Android"), item("Processor")).joinToString(" · "),
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            listOfNotNull(item("RAM")?.let { "RAM $it" }, item("Display")).joinToString(" · "),
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    // A taller block shows everything the summary knows, one value per line.
                    Column(
                        Modifier.fillMaxSize().cardSurface(RoundedCornerShape(24.dp)).tap(go?.let { g -> { g(Category.SYSTEM) } }, long)
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(name.ifBlank { "—" }, style = if (rows >= 3) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge)
                        more.take(if (rows >= 3) 8 else 4).forEach {
                            Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
        }

        "temp" -> {
            val ui = d.ui
            val batt = ui.tempBatt.map { Fmt.tempValue(it, d.unit) }
            val cpu = ui.tempCpu.map { Fmt.tempValue(it, d.unit) }
            if (cols == 1 && rows == 1) {
                Column(
                    Modifier.fillMaxSize().cardSurface(RoundedCornerShape(24.dp)).tap(null, long).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(stringResource(R.string.temperature), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(ui.cpuTempC?.let { Fmt.temp(it, d.unit) } ?: "—", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        stringResource(R.string.temp_battery) + " " + (ui.tempBatt.lastOrNull()?.let { Fmt.temp(it, d.unit) } ?: "—"),
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                Column(
                    Modifier.fillMaxSize().cardSurface(RoundedCornerShape(24.dp)).tap(null, long).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stringResource(R.string.temperature), style = MaterialTheme.typography.bodyLarge)
                        if (cols == 2) Text(
                            stringResource(R.string.temp_battery) + " · " + stringResource(R.string.temp_cpu),
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (batt.size >= 2 || cpu.size >= 2) {
                        LineChart(listOf(batt, cpu), if (rows > 1) Modifier.fillMaxWidth().weight(1f) else Modifier.fillMaxWidth().height(48.dp), maxPoints = 40)
                    } else {
                        Text(stringResource(R.string.st_na), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        else -> {
            val info = tileInfo(id, d) ?: return
            val click: (() -> Unit)? = go?.let { g -> { g(info.open) } }
            val shape = RoundedCornerShape(24.dp)
            when (st) {
                HomeBlocks.SMALL -> Column(
                    Modifier.fillMaxSize().cardSurface(shape).tap(click, long).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(info.title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(info.big, style = MaterialTheme.typography.headlineMedium)
                    Text(info.small, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                HomeBlocks.MEDIUM -> Column(
                    Modifier.fillMaxSize().cardSurface(shape).tap(click, long).padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(info.title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(info.big, style = MaterialTheme.typography.headlineMedium)
                        }
                        Text(
                            info.small, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.End, modifier = Modifier.weight(1f),
                        )
                    }
                    info.fraction?.let { Bar(it) }
                }
                else -> Column(
                    Modifier.fillMaxSize().cardSurface(shape).tap(click, long).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(info.title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (info.chart.size >= 2 || info.extra != null) {
                        Text(info.big, style = if (cols == 1) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.displaySmall)
                        Text(info.small, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        info.fraction?.let { Bar(it) }
                        if (info.chart.size >= 2) LineChart(listOf(info.chart), Modifier.fillMaxWidth().weight(1f).heightIn(min = 40.dp), maxPoints = 40)
                        info.extra?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                    } else {
                        // Nothing more to tell about this figure, so the figure itself grows to fill the block.
                        val big = (if (rows >= 3) 84 else 60) * (if (cols == 1) 0.7f else 1f)
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text(info.big, style = MaterialTheme.typography.displayLarge.copy(fontSize = big.sp, lineHeight = (big * 1.1f).sp), maxLines = 1)
                        }
                        Text(info.small, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        info.fraction?.let { Bar(it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Bar(fraction: Float) {
    LinearProgressIndicator(
        progress = { fraction }, modifier = Modifier.fillMaxWidth().height(6.dp),
        trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f),
    )
}

@Composable
internal fun blockTitle(id: String): String = specOf(id)?.let { stringResource(it.title) } ?: id
