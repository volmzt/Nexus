package com.nexus.device.hardware

import android.os.Build
import android.os.Process
import com.nexus.device.core.Availability
import com.nexus.device.core.Spec
import com.nexus.device.core.spec
import com.nexus.device.domain.Category
import com.nexus.device.domain.SpecProvider
import java.io.File

object CpuInfo {
    class Parsed(val global: Map<String, String>, val cores: List<Map<String, String>>)

    fun parse(): Parsed? = try {
        val text = File("/proc/cpuinfo").readText()
        val blocks = text.split("\n\n").map { block ->
            block.lines().mapNotNull { line ->
                val i = line.indexOf(':')
                if (i < 0) null else line.substring(0, i).trim() to line.substring(i + 1).trim()
            }.toMap()
        }.filter { it.isNotEmpty() }
        val cores = blocks.filter { it.containsKey("processor") }
        var global = emptyMap<String, String>()
        for (b in blocks) global = global + b.filterKeys { it !in global.keys }
        Parsed(global, cores)
    } catch (e: Exception) {
        null
    }

    // ARM implementer 0x41 part ids. Approximate: a lookup table, not read from hardware.
    private val armParts = mapOf(
        "0xd03" to "Cortex-A53", "0xd05" to "Cortex-A55", "0xd07" to "Cortex-A57", "0xd08" to "Cortex-A72",
        "0xd09" to "Cortex-A73", "0xd0a" to "Cortex-A75", "0xd0b" to "Cortex-A76", "0xd0d" to "Cortex-A77",
        "0xd41" to "Cortex-A78", "0xd44" to "Cortex-X1", "0xd46" to "Cortex-A510", "0xd47" to "Cortex-A710",
        "0xd48" to "Cortex-X2", "0xd4d" to "Cortex-A715", "0xd4e" to "Cortex-X3", "0xd80" to "Cortex-A520",
        "0xd81" to "Cortex-A720", "0xd82" to "Cortex-X4", "0xd85" to "Cortex-X925", "0xd87" to "Cortex-A725",
    )

    fun coreTypeSummary(p: Parsed): String? {
        val groups = p.cores.groupingBy {
            val impl = it["CPU implementer"]?.lowercase()
            val part = it["CPU part"]?.lowercase()
            if (impl == "0x41" && part != null) armParts[part] ?: "ARM part $part"
            else if (impl != null && part != null) "implementer $impl part $part"
            else "unknown"
        }.eachCount()
        if (groups.isEmpty() || groups.keys == setOf("unknown")) return null
        return groups.entries.joinToString(", ") { "${it.value}× ${it.key}" }
    }

    fun socName(): String? {
        if (Build.VERSION.SDK_INT >= 31) {
            val m = Build.SOC_MODEL
            val v = Build.SOC_MANUFACTURER
            if (m.isNotBlank() && m != Build.UNKNOWN) return if (v.isNotBlank() && v != Build.UNKNOWN) "$v $m" else m
        }
        return parse()?.global?.get("Hardware")?.takeIf { it.isNotBlank() } ?: Build.HARDWARE.takeIf { it.isNotBlank() }
    }
}

/** Reads cpufreq files. Many devices hide them from apps; null then means "not exposed", never a guess. */
object CpuFreqReader {
    private fun read(path: String): Long? = try {
        File(path).readText().trim().toLongOrNull()
    } catch (e: Exception) {
        null
    }

    fun currentKHz(core: Int) = read("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_cur_freq")
    fun maxKHz(core: Int) = read("/sys/devices/system/cpu/cpu$core/cpufreq/cpuinfo_max_freq")
    fun minKHz(core: Int) = read("/sys/devices/system/cpu/cpu$core/cpufreq/cpuinfo_min_freq")
    fun allCurrent(): List<Long?> = (0 until Runtime.getRuntime().availableProcessors()).map { currentKHz(it) }
}

class CpuProvider : SpecProvider {
    override val category = Category.CPU

    override fun read(): List<Spec> {
        val out = mutableListOf<Spec>()
        val parsed = CpuInfo.parse()
        val n = Runtime.getRuntime().availableProcessors()
        out += spec("SoC") { CpuInfo.socName() }
        out += spec("Hardware (cpuinfo)") { parsed?.global?.get("Hardware") }
        out += spec("Board") { Build.BOARD.takeIf { it.isNotBlank() } }
        out += Spec("Cores", n.toString())
        out += spec("Core types", approximate = true, reason = "Not exposed by /proc/cpuinfo") { parsed?.let { CpuInfo.coreTypeSummary(it) } }
        out += Spec("Architecture", if (Process.is64Bit()) "ARM64 (64-bit process)" else "32-bit process")
        out += Spec("Supported ABIs", Build.SUPPORTED_ABIS.joinToString(", "))
        out += Spec("64-bit ABIs", Build.SUPPORTED_64_BIT_ABIS.joinToString(", ").ifBlank { "none" })
        out += spec("Instruction set features") { parsed?.global?.get("Features") ?: parsed?.global?.get("flags") }
        out += spec("CPU architecture") { parsed?.global?.get("CPU architecture") }
        out += Spec("Address space", if (Process.is64Bit()) "64-bit user space" else "32-bit user space")
        for (i in 0 until n) {
            val cur = CpuFreqReader.currentKHz(i)
            val min = CpuFreqReader.minKHz(i)
            val max = CpuFreqReader.maxKHz(i)
            out += if (min != null && max != null) {
                Spec("cpu$i range", "${min / 1000}–${max / 1000} MHz")
            } else {
                Spec("cpu$i range", "Not exposed by Android", Availability.UNAVAILABLE)
            }
            out += if (cur != null) {
                Spec("cpu$i current", "${cur / 1000} MHz (at this moment)")
            } else {
                Spec("cpu$i current", "Not exposed by Android", Availability.UNAVAILABLE)
            }
        }
        return out
    }
}
