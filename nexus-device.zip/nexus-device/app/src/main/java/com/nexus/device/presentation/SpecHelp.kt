package com.nexus.device.presentation

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nexus.device.R
import com.nexus.device.core.Availability
import com.nexus.device.core.Spec
import com.nexus.device.domain.Category

/**
 * Maps the label of a value to its plain-language explanation.
 * Returns null for labels without a specific explanation; the dialog then shows a generic text.
 */
fun helpRes(label: String): Int? = when {
    label == "SoC" -> R.string.help_soc
    label == "Hardware (cpuinfo)" -> R.string.help_hw
    label == "Cores" -> R.string.help_cores
    label == "Core types" -> R.string.help_core_types
    label in setOf("Supported ABIs", "64-bit ABIs", "CPU architecture", "Architecture") -> R.string.help_abi
    label == "Instruction set features" -> R.string.help_isa
    Regex("cpu\\d+ (current|range)").matches(label) -> R.string.help_cpu_freq
    label == "Renderer (GPU)" -> R.string.help_renderer
    label.startsWith("OpenGL ES") -> R.string.help_gles
    label.startsWith("Vulkan") -> R.string.help_vulkan
    label == "GLSL version" -> R.string.help_glsl
    label == "Driver version" -> R.string.help_gpu_driver
    label in setOf("Total RAM", "Available RAM", "Used RAM (whole system)", "Used share (whole system)") -> R.string.help_ram
    label in setOf("Low RAM device", "Low memory state", "Low memory threshold", "Memory class") -> R.string.help_lowmem
    label.startsWith("This app: heap") -> R.string.help_heap
    label in setOf("Density", "Measured pixel density") -> R.string.help_density
    label in setOf("Logical resolution", "Physical resolution") -> R.string.help_resolution
    label.startsWith("Refresh rate") || label == "Supported modes" -> R.string.help_refresh
    label in setOf("HDR types", "Wide colour gamut") -> R.string.help_hdr
    label == "Temperature" -> R.string.help_batt_temp
    label == "Health" -> R.string.help_health
    label == "Current now" -> R.string.help_current
    label == "Charge cycles" -> R.string.help_cycles
    label in setOf("Design capacity", "Estimated full capacity") -> R.string.help_capacity
    label == "Voltage" -> R.string.help_voltage
    label == "Security patch" -> R.string.help_patch
    label == "API level" -> R.string.help_api
    label == "Build fingerprint" -> R.string.help_fingerprint
    label == "Bootloader" -> R.string.help_bootloader
    label == "Linux kernel" -> R.string.help_kernel
    label == "Build type" -> R.string.help_buildtype
    label == "Uptime (incl. sleep)" -> R.string.help_uptime
    label == "Wi-Fi signal (RSSI)" -> R.string.help_rssi
    label.endsWith("bandwidth (estimate)") -> R.string.help_bw
    label == "Metered" -> R.string.help_metered
    label == "Wi-Fi SSID / BSSID" -> R.string.help_ssid
    label == "Serial number" -> R.string.help_serial
    label in setOf("Package visibility", "Visible apps") -> R.string.help_pkgvis
    label.startsWith("Camera ") -> R.string.help_camera
    label.endsWith("· total") || label.endsWith("· used") || label.endsWith("· free") || label.endsWith("· removable") -> R.string.help_storage_part
    else -> null
}

/** Rows that deserve a "?" mark in the list. */
fun hasHelp(spec: Spec): Boolean = helpRes(spec.label) != null

/**
 * Simple view keeps values that are present and short.
 * If that would leave nothing, the full list is shown instead of an empty page.
 */
fun List<Spec>.forView(detailed: Boolean): List<Spec> {
    if (detailed) return this
    val simple = filter { it.availability != Availability.UNAVAILABLE && it.availability != Availability.PERMISSION && it.value.length <= 60 }
    return simple.ifEmpty { this }
}

/** One-line summary for a category, built only from values that were really read. */
fun categorySummary(cat: Category, specs: List<Spec>): String? {
    fun v(label: String) = specs.firstOrNull { it.label == label && it.availability != Availability.UNAVAILABLE && it.availability != Availability.PERMISSION }?.value
    val parts: List<String?> = when (cat) {
        Category.CPU -> listOf(v("SoC") ?: v("Hardware (cpuinfo)"), v("Cores")?.let { "$it cores" })
        Category.GPU -> listOf(v("Renderer (GPU)"))
        Category.MEMORY -> listOf(v("Total RAM"))
        Category.STORAGE -> listOf(specs.firstOrNull { it.label.endsWith("· total") && it.availability == Availability.AVAILABLE }?.value)
        Category.SYSTEM -> listOf(v("Model"), v("Android version")?.let { "Android $it" })
        Category.DISPLAY -> listOf(v("Physical resolution"), v("Refresh rate (max)"))
        Category.BATTERY -> listOf(v("Level"), v("Health"))
        Category.NETWORK -> listOf(v("Connection"))
        Category.SENSORS -> listOf(v("Sensors"))
        Category.CAMERA -> listOf(v("Cameras"))
        Category.CODECS, Category.APPS -> emptyList()
    }
    return parts.filterNotNull().joinToString(" · ").ifBlank { null }
}

@Composable
fun SpecInfoDialog(spec: Spec, onDismiss: () -> Unit, onCopy: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(spec.label) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(spec.value, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                Text(stringResource(R.string.dlg_what_is_it), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(helpRes(spec.label) ?: R.string.help_generic), style = MaterialTheme.typography.bodyMedium)
                val note = when (spec.availability) {
                    Availability.APPROXIMATE -> R.string.help_approx
                    Availability.UNAVAILABLE -> R.string.help_na
                    Availability.PERMISSION -> R.string.help_perm
                    Availability.AVAILABLE -> null
                }
                if (note != null) Text(stringResource(note), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = onCopy) { Text(stringResource(R.string.dlg_copy)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } },
    )
}

/** Emits the explanation dialog when a row is tapped and returns the function that opens it. */
@Composable
fun rememberSpecDialog(): (Spec) -> Unit {
    var selected by remember { mutableStateOf<Spec?>(null) }
    val copy = rememberCopier()
    selected?.let { s ->
        SpecInfoDialog(s, onDismiss = { selected = null }, onCopy = { copy(s.value); selected = null })
    }
    return { selected = it }
}

/** Two-option switch: Simple / Detailed. The highlight colour animates, there is no ripple. */
@Composable
fun ViewModeToggle(detailed: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainer).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        listOf(false to R.string.view_simple, true to R.string.view_detailed).forEach { (mode, res) ->
            val on = detailed == mode
            val bg by animateColorAsState(
                if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f) else androidx.compose.ui.graphics.Color.Transparent,
                tween(300), label = "mode",
            )
            Box(
                Modifier.weight(1f).clip(CircleShape).background(bg)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onChange(mode) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    stringResource(res), style = MaterialTheme.typography.labelLarge,
                    color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
