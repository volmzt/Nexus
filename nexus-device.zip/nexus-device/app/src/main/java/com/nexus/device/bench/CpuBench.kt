package com.nexus.device.bench

import java.util.zip.Deflater
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * CPU tests. Each one repeats a small, fixed piece of work for a fixed time and reports how many repeats fit in a second,
 * so the score does not depend on how fast the phone is. The result of every run feeds [sink] so it cannot be optimised away.
 */
object CpuBench {
    @Volatile
    var sink = 0L

    private const val WARMUP_MS = 300L
    private const val SIEVE_N = 100_000
    private const val MAT_N = 48

    private val sieveLocal = ThreadLocal.withInitial { BooleanArray(SIEVE_N + 1) }

    private class Mat {
        val a = DoubleArray(MAT_N * MAT_N) { (it % 7) * 0.5 + 1.0 }
        val b = DoubleArray(MAT_N * MAT_N) { (it % 5) * 0.25 + 0.5 }
        val c = DoubleArray(MAT_N * MAT_N)
    }

    private val matLocal = ThreadLocal.withInitial { Mat() }

    /** Runs [kernel] after a short warm-up for [budgetMs] and returns runs per second. */
    fun rate(budgetMs: Long, kernel: () -> Unit): Double {
        val warmEnd = System.nanoTime() + WARMUP_MS * 1_000_000L
        while (System.nanoTime() < warmEnd) kernel()
        var runs = 0L
        val start = System.nanoTime()
        val end = start + budgetMs * 1_000_000L
        var now = start
        while (now < end) {
            kernel()
            runs++
            now = System.nanoTime()
        }
        return runs * 1e9 / (now - start)
    }

    private fun integerKernel() {
        val s = sieveLocal.get()!!
        java.util.Arrays.fill(s, true)
        var i = 2
        while (i * i <= SIEVE_N) {
            if (s[i]) {
                var j = i * i
                while (j <= SIEVE_N) { s[j] = false; j += i }
            }
            i++
        }
        var count = 0
        var h = 0x9E3779B9L.toInt()
        for (k in 2..SIEVE_N) {
            if (s[k]) { count++; h = (h xor k) * 16777619 }
        }
        sink += (count + h).toLong()
    }

    private fun floatKernel() {
        val m = matLocal.get()!!
        val n = MAT_N
        for (i in 0 until n) {
            for (j in 0 until n) {
                var sum = 0.0
                for (k in 0 until n) sum += m.a[i * n + k] * m.b[k * n + j]
                m.c[i * n + j] = sum
            }
        }
        sink += m.c[n + 1].toLong()
    }

    fun integer(): Double = rate(2200) { integerKernel() }

    fun float(): Double = rate(2200) { floatKernel() }

    /** AES-256 in CBC mode over 256 KB, in MB/s. Uses the phone's crypto provider, so it shows hardware AES if present. */
    fun crypto(): Double {
        val data = ByteArray(256 * 1024) { (it * 31).toByte() }
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        val key = SecretKeySpec(ByteArray(32) { it.toByte() }, "AES")
        val iv = IvParameterSpec(ByteArray(16))
        val runs = rate(2200) {
            cipher.init(Cipher.ENCRYPT_MODE, key, iv)
            sink += cipher.doFinal(data).size.toLong()
        }
        return runs * 0.25
    }

    /** Deflate level 6 over about 512 KB of text-like data, in MB/s of input. */
    fun zip(): Double {
        val words = arrayOf("nexus", "device", "kernel", "thermal", "battery", "display", "memory", "sensor")
        val text = StringBuilder()
        var x = 12345
        while (text.length < 512 * 1024) {
            x = x * 1103515245 + 12345
            text.append(words[(x ushr 16) and 7]).append(' ')
        }
        val bytes = text.toString().toByteArray()
        val out = ByteArray(bytes.size + 1024)
        val deflater = Deflater(6)
        val runs = rate(2200) {
            deflater.reset()
            deflater.setInput(bytes)
            deflater.finish()
            var total = 0
            while (!deflater.finished()) total += deflater.deflate(out)
            sink += total.toLong()
        }
        deflater.end()
        return runs * bytes.size / 1048576.0
    }

    /** Integer and float work on every core at once; returns completed pairs per second across all threads. */
    fun multi(): Double {
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, 16)
        val counts = LongArray(cores)
        val deadline = System.nanoTime() + 2_500_000_000L
        val threads = List(cores) { idx ->
            Thread {
                var n = 0L
                while (System.nanoTime() < deadline) {
                    integerKernel()
                    floatKernel()
                    n++
                }
                counts[idx] = n
            }
        }
        val start = System.nanoTime()
        threads.forEach { it.start() }
        threads.forEach { it.join() }
        return counts.sum() / ((System.nanoTime() - start) / 1e9)
    }
}
