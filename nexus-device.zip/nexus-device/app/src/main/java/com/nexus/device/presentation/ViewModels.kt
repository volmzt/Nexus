package com.nexus.device.presentation

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexus.device.core.Spec
import com.nexus.device.core.TempUnit
import com.nexus.device.core.di.AppContainer
import com.nexus.device.data.AppSettings
import com.nexus.device.data.ThemeMode
import com.nexus.device.database.BenchmarkResultEntity
import com.nexus.device.database.MonitorSessionEntity
import com.nexus.device.diagnostics.AnalysisResult
import com.nexus.device.diagnostics.BenchmarkRunner
import com.nexus.device.diagnostics.LatencyResult
import com.nexus.device.diagnostics.LatencyTester
import com.nexus.device.diagnostics.StorageAnalyzer
import com.nexus.device.diagnostics.ThermalAbort
import com.nexus.device.domain.Category
import com.nexus.device.domain.Sample
import com.nexus.device.hardware.DeviceSummary
import com.nexus.device.hardware.SummaryItem
import com.nexus.device.hardware.ThermalReader
import com.nexus.device.reporting.ReportBuilder
import com.nexus.device.reporting.ReportFormat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.runningFold
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModelFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        HomeViewModel::class.java -> HomeViewModel(c)
        DeviceViewModel::class.java -> DeviceViewModel(c)
        MonitorViewModel::class.java -> MonitorViewModel(c)
        BenchmarkViewModel::class.java -> BenchmarkViewModel(c)
        SettingsViewModel::class.java -> SettingsViewModel(c)
        AnalyzerViewModel::class.java -> AnalyzerViewModel(c)
        NetDiagViewModel::class.java -> NetDiagViewModel()
        else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
    } as T
}

class HomeViewModel(private val c: AppContainer) : ViewModel() {
    data class Ui(
        val summary: List<SummaryItem> = emptyList(),
        val ram: List<Float> = emptyList(),
        val temp: List<Float> = emptyList(),
        val battery: List<Float> = emptyList(),
        val storage: List<Float> = emptyList(),
        val last: Sample? = null,
        /** Hottest CPU-like thermal zone, null when Android hides the thermal files. */
        val cpuTempC: Float? = null,
    )

    private val refreshTick = MutableStateFlow(0)
    private val summary = MutableStateFlow<List<SummaryItem>>(emptyList())

    init { loadSummary() }

    private fun loadSummary() {
        viewModelScope.launch(Dispatchers.Default) { summary.value = DeviceSummary.build(c.context) }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val ui: StateFlow<Ui> = refreshTick
        .flatMapLatest { flow { while (true) { emit(c.sampler.sample()); delay(2000) } } }
        .runningFold(Ui()) { acc, s ->
            acc.copy(
                ram = (acc.ram + s.ramUsedPercent).takeLast(30),
                temp = s.batteryTempC?.let { (acc.temp + it).takeLast(30) } ?: acc.temp,
                battery = s.batteryLevel?.let { (acc.battery + it.toFloat()).takeLast(30) } ?: acc.battery,
                storage = (acc.storage + s.storageUsedPercent).takeLast(30),
                last = s,
                cpuTempC = ThermalReader.cpuTempC(),
            )
        }
        .combine(summary) { u, sum -> u.copy(summary = sum) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Ui())

    fun refresh() {
        refreshTick.value++
        loadSummary()
    }
}

class DeviceViewModel(private val c: AppContainer) : ViewModel() {
    val all = MutableStateFlow<Map<Category, List<Spec>>>(emptyMap())
    val loading = MutableStateFlow(true)
    val query = MutableStateFlow("")

    val results: StateFlow<List<Pair<Category, Spec>>> = combine(all, query) { a, q ->
        val needle = q.trim()
        if (needle.isEmpty()) emptyList()
        else a.flatMap { (cat, list) -> list.filter { (it.label + " " + it.value).contains(needle, ignoreCase = true) }.map { cat to it } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init { reload() }

    fun reload() {
        viewModelScope.launch {
            loading.value = true
            all.value = c.devices.readAll()
            loading.value = false
        }
    }
}

enum class Metric { RAM, TEMP, BATTERY, STORAGE }

class MonitorViewModel(private val c: AppContainer) : ViewModel() {
    data class Ui(val running: Boolean = false, val samples: List<Sample> = emptyList(), val metric: Metric = Metric.RAM)

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    val sessions: StateFlow<List<MonitorSessionEntity>> =
        c.database.sessionDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val intervalMs: StateFlow<Long> =
        c.settings.settings.map { it.intervalMs }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1000L)

    private var job: Job? = null
    private var startedAt = 0L
    private val collected = ArrayList<Sample>()

    fun setMetric(m: Metric) = _ui.update { it.copy(metric = m) }
    fun setInterval(ms: Long) { viewModelScope.launch { c.settings.setInterval(ms) } }

    fun start() {
        if (job != null) return
        collected.clear()
        startedAt = System.currentTimeMillis()
        _ui.update { it.copy(running = true, samples = emptyList()) }
        job = viewModelScope.launch(Dispatchers.Default) {
            while (isActive) {
                val s = c.sampler.sample()
                collected.add(s)
                _ui.update { it.copy(samples = (it.samples + s).takeLast(60)) }
                delay(intervalMs.value)
            }
        }
    }

    fun stop() {
        val wasRunning = job != null
        job?.cancel()
        job = null
        _ui.update { it.copy(running = false) }
        if (wasRunning && collected.size >= 2) {
            val data = ArrayList(collected)
            val began = startedAt
            viewModelScope.launch(Dispatchers.IO) {
                val temps = data.mapNotNull { it.batteryTempC }
                c.database.sessionDao().insert(
                    MonitorSessionEntity(
                        startedAt = began,
                        durationMs = data.last().timestamp - began,
                        samples = data.size,
                        ramAvg = data.map { it.ramUsedPercent.toDouble() }.average(),
                        ramMax = data.maxOf { it.ramUsedPercent }.toDouble(),
                        tempMax = temps.maxOrNull()?.toDouble(),
                        batteryStart = data.first().batteryLevel,
                        batteryEnd = data.last().batteryLevel,
                    ),
                )
            }
        }
    }
}

class BenchmarkViewModel(private val c: AppContainer) : ViewModel() {
    data class Ui(val running: String? = null, val heatC: Float? = null, val error: String? = null)

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()
    val history: StateFlow<List<BenchmarkResultEntity>> =
        c.database.benchmarkDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var job: Job? = null

    private suspend fun runOne(id: String): Boolean {
        _ui.update { it.copy(running = id, heatC = null, error = null) }
        return try {
            for (r in c.benchmark.run(id)) {
                val v = r.value
                if (v != null) {
                    c.database.benchmarkDao().insert(BenchmarkResultEntity(testId = r.test.id, value = v, unit = r.test.unit, timestamp = System.currentTimeMillis()))
                } else if (r.message != null) {
                    _ui.update { it.copy(error = r.test.name + ": " + r.message) }
                }
            }
            true
        } catch (t: ThermalAbort) {
            _ui.update { it.copy(heatC = t.tempC) }
            false
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            _ui.update { it.copy(error = e.message ?: e.javaClass.simpleName) }
            true
        }
    }

    fun run(id: String) {
        if (job != null) return
        job = viewModelScope.launch { try { runOne(id) } finally { _ui.update { it.copy(running = null) }; job = null } }
    }

    fun runAll() {
        if (job != null) return
        job = viewModelScope.launch {
            try {
                for (t in BenchmarkRunner.tests) if (!runOne(t.id)) break
            } finally {
                _ui.update { it.copy(running = null) }
                job = null
            }
        }
    }

    fun cancel() { job?.cancel() }
}

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setTheme(t: ThemeMode) { viewModelScope.launch { c.settings.setTheme(t) } }
    fun setUnit(u: TempUnit) { viewModelScope.launch { c.settings.setUnit(u) } }
    fun setHideIds(v: Boolean) { viewModelScope.launch { c.settings.setHideIds(v) } }
    fun setDetailed(v: Boolean) { viewModelScope.launch { c.settings.setDetailed(v) } }
    fun setCategoryHidden(id: String, hidden: Boolean) { viewModelScope.launch { c.settings.setCategoryHidden(id, hidden) } }

    fun clearHistory(onDone: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            c.database.benchmarkDao().clear()
            c.database.sessionDao().clear()
            withContext(Dispatchers.Main) { onDone() }
        }
    }

    suspend fun buildReport(format: ReportFormat, titles: Map<Category, String>, version: String): String {
        val all = c.devices.readAll()
        return withContext(Dispatchers.Default) { ReportBuilder.build(all, titles, format, settings.value.hideIds, version) }
    }
}

class AnalyzerViewModel(private val c: AppContainer) : ViewModel() {
    data class Ui(val running: Boolean = false, val progress: Int = 0, val result: AnalysisResult? = null, val error: String? = null)

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    fun analyze(tree: Uri) {
        if (_ui.value.running) return
        _ui.value = Ui(running = true)
        viewModelScope.launch {
            try {
                val r = StorageAnalyzer.analyze(c.context, tree) { n -> _ui.update { it.copy(progress = n) } }
                _ui.value = Ui(result = r)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.value = Ui(error = e.message ?: e.javaClass.simpleName)
            }
        }
    }
}

class NetDiagViewModel : ViewModel() {
    data class Ui(val running: Boolean = false, val history: List<LatencyResult> = emptyList())

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    fun run(url: String, count: Int = 4) {
        if (_ui.value.running || url.isBlank()) return
        _ui.update { it.copy(running = true) }
        viewModelScope.launch {
            try {
                repeat(count) {
                    val r = LatencyTester.ping(url.trim())
                    _ui.update { s -> s.copy(history = (s.history + r).takeLast(40)) }
                    delay(300)
                }
            } finally {
                _ui.update { it.copy(running = false) }
            }
        }
    }

    fun clear() { _ui.update { it.copy(history = emptyList()) } }
}
