package com.nexus.device.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.nexus.device.core.Spec
import com.nexus.device.core.TempUnit
import com.nexus.device.core.di.AppContainer
import com.nexus.device.data.AppSettings
import com.nexus.device.data.ThemeMode
import com.nexus.device.data.VisualStyle
import com.nexus.device.domain.Category
import com.nexus.device.domain.Sample
import com.nexus.device.hardware.DeviceSummary
import com.nexus.device.hardware.SummaryItem
import com.nexus.device.control.ControlRepo
import com.nexus.device.monitoring.TempReader
import com.nexus.device.monitoring.BatteryRecorder
import com.nexus.device.presentation.battery.BatteryHealthViewModel
import com.nexus.device.reporting.ReportBuilder
import com.nexus.device.reporting.ReportFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.runningFold
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModelFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        HomeViewModel::class.java -> HomeViewModel(c)
        DeviceViewModel::class.java -> DeviceViewModel(c)
        com.nexus.device.presentation.bench.BenchViewModel::class.java -> com.nexus.device.presentation.bench.BenchViewModel(c)
        SettingsViewModel::class.java -> SettingsViewModel(c)
        ControlViewModel::class.java -> ControlViewModel(c)
        BatteryHealthViewModel::class.java -> BatteryHealthViewModel(c)
        ThrottleViewModel::class.java -> ThrottleViewModel(c)
        else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
    } as T
}

class HomeViewModel(private val c: AppContainer) : ViewModel() {
    data class Ui(
        val summary: List<SummaryItem> = emptyList(),
        val ram: List<Float> = emptyList(),
        val temp: List<Float> = emptyList(),
        val battery: List<Float> = emptyList(),
        val storage: List<Float> = emptyList(),
        val last: Sample? = null,
        /** Steady CPU temperature, null when no thermal sensor is readable. */
        val cpuTempC: Float? = null,
        val tempBatt: List<Float> = emptyList(),
        val tempCpu: List<Float> = emptyList(),
        /** Average load over all cores in percent, null when /proc/stat is not readable. */
        val loadPercent: Int? = null,
        val gpuMHz: Long? = null,
        val gpuBusy: Int? = null,
    )

    private val refreshTick = MutableStateFlow(0)
    private val summary = MutableStateFlow<List<SummaryItem>>(emptyList())

    init { loadSummary() }

    private fun loadSummary() {
        viewModelScope.launch(Dispatchers.Default) { summary.value = DeviceSummary.build(c.context) }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val ui: StateFlow<Ui> = refreshTick
        .flatMapLatest { flow { while (true) { emit(c.sampler.sample()); delay(2000) } } }
        .runningFold(Ui()) { acc, s ->
            val t = TempReader.read(c.context)
            runCatching { BatteryRecorder.record(c.context, c.database.batteryDao()) }
            val loads = ControlRepo.coreLoads()
            val gpu = ControlRepo.gpu()
            acc.copy(
                ram = (acc.ram + s.ramUsedPercent).takeLast(30),
                temp = s.batteryTempC?.let { (acc.temp + it).takeLast(30) } ?: acc.temp,
                tempBatt = t.batteryC?.let { (acc.tempBatt + it).takeLast(40) } ?: acc.tempBatt,
                tempCpu = t.cpuC?.let { (acc.tempCpu + it).takeLast(40) } ?: acc.tempCpu,
                loadPercent = loads.takeIf { it.isNotEmpty() }?.average()?.toInt(),
                gpuMHz = gpu?.curHz?.let { it / 1_000_000 },
                gpuBusy = gpu?.busyPercent,
                battery = s.batteryLevel?.let { (acc.battery + it.toFloat()).takeLast(30) } ?: acc.battery,
                storage = (acc.storage + s.storageUsedPercent).takeLast(30),
                last = s,
                cpuTempC = t.cpuC,
            )
        }
        .combine(summary) { u, sum -> u.copy(summary = sum) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Ui())

    fun refresh() {
        refreshTick.value++
        loadSummary()
    }
}

class DeviceViewModel(private val c: AppContainer) : ViewModel() {
    val all = MutableStateFlow<Map<Category, List<Spec>>>(emptyMap())
    val loading = MutableStateFlow(true)
    val query = MutableStateFlow("")

    val results: StateFlow<List<Pair<Category, Spec>>> = combine(all, query) { a, q ->
        val needle = q.trim()
        if (needle.isEmpty()) emptyList()
        else a.flatMap { (cat, list) -> list.filter { (it.label + " " + it.value).contains(needle, ignoreCase = true) }.map { cat to it } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init { reload() }

    fun reload() {
        viewModelScope.launch {
            loading.value = true
            all.value = c.devices.readAll()
            loading.value = false
        }
    }
}

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setTheme(t: ThemeMode) { viewModelScope.launch { c.settings.setTheme(t) } }
    fun setUnit(u: TempUnit) { viewModelScope.launch { c.settings.setUnit(u) } }
    fun setHideIds(v: Boolean) { viewModelScope.launch { c.settings.setHideIds(v) } }
    fun setDetailed(v: Boolean) { viewModelScope.launch { c.settings.setDetailed(v) } }
    fun setStyle(v: VisualStyle) { viewModelScope.launch { c.settings.setStyle(v) } }
    fun setAnimatedBg(v: Boolean) { viewModelScope.launch { c.settings.setAnimatedBg(v) } }
    fun setPlainHome(v: Boolean) { viewModelScope.launch { c.settings.setPlainHome(v) } }
    fun setTempNotify(v: Boolean) { viewModelScope.launch { c.settings.setTempNotify(v) } }
    fun setStopTemp(v: Int) { viewModelScope.launch { c.settings.setStopTemp(v) } }
    fun setAccent(v: com.nexus.device.data.AccentColor) { viewModelScope.launch { c.settings.setAccent(v) } }
    fun setPalette(v: com.nexus.device.data.BgPalette) { viewModelScope.launch { c.settings.setPalette(v) } }
    fun setBgSpeed(v: Int) { viewModelScope.launch { c.settings.setBgSpeed(v) } }
    fun setCorners(v: Int) { viewModelScope.launch { c.settings.setCorners(v) } }
    fun setTextSize(v: Int) { viewModelScope.launch { c.settings.setTextSize(v) } }
    fun setHomeBlocks(v: List<com.nexus.device.data.HomeBlock>) { viewModelScope.launch { c.settings.setHomeBlocks(v) } }
    fun resetCustomization() { viewModelScope.launch { c.settings.resetCustomization() } }
    fun setCategoryHidden(id: String, hidden: Boolean) { viewModelScope.launch { c.settings.setCategoryHidden(id, hidden) } }

    fun clearHistory(onDone: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            c.database.benchmarkDao().clear()
            c.bench.clear()
            c.database.sessionDao().clear()
            c.database.batteryDao().clear()
            withContext(Dispatchers.Main) { onDone() }
        }
    }

    suspend fun buildReport(format: ReportFormat, titles: Map<Category, String>, version: String): String {
        val all = c.devices.readAll()
        return withContext(Dispatchers.Default) { ReportBuilder.build(all, titles, format, settings.value.hideIds, version) }
    }
}
