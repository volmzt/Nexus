package com.nexus.device.presentation.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.data.AccentColor
import com.nexus.device.data.BgPalette
import com.nexus.device.presentation.SettingsViewModel
import com.nexus.device.presentation.components.SegmentedTabs
import com.nexus.device.presentation.components.cardSurface
import com.nexus.device.presentation.device.DetailHeader
import com.nexus.device.presentation.theme.auroraColors

/** Everything that changes how the app looks, in one place: colours, background, shapes, text size and the Home tiles. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomizeScreen(vm: SettingsViewModel, onBack: () -> Unit, onEditHome: () -> Unit, modifier: Modifier = Modifier) {
    val s by vm.settings.collectAsStateWithLifecycle()

    LazyColumn(
        modifier.fillMaxSize().padding(horizontal = 16.dp), state = rememberLazyListState(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { DetailHeader(stringResource(R.string.custom_title), onBack) }

        item {
            Card(R.string.custom_accent) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val options = listOf(
                        Triple(AccentColor.DEFAULT, R.string.accent_default, Brush.linearGradient(listOf(Color(0xFFE4E6EB), Color(0xFF8E9BAE)))),
                        Triple(AccentColor.BLUE, R.string.accent_blue, Brush.linearGradient(listOf(Color(0xFF4C7DFF), Color(0xFF4C7DFF)))),
                        Triple(AccentColor.VIOLET, R.string.accent_violet, Brush.linearGradient(listOf(Color(0xFF8E5CFF), Color(0xFF8E5CFF)))),
                        Triple(AccentColor.GREEN, R.string.accent_green, Brush.linearGradient(listOf(Color(0xFF2ECC71), Color(0xFF2ECC71)))),
                        Triple(AccentColor.RED, R.string.accent_red, Brush.linearGradient(listOf(Color(0xFFF0524F), Color(0xFFF0524F)))),
                        Triple(AccentColor.ORANGE, R.string.accent_orange, Brush.linearGradient(listOf(Color(0xFFFF9A2E), Color(0xFFFF9A2E)))),
                    ) + if (android.os.Build.VERSION.SDK_INT >= 31) listOf(
                        Triple(AccentColor.WALLPAPER, R.string.accent_wallpaper, Brush.linearGradient(listOf(Color(0xFFFFB4A8), Color(0xFFA8C7FF), Color(0xFFB6F2C2)))),
                    ) else emptyList()
                    options.forEach { (a, label, brush) -> Dot(brush, stringResource(label), s.accent == a) { vm.setAccent(a) } }
                }
            }
        }

        item {
            Card(R.string.custom_palette) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(
                        BgPalette.DEFAULT to R.string.pal_default, BgPalette.OCEAN to R.string.pal_ocean, BgPalette.SUNSET to R.string.pal_sunset,
                        BgPalette.FOREST to R.string.pal_forest, BgPalette.MONO to R.string.pal_mono,
                    ).forEach { (p, label) ->
                        Dot(Brush.linearGradient(auroraColors(p, true)), stringResource(label), s.palette == p) { vm.setPalette(p) }
                    }
                }
                Text(stringResource(R.string.custom_palette_d), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        item {
            Card(R.string.custom_speed) {
                SegmentedTabs(listOf(R.string.speed_slow, R.string.opt_normal, R.string.speed_fast).map { stringResource(it) }, s.bgSpeed, { vm.setBgSpeed(it) })
            }
        }
        item {
            Card(R.string.custom_corners) {
                SegmentedTabs(listOf(R.string.corners_strict, R.string.opt_normal, R.string.corners_soft).map { stringResource(it) }, s.corners, { vm.setCorners(it) })
            }
        }
        item {
            Card(R.string.custom_text) {
                SegmentedTabs(listOf(R.string.text_small, R.string.opt_normal, R.string.text_large).map { stringResource(it) }, s.textSize, { vm.setTextSize(it) })
            }
        }

        item {
            Card(R.string.custom_home) {
                Text(stringResource(R.string.custom_home_d), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(onClick = onEditHome) { Text(stringResource(R.string.custom_edit_home)) }
            }
        }

        item {
            OutlinedButton(onClick = { vm.resetCustomization() }, Modifier.fillMaxWidth().padding(top = 6.dp)) { Text(stringResource(R.string.custom_reset)) }
            Spacer(Modifier.height(100.dp))
        }
    }
}

@Composable
private fun Card(title: Int, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(title), style = MaterialTheme.typography.titleMedium)
        content()
    }
}

/** A round colour swatch with its name below; the chosen one has a ring. */
@Composable
private fun Dot(fill: Brush, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(64.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(44.dp)
                .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.outlineVariant, CircleShape)
                .padding(5.dp).clip(CircleShape).background(fill),
        )
        Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
    }
}
