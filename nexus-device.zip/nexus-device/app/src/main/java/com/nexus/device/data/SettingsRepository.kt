package com.nexus.device.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nexus.device.core.TempUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode { DARK, LIGHT, SYSTEM }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.DARK,
    val tempUnit: TempUnit = TempUnit.C,
    val hideIds: Boolean = true,
    val intervalMs: Long = 1000L,
    val hiddenCategories: Set<String> = emptySet(),
)

private val Context.dataStore by preferencesDataStore(name = "nexus_settings")

class SettingsRepository(private val context: Context) {
    private val kTheme = stringPreferencesKey("theme")
    private val kUnit = stringPreferencesKey("unit")
    private val kHide = booleanPreferencesKey("hide_ids")
    private val kInterval = longPreferencesKey("interval_ms")
    private val kHidden = stringSetPreferencesKey("hidden_categories")

    val settings: Flow<AppSettings> = context.dataStore.data.map { p: Preferences ->
        AppSettings(
            theme = p[kTheme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.DARK,
            tempUnit = p[kUnit]?.let { runCatching { TempUnit.valueOf(it) }.getOrNull() } ?: TempUnit.C,
            hideIds = p[kHide] ?: true,
            intervalMs = p[kInterval] ?: 1000L,
            hiddenCategories = p[kHidden] ?: emptySet(),
        )
    }

    suspend fun setTheme(v: ThemeMode) { context.dataStore.edit { it[kTheme] = v.name } }
    suspend fun setUnit(v: TempUnit) { context.dataStore.edit { it[kUnit] = v.name } }
    suspend fun setHideIds(v: Boolean) { context.dataStore.edit { it[kHide] = v } }
    suspend fun setInterval(v: Long) { context.dataStore.edit { it[kInterval] = v } }
    suspend fun setCategoryHidden(id: String, hidden: Boolean) {
        context.dataStore.edit { p ->
            val cur = p[kHidden] ?: emptySet()
            p[kHidden] = if (hidden) cur + id else cur - id
        }
    }
    suspend fun clearAll() { context.dataStore.edit { it.clear() } }
}
