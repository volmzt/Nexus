package com.nexus.device.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nexus.device.core.TempUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode { DARK, LIGHT, SYSTEM }

/** How cards and the navigation bar are drawn. OPAQUE is the cheapest on battery and GPU. */
enum class VisualStyle { TRANSLUCENT, OPAQUE }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val tempUnit: TempUnit = TempUnit.C,
    val hideIds: Boolean = true,
    val intervalMs: Long = 1000L,
    val hiddenCategories: Set<String> = emptySet(),
    /** false = Simple view (only the important values), true = Detailed view (everything). */
    val detailed: Boolean = false,
    val tempNotify: Boolean = false,
    val style: VisualStyle = VisualStyle.OPAQUE,
    /** The throttling test stops by itself when the battery reaches this temperature, degrees C. */
    val stopTempC: Int = 45,
)

private val Context.dataStore by preferencesDataStore(name = "nexus_settings")

class SettingsRepository(private val context: Context) {
    private val kTheme = stringPreferencesKey("theme")
    private val kUnit = stringPreferencesKey("unit")
    private val kHide = booleanPreferencesKey("hide_ids")
    private val kInterval = longPreferencesKey("interval_ms")
    private val kHidden = stringSetPreferencesKey("hidden_categories")
    private val kDetailed = booleanPreferencesKey("detailed_view")
    private val kStyle = stringPreferencesKey("visual_style")
    private val kNotify = booleanPreferencesKey("temp_notify")
    private val kStop = androidx.datastore.preferences.core.intPreferencesKey("stop_temp_c")

    val settings: Flow<AppSettings> = context.dataStore.data.map { p: Preferences ->
        AppSettings(
            theme = p[kTheme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
            tempUnit = p[kUnit]?.let { runCatching { TempUnit.valueOf(it) }.getOrNull() } ?: TempUnit.C,
            hideIds = p[kHide] ?: true,
            intervalMs = p[kInterval] ?: 1000L,
            hiddenCategories = p[kHidden] ?: emptySet(),
            detailed = p[kDetailed] ?: false,
            tempNotify = p[kNotify] ?: false,
            // "GLASS" was removed; anyone who had it gets the translucent style.
            style = p[kStyle]?.let { if (it == "GLASS") VisualStyle.TRANSLUCENT else runCatching { VisualStyle.valueOf(it) }.getOrNull() } ?: VisualStyle.OPAQUE,
            stopTempC = p[kStop] ?: 45,
        )
    }

    suspend fun setTheme(v: ThemeMode) { context.dataStore.edit { it[kTheme] = v.name } }
    suspend fun setUnit(v: TempUnit) { context.dataStore.edit { it[kUnit] = v.name } }
    suspend fun setHideIds(v: Boolean) { context.dataStore.edit { it[kHide] = v } }
    suspend fun setInterval(v: Long) { context.dataStore.edit { it[kInterval] = v } }
    suspend fun setDetailed(v: Boolean) { context.dataStore.edit { it[kDetailed] = v } }
    suspend fun setStyle(v: VisualStyle) { context.dataStore.edit { it[kStyle] = v.name } }
    suspend fun setTempNotify(v: Boolean) { context.dataStore.edit { it[kNotify] = v } }
    suspend fun setStopTemp(v: Int) { context.dataStore.edit { it[kStop] = v } }
    suspend fun setCategoryHidden(id: String, hidden: Boolean) {
        context.dataStore.edit { p ->
            val cur = p[kHidden] ?: emptySet()
            p[kHidden] = if (hidden) cur + id else cur - id
        }
    }
    suspend fun clearAll() { context.dataStore.edit { it.clear() } }
}
