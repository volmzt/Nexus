package com.nexus.device.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nexus.device.core.TempUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode { DARK, LIGHT, SYSTEM }

/** How cards and the navigation bar are drawn. OPAQUE is the cheapest on battery and GPU. */
enum class VisualStyle { TRANSLUCENT, OPAQUE }

/** Colour of buttons, switches and highlights. DEFAULT keeps the neutral steel look; WALLPAPER follows the system colours (Android 12+). */
enum class AccentColor { DEFAULT, BLUE, VIOLET, GREEN, RED, ORANGE, WALLPAPER }

/** The set of colours the animated background flows through. */
enum class BgPalette { DEFAULT, OCEAN, SUNSET, FOREST, MONO }

/** One block on the Home screen. [size] is columns * 10 + rows: 11 (1x1), 21 (2x1), 12 (1x2), 13 (1x3), 22 (2x2), 23 (2x3). */
data class HomeBlock(val id: String, val size: Int)

object HomeBlocks {
    const val SMALL = 11
    const val MEDIUM = 21
    const val LARGE = 22

    fun cols(size: Int): Int = (size / 10).coerceIn(1, 2)
    fun rows(size: Int): Int = (size % 10).coerceIn(1, 3)
    fun make(cols: Int, rows: Int): Int = cols.coerceIn(1, 2) * 10 + rows.coerceIn(1, 3)

    /** Sizes saved by older versions were 1, 2 and 3 (small, wide, wide with a chart). */
    fun normalize(size: Int): Int = when (size) {
        1 -> SMALL
        2 -> MEDIUM
        3 -> LARGE
        else -> make(size / 10, size % 10)
    }

    /** Every block that can be placed on Home. "fn:" blocks are shortcuts to a tool. */
    val known = listOf(
        "bench", "device", "battery", "cpu", "ram", "load", "storage", "gpu", "temp",
        "fn:throttle", "fn:hwcheck", "fn:tests", "fn:terminal", "fn:apps", "fn:battery_health", "fn:cores",
        "fn:sensors_live", "fn:gpu_ext", "fn:c_system", "fn:c_cpu", "fn:c_gpu", "fn:c_memory", "fn:c_storage",
        "fn:c_display", "fn:c_battery", "fn:c_network", "fn:c_sensors", "fn:c_camera", "fn:c_codecs",
    )

    val defaults = listOf(
        HomeBlock("bench", LARGE), HomeBlock("device", MEDIUM),
        HomeBlock("battery", SMALL), HomeBlock("cpu", SMALL), HomeBlock("ram", SMALL), HomeBlock("load", SMALL),
        HomeBlock("storage", SMALL), HomeBlock("gpu", SMALL), HomeBlock("temp", LARGE),
    )

    fun defaultSize(id: String): Int = if (id.startsWith("fn:")) MEDIUM else defaults.firstOrNull { it.id == id }?.size ?: MEDIUM

    fun encode(blocks: List<HomeBlock>): String = blocks.joinToString(",") { it.id + ":" + it.size }

    /** null (nothing saved yet) gives the defaults; unknown or repeated ids are dropped, sizes are clamped. */
    fun decode(saved: String?): List<HomeBlock> {
        if (saved == null) return defaults
        return saved.split(',').mapNotNull { part ->
            val at = part.lastIndexOf(':')
            if (at <= 0) return@mapNotNull null
            val id = part.substring(0, at)
            val size = part.substring(at + 1).toIntOrNull() ?: return@mapNotNull null
            if (id in known) HomeBlock(id, if (size == 2 && (id == "bench" || id == "temp")) LARGE else normalize(size)) else null
        }.distinctBy { it.id }
    }
}

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val tempUnit: TempUnit = TempUnit.C,
    val hideIds: Boolean = true,
    val intervalMs: Long = 1000L,
    val hiddenCategories: Set<String> = emptySet(),
    /** false = Simple view (only the important values), true = Detailed view (everything). */
    val detailed: Boolean = false,
    val tempNotify: Boolean = false,
    val style: VisualStyle = VisualStyle.TRANSLUCENT,
    /** Slow moving colours behind the semi-transparent style. Off saves battery on weaker phones. */
    val animatedBg: Boolean = true,
    /** Home editor without motion: blocks jump to their place. For weak phones. */
    val plainHome: Boolean = false,
    /** The throttling test stops by itself when the battery reaches this temperature, degrees C. */
    val stopTempC: Int = 45,
    val accent: AccentColor = AccentColor.DEFAULT,
    val palette: BgPalette = BgPalette.DEFAULT,
    /** Speed of the animated background: 0 slow, 1 normal, 2 fast. */
    val bgSpeed: Int = 1,
    /** Card corners: 0 strict, 1 normal, 2 soft. */
    val corners: Int = 1,
    /** Text size: 0 small, 1 normal, 2 large. */
    val textSize: Int = 1,
    val homeBlocks: List<HomeBlock> = HomeBlocks.defaults,
    /** Small floating window with live values, drawn over other apps. */
    val overlayOn: Boolean = false,
    val overlayItems: String = "pct,fps,time,temp",
    val overlayX: Int = 24,
    val overlayY: Int = 120,
    /** Opacity of the floating window background, percent. */
    val overlayAlpha: Int = 70,
)

private val Context.dataStore by preferencesDataStore(name = "nexus_settings")

class SettingsRepository(private val context: Context) {
    private val kTheme = stringPreferencesKey("theme")
    private val kUnit = stringPreferencesKey("unit")
    private val kHide = booleanPreferencesKey("hide_ids")
    private val kInterval = longPreferencesKey("interval_ms")
    private val kHidden = stringSetPreferencesKey("hidden_categories")
    private val kDetailed = booleanPreferencesKey("detailed_view")
    private val kStyle = stringPreferencesKey("visual_style")
    private val kAnim = booleanPreferencesKey("animated_bg")
    private val kPlain = booleanPreferencesKey("plain_home")
    private val kNotify = booleanPreferencesKey("temp_notify")
    private val kAccent = stringPreferencesKey("accent")
    private val kPalette = stringPreferencesKey("bg_palette")
    private val kSpeed = androidx.datastore.preferences.core.intPreferencesKey("bg_speed")
    private val kCorners = androidx.datastore.preferences.core.intPreferencesKey("corners")
    private val kText = androidx.datastore.preferences.core.intPreferencesKey("text_size")
    private val kBlocks = stringPreferencesKey("home_blocks")
    private val kOvOn = booleanPreferencesKey("overlay_on")
    private val kOvItems = stringPreferencesKey("overlay_items")
    private val kOvX = androidx.datastore.preferences.core.intPreferencesKey("overlay_x")
    private val kOvY = androidx.datastore.preferences.core.intPreferencesKey("overlay_y")
    private val kOvA = androidx.datastore.preferences.core.intPreferencesKey("overlay_alpha")
    private val kStop = androidx.datastore.preferences.core.intPreferencesKey("stop_temp_c")

    val settings: Flow<AppSettings> = context.dataStore.data.map { p: Preferences ->
        AppSettings(
            theme = p[kTheme]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM,
            tempUnit = p[kUnit]?.let { runCatching { TempUnit.valueOf(it) }.getOrNull() } ?: TempUnit.C,
            hideIds = p[kHide] ?: true,
            intervalMs = p[kInterval] ?: 1000L,
            hiddenCategories = p[kHidden] ?: emptySet(),
            detailed = p[kDetailed] ?: false,
            tempNotify = p[kNotify] ?: false,
            // "GLASS" was removed; anyone who had it gets the translucent style.
            style = p[kStyle]?.let { if (it == "GLASS") VisualStyle.TRANSLUCENT else runCatching { VisualStyle.valueOf(it) }.getOrNull() } ?: VisualStyle.TRANSLUCENT,
            animatedBg = p[kAnim] ?: true,
            plainHome = p[kPlain] ?: false,
            stopTempC = p[kStop] ?: 45,
            accent = p[kAccent]?.let { runCatching { AccentColor.valueOf(it) }.getOrNull() } ?: AccentColor.DEFAULT,
            palette = p[kPalette]?.let { runCatching { BgPalette.valueOf(it) }.getOrNull() } ?: BgPalette.DEFAULT,
            bgSpeed = (p[kSpeed] ?: 1).coerceIn(0, 2),
            corners = (p[kCorners] ?: 1).coerceIn(0, 2),
            textSize = (p[kText] ?: 1).coerceIn(0, 2),
            homeBlocks = HomeBlocks.decode(p[kBlocks]),
            overlayOn = p[kOvOn] ?: false,
            overlayItems = p[kOvItems] ?: "pct,fps,time,temp",
            overlayX = p[kOvX] ?: 24,
            overlayY = p[kOvY] ?: 120,
            overlayAlpha = (p[kOvA] ?: 70).coerceIn(20, 100),
        )
    }

    suspend fun setTheme(v: ThemeMode) { context.dataStore.edit { it[kTheme] = v.name } }
    suspend fun setUnit(v: TempUnit) { context.dataStore.edit { it[kUnit] = v.name } }
    suspend fun setHideIds(v: Boolean) { context.dataStore.edit { it[kHide] = v } }
    suspend fun setInterval(v: Long) { context.dataStore.edit { it[kInterval] = v } }
    suspend fun setDetailed(v: Boolean) { context.dataStore.edit { it[kDetailed] = v } }
    suspend fun setStyle(v: VisualStyle) { context.dataStore.edit { it[kStyle] = v.name } }
    suspend fun setAnimatedBg(v: Boolean) { context.dataStore.edit { it[kAnim] = v } }
    suspend fun setPlainHome(v: Boolean) { context.dataStore.edit { it[kPlain] = v } }
    suspend fun setTempNotify(v: Boolean) { context.dataStore.edit { it[kNotify] = v } }
    suspend fun setOverlayOn(v: Boolean) { context.dataStore.edit { it[kOvOn] = v } }
    suspend fun setOverlayItems(v: String) { context.dataStore.edit { it[kOvItems] = v } }
    suspend fun setOverlayPos(x: Int, y: Int) { context.dataStore.edit { it[kOvX] = x; it[kOvY] = y } }
    suspend fun setOverlayAlpha(v: Int) { context.dataStore.edit { it[kOvA] = v } }
    suspend fun setStopTemp(v: Int) { context.dataStore.edit { it[kStop] = v } }
    suspend fun setAccent(v: AccentColor) { context.dataStore.edit { it[kAccent] = v.name } }
    suspend fun setPalette(v: BgPalette) { context.dataStore.edit { it[kPalette] = v.name } }
    suspend fun setBgSpeed(v: Int) { context.dataStore.edit { it[kSpeed] = v } }
    suspend fun setCorners(v: Int) { context.dataStore.edit { it[kCorners] = v } }
    suspend fun setTextSize(v: Int) { context.dataStore.edit { it[kText] = v } }
    suspend fun setHomeBlocks(v: List<HomeBlock>) { context.dataStore.edit { it[kBlocks] = HomeBlocks.encode(v) } }
    suspend fun resetCustomization() {
        context.dataStore.edit { listOf(kAccent, kPalette, kSpeed, kCorners, kText, kBlocks).forEach { k -> it.remove(k) } }
    }
    suspend fun setCategoryHidden(id: String, hidden: Boolean) {
        context.dataStore.edit { p ->
            val cur = p[kHidden] ?: emptySet()
            p[kHidden] = if (hidden) cur + id else cur - id
        }
    }
    suspend fun clearAll() { context.dataStore.edit { it.clear() } }
}
