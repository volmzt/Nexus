package com.nexus.device.core

import java.util.Locale

enum class TempUnit { C, F }

object Fmt {
    fun bytes(b: Long): String {
        if (b < 1024) return "$b B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = -1
        while (v >= 1024 && i < units.lastIndex) {
            v /= 1024
            i++
        }
        return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.1f %s", v, units[i])
    }

    fun temp(celsius: Float, unit: TempUnit): String =
        if (unit == TempUnit.C) String.format(Locale.US, "%.1f °C", celsius)
        else String.format(Locale.US, "%.1f °F", celsius * 9f / 5f + 32f)

    fun tempValue(celsius: Float, unit: TempUnit): Float =
        if (unit == TempUnit.C) celsius else celsius * 9f / 5f + 32f

    fun duration(ms: Long): String {
        val s = ms / 1000
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        return if (d > 0) "${d}d ${h}h ${m}m" else "${h}h ${m}m ${s % 60}s"
    }

    fun one(v: Double): String = String.format(Locale.US, "%.1f", v)
}
