package com.nexus.device.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.widget.RemoteViews
import com.nexus.device.MainActivity
import com.nexus.device.NexusApplication
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.monitoring.TempReader
import com.nexus.device.monitoring.Temps
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Home-screen widget: battery level, battery temperature, CPU temperature.
 * Android refreshes widgets at most every 30 minutes by itself; while the temperature notification is on,
 * the notification service pushes fresh values every two seconds.
 */
class TempWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val unit = (context.applicationContext as NexusApplication).container.settings.settings.first().tempUnit
                push(context, TempReader.read(context), unit)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        fun push(context: Context, t: Temps, unit: TempUnit) {
            val mgr = AppWidgetManager.getInstance(context)
            val me = ComponentName(context, TempWidget::class.java)
            if (mgr.getAppWidgetIds(me).isEmpty()) return
            val level = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                ?.let { i ->
                    val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                    if (l >= 0 && s > 0) l * 100 / s else null
                }
            val v = RemoteViews(context.packageName, R.layout.widget_temps)
            v.setTextViewText(R.id.w_level, level?.let { "$it%" } ?: "—")
            v.setTextViewText(R.id.w_batt, t.batteryC?.let { Fmt.temp(it, unit) } ?: "—")
            v.setTextViewText(R.id.w_cpu, t.cpuC?.let { Fmt.temp(it, unit) } ?: "—")
            v.setOnClickPendingIntent(
                R.id.w_root,
                PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE),
            )
            mgr.updateAppWidget(me, v)
        }
    }
}
