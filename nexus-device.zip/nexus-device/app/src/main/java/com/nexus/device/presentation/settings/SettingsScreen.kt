package com.nexus.device.presentation.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.nexus.device.presentation.components.SegmentedTabs
import com.nexus.device.presentation.components.cardSurface
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.BuildConfig
import com.nexus.device.R
import com.nexus.device.core.TempUnit
import com.nexus.device.data.ThemeMode
import com.nexus.device.data.VisualStyle
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import com.nexus.device.domain.Category
import com.nexus.device.presentation.SettingsViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.titleRes
import com.nexus.device.presentation.toast
import com.nexus.device.reporting.PdfExporter
import com.nexus.device.reporting.ReportFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(vm: SettingsViewModel, onPrivacy: () -> Unit, modifier: Modifier = Modifier, listState: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var showSections by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf(ReportFormat.TXT) }
    val titles = Category.entries.associateWith { ctx.getString(it.titleRes()) }
    val savedMsg = stringResource(R.string.report_saved)
    val failMsg = stringResource(R.string.report_failed)
    val clearedMsg = stringResource(R.string.history_cleared)

    // Reports are written only where the user chooses, through the system file picker.
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val text = vm.buildReport(pending, titles, BuildConfig.VERSION_NAME)
                    ctx.contentResolver.openOutputStream(uri)?.use { out ->
                        if (pending == ReportFormat.PDF) PdfExporter.write(text, out) else out.write(text.toByteArray())
                    } != null
                } catch (e: Exception) {
                    false
                }
            }
            toast(ctx, if (ok) savedMsg else failMsg)
        }
    }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { BigTitle(stringResource(R.string.settings_title)) }

        // Appearance: theme, style with a live preview, temperature unit.
        item { SectionLabel(R.string.set_appearance) }
        item {
            Column(
                Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                SegmentedTabs(
                    listOf(R.string.theme_dark, R.string.theme_light, R.string.theme_system).map { stringResource(it) },
                    ThemeMode.entries.indexOf(s.theme).coerceAtLeast(0), { vm.setTheme(ThemeMode.entries[it]) },
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StyleCard(VisualStyle.TRANSLUCENT, R.string.style_translucent, s.style == VisualStyle.TRANSLUCENT, Modifier.weight(1f)) { vm.setStyle(VisualStyle.TRANSLUCENT) }
                    StyleCard(VisualStyle.OPAQUE, R.string.style_opaque, s.style == VisualStyle.OPAQUE, Modifier.weight(1f)) { vm.setStyle(VisualStyle.OPAQUE) }
                }
                Text(
                    stringResource(if (s.style == VisualStyle.OPAQUE) R.string.style_opaque_d else R.string.style_translucent_d),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(stringResource(R.string.temp_unit), style = MaterialTheme.typography.bodyLarge)
                    SegmentedTabs(listOf("°C", "°F"), TempUnit.entries.indexOf(s.tempUnit).coerceAtLeast(0), { vm.setUnit(TempUnit.entries[it]) }, Modifier.width(140.dp))
                }
            }
        }

        item { SectionLabel(R.string.set_general) }
        item {
            ItemRow(
                stringResource(R.string.hide_ids), stringResource(R.string.hide_ids_desc), icon = Icons.Filled.VisibilityOff, shape = groupShape(0, 3),
                onClick = { vm.setHideIds(!s.hideIds) },
                trailing = { Switch(checked = s.hideIds, onCheckedChange = { vm.setHideIds(it) }) },
            )
            Spacer(Modifier.height(2.dp))
            ItemRow(
                stringResource(R.string.language),
                if (Build.VERSION.SDK_INT >= 33) stringResource(R.string.language_desc) else stringResource(R.string.language_old),
                icon = Icons.Filled.Language, shape = groupShape(1, 3),
                onClick = if (Build.VERSION.SDK_INT >= 33) ({
                    ctx.startActivity(Intent(Settings.ACTION_APP_LOCALE_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) else null,
                chevron = Build.VERSION.SDK_INT >= 33,
            )
            Spacer(Modifier.height(2.dp))
            ItemRow(stringResource(R.string.notifications), stringResource(R.string.notifications_desc), icon = Icons.Filled.Notifications, shape = groupShape(2, 3))
        }

        item { SectionLabel(R.string.sections) }
        val cats = Category.entries
        item {
            ItemRow(
                stringResource(R.string.sections), cats.count { it.id !in s.hiddenCategories }.toString() + " / " + cats.size,
                icon = Icons.Filled.Tune, shape = groupShape(0, 1),
                onClick = { showSections = !showSections }, chevron = true,
            )
        }
        if (showSections) items(cats.size) { i ->
            val c = cats[i]
            val hidden = c.id in s.hiddenCategories
            ItemRow(
                stringResource(c.titleRes()), shape = groupShape(i, cats.size),
                onClick = { vm.setCategoryHidden(c.id, !hidden) },
                trailing = { Switch(checked = !hidden, onCheckedChange = { vm.setCategoryHidden(c.id, !it) }) },
            )
        }

        item { SectionLabel(R.string.reports) }
        val formats = ReportFormat.entries
        items(formats.size) { i ->
            val f = formats[i]
            ItemRow(
                stringResource(R.string.report_save, f.name), shape = groupShape(i, formats.size + 1),
                onClick = { pending = f; saver.launch("nexus-device-report." + f.extension) },
            )
        }
        item {
            ItemRow(
                stringResource(R.string.report_share), shape = groupShape(formats.size, formats.size + 1),
                onClick = {
                    scope.launch {
                        val text = vm.buildReport(ReportFormat.TXT, titles, BuildConfig.VERSION_NAME)
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                        ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                },
            )
        }

        item { SectionLabel(R.string.data) }
        item {
            ItemRow(stringResource(R.string.clear_history), shape = groupShape(0, 1), onClick = { vm.clearHistory { toast(ctx, clearedMsg) } })
        }

        item { SectionLabel(R.string.about) }
        item {
            ItemRow(stringResource(R.string.app_name), stringResource(R.string.about_desc, BuildConfig.VERSION_NAME), shape = groupShape(0, 2))
            ItemRow(stringResource(R.string.privacy), shape = groupShape(1, 2), onClick = onPrivacy, chevron = true)
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { com.nexus.device.presentation.device.DetailHeader(stringResource(R.string.privacy), onBack) }
        item { Text(stringResource(R.string.privacy_text), style = MaterialTheme.typography.bodyLarge) }
        item { Text(stringResource(R.string.permissions_title), style = MaterialTheme.typography.titleMedium) }
        item { Text(stringResource(R.string.permissions_text), style = MaterialTheme.typography.bodyLarge) }
        item { Text(stringResource(R.string.licenses), style = MaterialTheme.typography.titleMedium) }
        item { Text(stringResource(R.string.licenses_text), style = MaterialTheme.typography.bodyLarge) }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
private fun SectionLabel(res: Int) {
    Text(
        stringResource(res).uppercase(), style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.2.sp,
        modifier = Modifier.padding(start = 6.dp, top = 22.dp, bottom = 8.dp),
    )
}

/** Small preview of how a card looks in a style, so the choice is visible before it is made. */
@Composable
private fun StyleCard(style: VisualStyle, label: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val card = MaterialTheme.colorScheme.surfaceContainer
    val backdrop = if (style == VisualStyle.OPAQUE) Brush.verticalGradient(listOf(Color.Black, Color.Black))
    else Brush.verticalGradient(listOf(Color(0xFF3A3F4A), Color(0xFF0B0C0F)))
    val edge by androidx.compose.animation.animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, label = "edge",
    )
    Column(
        modifier.clip(shape).border(if (selected) 2.dp else 1.dp, edge, shape).clickable(onClick = onClick),
    ) {
        Box(Modifier.fillMaxWidth().height(64.dp).background(backdrop).padding(12.dp)) {
            Box(
                Modifier.fillMaxWidth().fillMaxHeight().clip(RoundedCornerShape(10.dp))
                    .background(if (style == VisualStyle.OPAQUE) card else card.copy(alpha = 0.62f)),
            )
        }
        Text(
            stringResource(label), style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}
