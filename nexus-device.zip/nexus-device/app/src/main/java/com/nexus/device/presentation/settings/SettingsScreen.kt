package com.nexus.device.presentation.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.BuildConfig
import com.nexus.device.R
import com.nexus.device.core.TempUnit
import com.nexus.device.data.ThemeMode
import com.nexus.device.data.VisualStyle
import androidx.compose.material3.RadioButton
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import com.nexus.device.domain.Category
import com.nexus.device.presentation.SettingsViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.titleRes
import com.nexus.device.presentation.toast
import com.nexus.device.reporting.PdfExporter
import com.nexus.device.reporting.ReportFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(vm: SettingsViewModel, onPrivacy: () -> Unit, modifier: Modifier = Modifier, listState: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf(ReportFormat.TXT) }
    val titles = Category.entries.associateWith { ctx.getString(it.titleRes()) }
    val savedMsg = stringResource(R.string.report_saved)
    val failMsg = stringResource(R.string.report_failed)
    val clearedMsg = stringResource(R.string.history_cleared)

    // Reports are written only where the user chooses, through the system file picker.
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val text = vm.buildReport(pending, titles, BuildConfig.VERSION_NAME)
                    ctx.contentResolver.openOutputStream(uri)?.use { out ->
                        if (pending == ReportFormat.PDF) PdfExporter.write(text, out) else out.write(text.toByteArray())
                    } != null
                } catch (e: Exception) {
                    false
                }
            }
            toast(ctx, if (ok) savedMsg else failMsg)
        }
    }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { BigTitle(stringResource(R.string.settings_title)) }

        item {
            ItemRow(stringResource(R.string.theme), shape = groupShape(0, 3), trailing = {})
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { m ->
                    FilterChip(
                        selected = s.theme == m, onClick = { vm.setTheme(m) },
                        label = { Text(stringResource(when (m) { ThemeMode.DARK -> R.string.theme_dark; ThemeMode.LIGHT -> R.string.theme_light; ThemeMode.SYSTEM -> R.string.theme_system })) },
                    )
                }
            }
        }
        item {
            Spacer(Modifier.height(10.dp))
            val opts = listOf(
                Triple(VisualStyle.GLASS, R.string.style_glass, R.string.style_glass_d),
                Triple(VisualStyle.TRANSLUCENT, R.string.style_translucent, R.string.style_translucent_d),
                Triple(VisualStyle.OPAQUE, R.string.style_opaque, R.string.style_opaque_d),
            )
            ItemRow(stringResource(R.string.visual_style), shape = groupShape(0, 1 + opts.size))
            opts.forEachIndexed { i, (m, title, desc) ->
                ItemRow(
                    stringResource(title), stringResource(desc), shape = groupShape(i + 1, 1 + opts.size),
                    onClick = { vm.setStyle(m) },
                    trailing = { RadioButton(selected = s.style == m, onClick = { vm.setStyle(m) }) },
                )
            }
            Spacer(Modifier.height(10.dp))
        }
        item {
            ItemRow(stringResource(R.string.temp_unit), shape = groupShape(1, 3))
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TempUnit.entries.forEach { u ->
                    FilterChip(selected = s.tempUnit == u, onClick = { vm.setUnit(u) }, label = { Text(if (u == TempUnit.C) "°C" else "°F") })
                }
            }
        }
        item {
            ItemRow(
                stringResource(R.string.hide_ids), stringResource(R.string.hide_ids_desc), shape = groupShape(2, 3),
                onClick = { vm.setHideIds(!s.hideIds) },
                trailing = { Switch(checked = s.hideIds, onCheckedChange = { vm.setHideIds(it) }) },
            )
        }

        item {
            Spacer(Modifier.height(12.dp))
            ItemRow(
                stringResource(R.string.language),
                if (Build.VERSION.SDK_INT >= 33) stringResource(R.string.language_desc) else stringResource(R.string.language_old),
                shape = groupShape(0, 2),
                onClick = if (Build.VERSION.SDK_INT >= 33) ({
                    ctx.startActivity(Intent(Settings.ACTION_APP_LOCALE_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) else null,
                chevron = Build.VERSION.SDK_INT >= 33,
            )
            ItemRow(stringResource(R.string.notifications), stringResource(R.string.notifications_desc), shape = groupShape(1, 2))
        }

        item { Spacer(Modifier.height(12.dp)); Text(stringResource(R.string.sections), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 4.dp)); Spacer(Modifier.height(6.dp)) }
        val cats = Category.entries
        items(cats.size) { i ->
            val c = cats[i]
            val hidden = c.id in s.hiddenCategories
            ItemRow(
                stringResource(c.titleRes()), shape = groupShape(i, cats.size),
                onClick = { vm.setCategoryHidden(c.id, !hidden) },
                trailing = { Switch(checked = !hidden, onCheckedChange = { vm.setCategoryHidden(c.id, !it) }) },
            )
        }

        item { Spacer(Modifier.height(12.dp)); Text(stringResource(R.string.reports), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 4.dp)); Spacer(Modifier.height(6.dp)) }
        val formats = ReportFormat.entries
        items(formats.size) { i ->
            val f = formats[i]
            ItemRow(
                stringResource(R.string.report_save, f.name), shape = groupShape(i, formats.size + 1),
                onClick = { pending = f; saver.launch("nexus-device-report." + f.extension) },
            )
        }
        item {
            ItemRow(
                stringResource(R.string.report_share), shape = groupShape(formats.size, formats.size + 1),
                onClick = {
                    scope.launch {
                        val text = vm.buildReport(ReportFormat.TXT, titles, BuildConfig.VERSION_NAME)
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                        ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                },
            )
        }

        item { Spacer(Modifier.height(12.dp)); Text(stringResource(R.string.data), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 4.dp)); Spacer(Modifier.height(6.dp)) }
        item {
            ItemRow(stringResource(R.string.clear_history), shape = groupShape(0, 1), onClick = { vm.clearHistory { toast(ctx, clearedMsg) } })
        }

        item { Spacer(Modifier.height(12.dp)); Text(stringResource(R.string.about), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 4.dp)); Spacer(Modifier.height(6.dp)) }
        item {
            ItemRow(stringResource(R.string.app_name), stringResource(R.string.about_desc, BuildConfig.VERSION_NAME), shape = groupShape(0, 2))
            ItemRow(stringResource(R.string.privacy), shape = groupShape(1, 2), onClick = onPrivacy, chevron = true)
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
fun PrivacyScreen(onBack: () -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { com.nexus.device.presentation.device.DetailHeader(stringResource(R.string.privacy), onBack) }
        item { Text(stringResource(R.string.privacy_text), style = MaterialTheme.typography.bodyLarge) }
        item { Text(stringResource(R.string.permissions_title), style = MaterialTheme.typography.titleMedium) }
        item { Text(stringResource(R.string.permissions_text), style = MaterialTheme.typography.bodyLarge) }
        item { Text(stringResource(R.string.licenses), style = MaterialTheme.typography.titleMedium) }
        item { Text(stringResource(R.string.licenses_text), style = MaterialTheme.typography.bodyLarge) }
        item { Spacer(Modifier.height(120.dp)) }
    }
}
