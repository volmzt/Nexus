package com.nexus.device.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.background
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.nexus.device.data.AccentColor
import com.nexus.device.data.BgPalette
import com.nexus.device.data.VisualStyle
import androidx.compose.ui.graphics.luminance
import com.nexus.device.core.Availability

/** Colours that Material 3 has no slot for: availability status and the warning banner. */
data class ExtraColors(val ok: Color, val warn: Color, val perm: Color, val muted: Color)

val LocalExtraColors = staticCompositionLocalOf { ExtraColors(Color.Green, Color.Yellow, Color.Magenta, Color.Gray) }

// Restrained palette: neutral greys with one cool steel accent. No saturated colours anywhere.
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFE4E6EB),
    onPrimary = Color(0xFF101114),
    secondary = Color(0xFF8E9BAE),
    tertiary = Color(0xFFA99B84),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE8E8EA),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFE8E8EA),
    onSurfaceVariant = Color(0xFF9A9BA2),
    surfaceContainer = Color(0xFF1B1B1E),
    surfaceContainerHigh = Color(0xFF28282C),
    outlineVariant = Color(0xFF2C2C30),
    primaryContainer = Color(0xFF2E3138),
    onPrimaryContainer = Color(0xFFE4E6EB),
    secondaryContainer = Color(0xFF2E3138),
    onSecondaryContainer = Color(0xFFE4E6EB),
    error = Color(0xFFE08A84),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF2B2F36),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF5D6B80),
    tertiary = Color(0xFF7C6B52),
    background = Color(0xFFF2F2F5),
    onBackground = Color(0xFF17171A),
    surface = Color(0xFFF2F2F5),
    onSurface = Color(0xFF17171A),
    onSurfaceVariant = Color(0xFF5F5F68),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFE9E9EE),
    outlineVariant = Color(0xFFE2E2E8),
    primaryContainer = Color(0xFFDADCE2),
    onPrimaryContainer = Color(0xFF17171A),
    secondaryContainer = Color(0xFFDADCE2),
    onSecondaryContainer = Color(0xFF17171A),
    error = Color(0xFFB3261E),
)

val LocalVisualStyle = staticCompositionLocalOf { VisualStyle.OPAQUE }

/** Corner scale for cards, from the Customization setting. 1 = the designed size. */
val LocalCornerScale = staticCompositionLocalOf { 1f }

/** The chosen background palette, so accents drawn on it (the score ring) can follow it. */
val LocalBgPalette = staticCompositionLocalOf { BgPalette.DEFAULT }

private fun accentColor(accent: AccentColor, dark: Boolean, ctx: android.content.Context): Color? {
    val c = when (accent) {
        AccentColor.DEFAULT -> return null
        AccentColor.BLUE -> Color(0xFF4C7DFF)
        AccentColor.VIOLET -> Color(0xFF8E5CFF)
        AccentColor.GREEN -> Color(0xFF2ECC71)
        AccentColor.RED -> Color(0xFFF0524F)
        AccentColor.ORANGE -> Color(0xFFFF9A2E)
        AccentColor.WALLPAPER -> {
            if (android.os.Build.VERSION.SDK_INT < 31) return null
            return if (dark) androidx.compose.material3.dynamicDarkColorScheme(ctx).primary else androidx.compose.material3.dynamicLightColorScheme(ctx).primary
        }
    }
    return if (dark) c else lerp(c, Color.Black, 0.18f)
}

@Composable
fun NexusTheme(
    dark: Boolean,
    style: VisualStyle,
    accent: AccentColor = AccentColor.DEFAULT,
    corners: Int = 1,
    textSize: Int = 1,
    content: @Composable () -> Unit,
) {
    val extra = if (dark) ExtraColors(Color(0xFF7FB88F), Color(0xFFC9A66B), Color(0xFFA396C4), Color(0xFF9A9BA2))
    else ExtraColors(Color(0xFF2F7A48), Color(0xFF8A5A00), Color(0xFF5B3FC0), Color(0xFF5F5F68))
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val textK = when (textSize) { 0 -> 0.9f; 2 -> 1.15f; else -> 1f }
    val cornerK = when (corners) { 0 -> 0.45f; 2 -> 1.35f; else -> 1f }
    CompositionLocalProvider(
        LocalExtraColors provides extra,
        LocalVisualStyle provides style,
        LocalCornerScale provides cornerK,
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(density.density, density.fontScale * textK),
    ) {
        val base = if (dark) DarkScheme else LightScheme
        val tint = accentColor(accent, dark, ctx)
        val scheme = if (tint == null) base else base.copy(
            primary = tint,
            onPrimary = if (tint.luminance() > 0.5f) Color(0xFF101114) else Color.White,
            primaryContainer = lerp(base.surfaceContainerHigh, tint, 0.38f),
            secondaryContainer = lerp(base.surfaceContainerHigh, tint, 0.38f),
        )
        // Text outside a themed Surface would otherwise default to black.
        MaterialTheme(colorScheme = scheme) { CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides scheme.onBackground, content = content) }
    }
}

/** The three colours the background flows through, for the chosen palette. */
fun auroraColors(palette: BgPalette, dark: Boolean): List<Color> {
    val strong = when (palette) {
        BgPalette.DEFAULT -> listOf(Color(0xFF2237FF), Color(0xFFB847F0), Color(0xFF6C3BFF))
        BgPalette.OCEAN -> listOf(Color(0xFF0A6CFF), Color(0xFF00C2D1), Color(0xFF2A4BFF))
        BgPalette.SUNSET -> listOf(Color(0xFFFF5A36), Color(0xFFFF2E7E), Color(0xFF9A3BFF))
        BgPalette.FOREST -> listOf(Color(0xFF0FA968), Color(0xFF2EC4A0), Color(0xFF4FA83A))
        BgPalette.MONO -> listOf(Color(0xFF8A93A3), Color(0xFF5B6372), Color(0xFFB7BDC8))
    }
    return if (dark) strong else strong.map { lerp(it, Color.White, 0.55f) }
}

/** Smoothly walks through [colors] in a loop; [x] is the position, 1.0 is one step. */
private fun cycle(colors: List<Color>, x: Float): Color {
    val n = colors.size
    val p = ((x % n) + n) % n
    val i = p.toInt()
    return lerp(colors[i], colors[(i + 1) % n], p - i)
}

/**
 * Screen background. OPAQUE is a flat colour. TRANSLUCENT is a slow aurora: three large soft blobs travel in circles
 * near the top while their colours flow blue -> pink-blue -> violet-blue, then fade into the base colour so the
 * lower part of the screen stays calm. The motion is driven at ~20 frames per second and only while the app is
 * visible, so it costs little battery.
 */
@Composable
fun Modifier.appBackdrop(dark: Boolean, style: VisualStyle, animated: Boolean = true, palette: BgPalette = BgPalette.DEFAULT, speed: Int = 1): Modifier {
    val base = if (dark) Color(0xFF000000) else Color(0xFFF2F2F5)
    if (style == VisualStyle.OPAQUE) return this.background(base)

    var phase by remember { mutableFloatStateOf(0f) }
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val period = when (speed) { 0 -> 48000f; 2 -> 12000f; else -> 24000f }
    LaunchedEffect(owner, animated, period) {
        if (!animated) { phase = 0.12f; return@LaunchedEffect }
        owner.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
            while (true) {
                delay(50)
                phase = (phase + 50f / period) % 1f
            }
        }
    }
    val colors = remember(palette, dark) { auroraColors(palette, dark) }
    return this.background(base).drawBehind {
        val w = size.width
        // Everything below this height is the flat base colour, so nothing is drawn there.
        val h = size.height * 1.0f
        val area = Size(w, h)
        val turn = phase * 2f * Math.PI.toFloat()
        for (k in 0 until 3) {
            val a = turn + k * 2.0944f
            val c = cycle(colors, phase * 3f + k)
            val center = Offset(w * (0.5f + 0.40f * kotlin.math.cos(a)), h * (0.30f + 0.22f * kotlin.math.sin(a)))
            drawRect(Brush.radialGradient(listOf(c.copy(alpha = 0.9f), Color.Transparent), center, w * 1.1f), size = area)
        }
        drawRect(Brush.verticalGradient(0f to Color.Transparent, 0.7f to base.copy(alpha = 0.7f), 1f to base, startY = 0f, endY = h), size = area)
    }
}

@Composable
fun Availability.color(): Color = when (this) {
    Availability.AVAILABLE -> LocalExtraColors.current.ok
    Availability.APPROXIMATE -> LocalExtraColors.current.warn
    Availability.UNAVAILABLE -> LocalExtraColors.current.muted
    Availability.PERMISSION -> LocalExtraColors.current.perm
}
