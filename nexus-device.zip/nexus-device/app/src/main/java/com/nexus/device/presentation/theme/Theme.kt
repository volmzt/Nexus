package com.nexus.device.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.nexus.device.core.Availability

/** Colours that Material 3 has no slot for: availability status and the warning banner. */
data class ExtraColors(val ok: Color, val warn: Color, val perm: Color, val muted: Color)

val LocalExtraColors = staticCompositionLocalOf { ExtraColors(Color.Green, Color.Yellow, Color.Magenta, Color.Gray) }

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8AB4F8),
    onPrimary = Color(0xFF08203F),
    secondary = Color(0xFF6FD98F),
    tertiary = Color(0xFFF2B84B),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE8E8EA),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFE8E8EA),
    onSurfaceVariant = Color(0xFF9C9CA3),
    surfaceContainer = Color(0xFF1D1D1F),
    surfaceContainerHigh = Color(0xFF2A2A2D),
    outlineVariant = Color(0xFF2C2C30),
    error = Color(0xFFFF8A80),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF1A5FD0),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF1B7F3F),
    tertiary = Color(0xFF8A5A00),
    background = Color(0xFFF3F3F6),
    onBackground = Color(0xFF17171A),
    surface = Color(0xFFF3F3F6),
    onSurface = Color(0xFF17171A),
    onSurfaceVariant = Color(0xFF5F5F68),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFE9E9EE),
    outlineVariant = Color(0xFFE2E2E8),
    error = Color(0xFFB3261E),
)

@Composable
fun NexusTheme(dark: Boolean, content: @Composable () -> Unit) {
    val extra = if (dark) ExtraColors(Color(0xFF6FD98F), Color(0xFFF2B84B), Color(0xFFB9A4FF), Color(0xFF9C9CA3))
    else ExtraColors(Color(0xFF1B7F3F), Color(0xFF8A5A00), Color(0xFF5B3FC0), Color(0xFF5F5F68))
    CompositionLocalProvider(LocalExtraColors provides extra) {
        MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
    }
}

@Composable
fun Availability.color(): Color = when (this) {
    Availability.AVAILABLE -> LocalExtraColors.current.ok
    Availability.APPROXIMATE -> LocalExtraColors.current.warn
    Availability.UNAVAILABLE -> LocalExtraColors.current.muted
    Availability.PERMISSION -> LocalExtraColors.current.perm
}
