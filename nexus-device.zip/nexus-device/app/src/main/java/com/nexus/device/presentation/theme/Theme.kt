package com.nexus.device.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import com.nexus.device.data.VisualStyle
import com.nexus.device.core.Availability

/** Colours that Material 3 has no slot for: availability status and the warning banner. */
data class ExtraColors(val ok: Color, val warn: Color, val perm: Color, val muted: Color)

val LocalExtraColors = staticCompositionLocalOf { ExtraColors(Color.Green, Color.Yellow, Color.Magenta, Color.Gray) }

// Restrained palette: neutral greys with one cool steel accent. No saturated colours anywhere.
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFE4E6EB),
    onPrimary = Color(0xFF101114),
    secondary = Color(0xFF8E9BAE),
    tertiary = Color(0xFFA99B84),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE8E8EA),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFE8E8EA),
    onSurfaceVariant = Color(0xFF9A9BA2),
    surfaceContainer = Color(0xFF1B1B1E),
    surfaceContainerHigh = Color(0xFF28282C),
    outlineVariant = Color(0xFF2C2C30),
    primaryContainer = Color(0xFF2E3138),
    onPrimaryContainer = Color(0xFFE4E6EB),
    secondaryContainer = Color(0xFF2E3138),
    onSecondaryContainer = Color(0xFFE4E6EB),
    error = Color(0xFFE08A84),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF2B2F36),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF5D6B80),
    tertiary = Color(0xFF7C6B52),
    background = Color(0xFFF2F2F5),
    onBackground = Color(0xFF17171A),
    surface = Color(0xFFF2F2F5),
    onSurface = Color(0xFF17171A),
    onSurfaceVariant = Color(0xFF5F5F68),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFE9E9EE),
    outlineVariant = Color(0xFFE2E2E8),
    primaryContainer = Color(0xFFDADCE2),
    onPrimaryContainer = Color(0xFF17171A),
    secondaryContainer = Color(0xFFDADCE2),
    onSecondaryContainer = Color(0xFF17171A),
    error = Color(0xFFB3261E),
)

val LocalVisualStyle = staticCompositionLocalOf { VisualStyle.OPAQUE }

@Composable
fun NexusTheme(dark: Boolean, style: VisualStyle, content: @Composable () -> Unit) {
    val extra = if (dark) ExtraColors(Color(0xFF7FB88F), Color(0xFFC9A66B), Color(0xFFA396C4), Color(0xFF9A9BA2))
    else ExtraColors(Color(0xFF2F7A48), Color(0xFF8A5A00), Color(0xFF5B3FC0), Color(0xFF5F5F68))
    CompositionLocalProvider(LocalExtraColors provides extra, LocalVisualStyle provides style) {
        MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
    }
}

/** Flat black for the opaque style; a very faint vertical gradient for the others so translucent cards have something to show through. */
fun appBackdrop(dark: Boolean, style: VisualStyle): Brush = when {
    style == VisualStyle.OPAQUE -> SolidColor(if (dark) Color(0xFF000000) else Color(0xFFF2F2F5))
    dark -> Brush.verticalGradient(listOf(Color(0xFF1A1C21), Color(0xFF07080A), Color(0xFF000000)))
    else -> Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFE6E7ED)))
}

@Composable
fun Availability.color(): Color = when (this) {
    Availability.AVAILABLE -> LocalExtraColors.current.ok
    Availability.APPROXIMATE -> LocalExtraColors.current.warn
    Availability.UNAVAILABLE -> LocalExtraColors.current.muted
    Availability.PERMISSION -> LocalExtraColors.current.perm
}
