package com.nexus.device.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.background
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.nexus.device.data.VisualStyle
import com.nexus.device.core.Availability

/** Colours that Material 3 has no slot for: availability status and the warning banner. */
data class ExtraColors(val ok: Color, val warn: Color, val perm: Color, val muted: Color)

val LocalExtraColors = staticCompositionLocalOf { ExtraColors(Color.Green, Color.Yellow, Color.Magenta, Color.Gray) }

// Restrained palette: neutral greys with one cool steel accent. No saturated colours anywhere.
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFE4E6EB),
    onPrimary = Color(0xFF101114),
    secondary = Color(0xFF8E9BAE),
    tertiary = Color(0xFFA99B84),
    background = Color(0xFF000000),
    onBackground = Color(0xFFE8E8EA),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFE8E8EA),
    onSurfaceVariant = Color(0xFF9A9BA2),
    surfaceContainer = Color(0xFF1B1B1E),
    surfaceContainerHigh = Color(0xFF28282C),
    outlineVariant = Color(0xFF2C2C30),
    primaryContainer = Color(0xFF2E3138),
    onPrimaryContainer = Color(0xFFE4E6EB),
    secondaryContainer = Color(0xFF2E3138),
    onSecondaryContainer = Color(0xFFE4E6EB),
    error = Color(0xFFE08A84),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF2B2F36),
    onPrimary = Color(0xFFFFFFFF),
    secondary = Color(0xFF5D6B80),
    tertiary = Color(0xFF7C6B52),
    background = Color(0xFFF2F2F5),
    onBackground = Color(0xFF17171A),
    surface = Color(0xFFF2F2F5),
    onSurface = Color(0xFF17171A),
    onSurfaceVariant = Color(0xFF5F5F68),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFE9E9EE),
    outlineVariant = Color(0xFFE2E2E8),
    primaryContainer = Color(0xFFDADCE2),
    onPrimaryContainer = Color(0xFF17171A),
    secondaryContainer = Color(0xFFDADCE2),
    onSecondaryContainer = Color(0xFF17171A),
    error = Color(0xFFB3261E),
)

val LocalVisualStyle = staticCompositionLocalOf { VisualStyle.OPAQUE }

@Composable
fun NexusTheme(dark: Boolean, style: VisualStyle, content: @Composable () -> Unit) {
    val extra = if (dark) ExtraColors(Color(0xFF7FB88F), Color(0xFFC9A66B), Color(0xFFA396C4), Color(0xFF9A9BA2))
    else ExtraColors(Color(0xFF2F7A48), Color(0xFF8A5A00), Color(0xFF5B3FC0), Color(0xFF5F5F68))
    CompositionLocalProvider(LocalExtraColors provides extra, LocalVisualStyle provides style) {
        val scheme = if (dark) DarkScheme else LightScheme
        // Text outside a themed Surface would otherwise default to black.
        MaterialTheme(colorScheme = scheme) { CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides scheme.onBackground, content = content) }
    }
}

private val AuroraDark = listOf(Color(0xFF2237FF), Color(0xFFB847F0), Color(0xFF6C3BFF))
private val AuroraLight = listOf(Color(0xFF8FA8FF), Color(0xFFE3A6F5), Color(0xFFB9A2FF))

/** Smoothly walks through [colors] in a loop; [x] is the position, 1.0 is one step. */
private fun cycle(colors: List<Color>, x: Float): Color {
    val n = colors.size
    val p = ((x % n) + n) % n
    val i = p.toInt()
    return lerp(colors[i], colors[(i + 1) % n], p - i)
}

/**
 * Screen background. OPAQUE is a flat colour. TRANSLUCENT is a slow aurora: three large soft blobs travel in circles
 * near the top while their colours flow blue -> pink-blue -> violet-blue, then fade into the base colour so the
 * lower part of the screen stays calm. The motion is driven at ~20 frames per second and only while the app is
 * visible, so it costs little battery.
 */
@Composable
fun Modifier.appBackdrop(dark: Boolean, style: VisualStyle, animated: Boolean = true): Modifier {
    val base = if (dark) Color(0xFF000000) else Color(0xFFF2F2F5)
    if (style == VisualStyle.OPAQUE) return this.background(base)

    var phase by remember { mutableFloatStateOf(0f) }
    val owner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    LaunchedEffect(owner, animated) {
        if (!animated) { phase = 0.12f; return@LaunchedEffect }
        owner.lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
            while (true) {
                delay(50)
                phase = (phase + 50f / 24000f) % 1f
            }
        }
    }
    val palette = if (dark) AuroraDark else AuroraLight
    return this.background(base).drawBehind {
        val w = size.width
        // Everything below this height is the flat base colour, so nothing is drawn there.
        val h = size.height * 0.75f
        val area = Size(w, h)
        val turn = phase * 2f * Math.PI.toFloat()
        for (k in 0 until 3) {
            val a = turn + k * 2.0944f
            val c = cycle(palette, phase * 3f + k)
            val center = Offset(w * (0.5f + 0.40f * kotlin.math.cos(a)), h * (0.20f + 0.10f * kotlin.math.sin(a)))
            drawRect(Brush.radialGradient(listOf(c.copy(alpha = 0.9f), Color.Transparent), center, w * 1.1f), size = area)
        }
        drawRect(Brush.verticalGradient(0f to Color.Transparent, 0.5f to base.copy(alpha = 0.55f), 1f to base, startY = 0f, endY = h), size = area)
    }
}

@Composable
fun Availability.color(): Color = when (this) {
    Availability.AVAILABLE -> LocalExtraColors.current.ok
    Availability.APPROXIMATE -> LocalExtraColors.current.warn
    Availability.UNAVAILABLE -> LocalExtraColors.current.muted
    Availability.PERMISSION -> LocalExtraColors.current.perm
}
