package com.nexus.device.hardware

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import com.nexus.device.core.Availability
import com.nexus.device.core.Fmt
import com.nexus.device.core.Spec
import com.nexus.device.core.spec
import com.nexus.device.domain.Category
import com.nexus.device.domain.SpecProvider
import java.io.File
import java.util.Locale
import java.util.TimeZone

class MemoryProvider(private val context: Context) : SpecProvider {
    override val category = Category.MEMORY

    override fun read(): List<Spec> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val used = mi.totalMem - mi.availMem
        val rt = Runtime.getRuntime()
        return listOf(
            Spec("Total RAM", Fmt.bytes(mi.totalMem)),
            Spec("Available RAM", Fmt.bytes(mi.availMem)),
            Spec("Used RAM (whole system)", Fmt.bytes(used)),
            Spec("Used share (whole system)", Fmt.one(used * 100.0 / mi.totalMem) + " %"),
            Spec("Low memory threshold", Fmt.bytes(mi.threshold)),
            Spec("Low memory state", if (mi.lowMemory) "System is low on memory" else "Normal"),
            Spec("This app: heap in use", Fmt.bytes(rt.totalMemory() - rt.freeMemory())),
            Spec("This app: heap limit", Fmt.bytes(rt.maxMemory())),
            Spec("Memory class", "${am.memoryClass} MB per app (${am.largeMemoryClass} MB large)"),
            Spec("Low RAM device", if (am.isLowRamDevice) "Yes" else "No"),
        )
    }
}

class StorageProvider(private val context: Context) : SpecProvider {
    override val category = Category.STORAGE

    private fun volume(label: String, path: File, removable: Boolean?): List<Spec> = try {
        val s = StatFs(path.absolutePath)
        val total = s.totalBytes
        val free = s.availableBytes
        val used = total - free
        listOf(
            Spec("$label · total", Fmt.bytes(total)),
            Spec("$label · used", Fmt.bytes(used) + " (" + Fmt.one(used * 100.0 / total) + " %)"),
            Spec("$label · free", Fmt.bytes(free)),
        ) + (removable?.let { listOf(Spec("$label · removable", if (it) "Yes" else "No")) } ?: emptyList())
    } catch (e: Exception) {
        listOf(Spec(label, "Cannot read this volume", Availability.UNAVAILABLE))
    }

    override fun read(): List<Spec> {
        val out = mutableListOf<Spec>()
        out += volume("Internal (data)", Environment.getDataDirectory(), false)
        val dirs = context.getExternalFilesDirs(null).filterNotNull()
        dirs.forEachIndexed { i, d ->
            if (i == 0) {
                out += volume("Shared storage", d, runCatching { Environment.isExternalStorageRemovable(d) }.getOrNull())
            } else {
                out += volume("Extra volume $i", d, runCatching { Environment.isExternalStorageRemovable(d) }.getOrNull())
            }
        }
        out += spec("Filesystems in use", reason = "/proc/mounts is not readable") {
            val real = setOf("ext4", "f2fs", "erofs", "squashfs", "vfat", "exfat", "ntfs", "sdcardfs", "fuse", "btrfs", "overlay")
            File("/proc/mounts").readLines().mapNotNull { it.split(" ").getOrNull(2) }.filter { it in real }.distinct().joinToString(", ")
        }
        return out
    }
}

class SystemProvider(private val context: Context) : SpecProvider {
    override val category = Category.SYSTEM

    override fun read(): List<Spec> {
        val up = SystemClock.elapsedRealtime()
        return listOf(
            Spec("Manufacturer", Build.MANUFACTURER),
            Spec("Brand", Build.BRAND),
            Spec("Model", Build.MODEL),
            Spec("Device", Build.DEVICE),
            Spec("Product", Build.PRODUCT),
            Spec("Android version", Build.VERSION.RELEASE),
            Spec("API level", Build.VERSION.SDK_INT.toString()),
            Spec("Build ID", Build.ID),
            Spec("Build display", Build.DISPLAY),
            spec("Build fingerprint", sensitive = true) { Build.FINGERPRINT },
            spec("Linux kernel") { System.getProperty("os.version") },
            Spec("Build type", Build.TYPE),
            spec("Security patch") { Build.VERSION.SECURITY_PATCH.takeIf { it.isNotBlank() } },
            spec("Bootloader") { Build.BOOTLOADER.takeIf { it.isNotBlank() && it != Build.UNKNOWN } },
            Spec("Uptime (incl. sleep)", Fmt.duration(up)),
            Spec("Last boot", java.text.DateFormat.getDateTimeInstance().format(java.util.Date(System.currentTimeMillis() - up)), Availability.APPROXIMATE),
            Spec("Language", Locale.getDefault().toLanguageTag()),
            Spec("Time zone", TimeZone.getDefault().id),
            Spec("Serial number", "Android does not give apps the serial number", Availability.UNAVAILABLE),
            Spec("System features", context.packageManager.systemAvailableFeatures.count { it.name != null }.toString() + " declared"),
        )
    }
}
