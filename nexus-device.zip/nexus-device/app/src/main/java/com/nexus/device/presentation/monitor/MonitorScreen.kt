package com.nexus.device.presentation.monitor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.presentation.Metric
import com.nexus.device.presentation.MonitorViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.LineChart
import com.nexus.device.presentation.components.groupShape
import java.text.DateFormat
import java.util.Date

@Composable
fun MonitorScreen(vm: MonitorViewModel, unit: TempUnit, modifier: Modifier = Modifier, listState: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val sessions by vm.sessions.collectAsStateWithLifecycle()
    val interval by vm.intervalMs.collectAsStateWithLifecycle()

    // Monitoring is never left running in the background: leaving the app stops and saves the session.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) vm.stop() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val values: List<Float> = ui.samples.mapNotNull {
        when (ui.metric) {
            Metric.RAM -> it.ramUsedPercent
            Metric.TEMP -> it.batteryTempC?.let { t -> Fmt.tempValue(t, unit) }
            Metric.BATTERY -> it.batteryLevel?.toFloat()
            Metric.STORAGE -> it.storageUsedPercent
        }
    }
    val suffix = when (ui.metric) {
        Metric.TEMP -> if (unit == TempUnit.C) " °C" else " °F"
        else -> " %"
    }

    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { BigTitle(stringResource(R.string.tab_monitor)) }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Metric.entries.forEach { m ->
                    FilterChip(
                        selected = ui.metric == m, onClick = { vm.setMetric(m) },
                        label = {
                            Text(
                                when (m) {
                                    Metric.RAM -> stringResource(R.string.ram)
                                    Metric.TEMP -> stringResource(R.string.temperature)
                                    Metric.BATTERY -> stringResource(R.string.battery)
                                    Metric.STORAGE -> stringResource(R.string.storage_used)
                                },
                                maxLines = 1,
                            )
                        },
                    )
                }
            }
        }

        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (values.size < 2) {
                    Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                        Text(
                            if (ui.metric == Metric.TEMP && ui.samples.isNotEmpty() && values.isEmpty()) stringResource(R.string.no_temp) else stringResource(R.string.press_start),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    LineChart(listOf(values), Modifier.fillMaxWidth().height(150.dp))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stat(stringResource(R.string.stat_min), values.minOrNull(), suffix)
                    Stat(stringResource(R.string.stat_avg), if (values.isEmpty()) null else values.average().toFloat(), suffix)
                    Stat(stringResource(R.string.stat_max), values.maxOrNull(), suffix)
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (ui.running) vm.stop() else vm.start() }) {
                    Text(stringResource(if (ui.running) R.string.monitor_stop else R.string.monitor_start))
                }
                Text(stringResource(R.string.interval), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp))
                listOf(500L, 1000L, 2000L).forEach { ms ->
                    FilterChip(selected = interval == ms, onClick = { vm.setInterval(ms) }, label = { Text(if (ms < 1000) "0.5 s" else "${ms / 1000} s") })
                }
            }
        }

        item {
            // Per-core frequencies and connection state of the latest sample.
            val last = ui.samples.lastOrNull()
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ItemRow(
                    stringResource(R.string.cpu_freq_mhz),
                    subtitle = when {
                        last == null -> stringResource(R.string.press_start)
                        last.cpuFreqKHz.all { it == null } -> stringResource(R.string.cpu_freq_hidden)
                        else -> last.cpuFreqKHz.mapIndexed { i, f -> "cpu$i ${f?.let { it / 1000 } ?: "—"}" }.joinToString("  ")
                    },
                    shape = groupShape(0, 2),
                )
                ItemRow(
                    stringResource(R.string.cat_network),
                    subtitle = when {
                        last == null -> stringResource(R.string.press_start)
                        last.networkOnline -> stringResource(R.string.online)
                        else -> stringResource(R.string.offline)
                    },
                    shape = groupShape(1, 2),
                )
            }
        }

        item { Text(stringResource(R.string.monitor_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }

        item { Text(stringResource(R.string.sessions), style = MaterialTheme.typography.titleMedium) }
        if (sessions.isEmpty()) {
            item { Text(stringResource(R.string.no_sessions), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    sessions.take(20).forEachIndexed { i, s ->
                        ItemRow(
                            title = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(s.startedAt)) + " · " + Fmt.duration(s.durationMs),
                            subtitle = stringResource(R.string.session_line, "", s.samples, Fmt.one(s.ramAvg), Fmt.one(s.ramMax)).removePrefix(" · ") +
                                (s.tempMax?.let { " · max " + Fmt.temp(it.toFloat(), unit) } ?: "") +
                                (if (s.batteryStart != null && s.batteryEnd != null) " · ${s.batteryStart}→${s.batteryEnd} %" else ""),
                            shape = groupShape(i, minOf(sessions.size, 20)),
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

@Composable
private fun Stat(label: String, v: Float?, suffix: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(if (v == null) "—" else Fmt.one(v.toDouble()) + suffix, style = MaterialTheme.typography.titleMedium)
    }
}
