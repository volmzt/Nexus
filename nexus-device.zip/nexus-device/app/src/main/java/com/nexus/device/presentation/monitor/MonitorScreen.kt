package com.nexus.device.presentation.monitor

import android.Manifest
import com.nexus.device.presentation.components.cardSurface
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.monitoring.TempReader
import com.nexus.device.monitoring.TempService
import com.nexus.device.monitoring.Temps
import com.nexus.device.presentation.SettingsViewModel
import com.nexus.device.presentation.ThrottleViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.LineChart
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.toast
import kotlin.math.max

@Composable
fun MonitorScreen(
    thr: ThrottleViewModel,
    settingsVm: SettingsViewModel,
    unit: TempUnit,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
) {
    val ctx = LocalContext.current
    val s by settingsVm.settings.collectAsStateWithLifecycle()
    val t by thr.ui.collectAsStateWithLifecycle()
    val owner = LocalLifecycleOwner.current

    // Fresh temperature readings, only while the screen is visible.
    var temps by remember { mutableStateOf<Temps?>(null) }
    var battHist by remember { mutableStateOf(listOf<Float>()) }
    var cpuHist by remember { mutableStateOf(listOf<Float>()) }
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                val r = TempReader.read(ctx)
                temps = r
                r.batteryC?.let { battHist = (battHist + Fmt.tempValue(it, unit)).takeLast(60) }
                r.cpuC?.let { cpuHist = (cpuHist + Fmt.tempValue(it, unit)).takeLast(60) }
                kotlinx.coroutines.delay(1500)
            }
        }
    }

    // The screen stays on while the throttling test runs, otherwise Android would put the phone to sleep.
    val view = LocalView.current
    DisposableEffect(t.running) {
        view.keepScreenOn = t.running
        onDispose { view.keepScreenOn = false }
    }

    val permMsg = stringResource(R.string.no_notif_perm)
    val askPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { settingsVm.setTempNotify(true); TempService.start(ctx) } else toast(ctx, permMsg)
    }
    fun setNotify(on: Boolean) {
        if (!on) { settingsVm.setTempNotify(false); TempService.stop(ctx); return }
        val need = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (need) askPerm.launch(Manifest.permission.POST_NOTIFICATIONS) else { settingsVm.setTempNotify(true); TempService.start(ctx) }
    }

    val na = stringResource(R.string.st_na)
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { BigTitle(stringResource(R.string.tab_monitor)) }

        // Temperatures
        item {
            Column(
                Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(stringResource(R.string.temps_title), style = MaterialTheme.typography.titleMedium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(stringResource(R.string.temp_battery), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(temps?.batteryC?.let { Fmt.temp(it, unit) } ?: na, style = MaterialTheme.typography.headlineMedium)
                    }
                    Column {
                        Text(stringResource(R.string.temp_cpu), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(temps?.cpuC?.let { Fmt.temp(it, unit) } ?: na, style = MaterialTheme.typography.headlineMedium)
                    }
                }
                if (battHist.size >= 2 || cpuHist.size >= 2) LineChart(listOf(battHist, cpuHist), Modifier.fillMaxWidth().height(90.dp))
                if (temps != null && temps?.cpuC == null) {
                    Text(stringResource(R.string.temp_cpu_hidden), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // Notification switch
        item {
            ItemRow(
                stringResource(R.string.temp_notify), stringResource(R.string.temp_notify_desc), shape = groupShape(0, 1),
                onClick = { setNotify(!s.tempNotify) },
                trailing = { Switch(checked = s.tempNotify, onCheckedChange = { setNotify(it) }) },
            )
            Spacer(Modifier.height(8.dp))
        }

        // Throttling test
        item {
            Column(
                Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(stringResource(R.string.throttle), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.throttle_desc), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    if (!t.running) Button(onClick = { thr.start() }) { Text(stringResource(R.string.thr_start)) }
                    else OutlinedButton(onClick = { thr.stop() }) { Text(stringResource(R.string.thr_stop)) }
                    if (t.seconds > 0) Text(stringResource(R.string.thr_elapsed, t.seconds), style = MaterialTheme.typography.bodyLarge)
                }
                if (t.perf.isNotEmpty()) {
                    Text(stringResource(R.string.thr_perf), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LineChart(listOf(t.perf), Modifier.fillMaxWidth().height(110.dp), maxPoints = max(60, t.perf.size))
                    t.dropPercent?.let { Text(stringResource(R.string.thr_drop, Fmt.one(it.toDouble())), style = MaterialTheme.typography.bodyLarge) }
                    if (t.battery.size >= 2 || t.cpu.size >= 2) {
                        Text(stringResource(R.string.thr_temp_chart), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        LineChart(listOf(t.battery, t.cpu), Modifier.fillMaxWidth().height(90.dp), maxPoints = max(60, max(t.battery.size, t.cpu.size)))
                    }
                }
                t.stoppedHot?.let { Text(stringResource(R.string.thr_auto_stop, Fmt.one(it.toDouble())), color = MaterialTheme.colorScheme.error) }
                Text(stringResource(R.string.thr_limit), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(40, 43, 45, 48, 50).forEach { v ->
                        FilterChip(selected = s.stopTempC == v, onClick = { settingsVm.setStopTemp(v) }, label = { Text("$v°") })
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // The less useful tools live here, one tap away.
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ItemRow(stringResource(R.string.benchmarks), stringResource(R.string.benchmarks_desc), shape = groupShape(0, 2), onClick = { onOpen("tests") }, chevron = true)
                ItemRow(stringResource(R.string.core_freqs), stringResource(R.string.core_freqs_desc), shape = groupShape(1, 2), onClick = { onOpen("cores") }, chevron = true)
            }
            Spacer(Modifier.height(120.dp))
        }
    }
}
