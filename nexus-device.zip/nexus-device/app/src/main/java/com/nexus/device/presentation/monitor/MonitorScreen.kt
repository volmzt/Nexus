package com.nexus.device.presentation.monitor

import android.Manifest
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.nexus.device.presentation.components.cardSurface
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.nexus.device.R
import com.nexus.device.core.Fmt
import com.nexus.device.core.TempUnit
import com.nexus.device.monitoring.TempReader
import com.nexus.device.monitoring.TempService
import com.nexus.device.monitoring.Temps
import com.nexus.device.presentation.SettingsViewModel
import com.nexus.device.presentation.ThrottleViewModel
import com.nexus.device.presentation.components.BigTitle
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.LineChart
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.toast

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun MonitorScreen(
    thr: ThrottleViewModel,
    settingsVm: SettingsViewModel,
    unit: TempUnit,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
) {
    val ctx = LocalContext.current
    val s by settingsVm.settings.collectAsStateWithLifecycle()
    val t by thr.ui.collectAsStateWithLifecycle()
    val owner = LocalLifecycleOwner.current

    // Fresh temperature readings, only while the screen is visible.
    var temps by remember { mutableStateOf<Temps?>(null) }
    var battHist by remember { mutableStateOf(listOf<Float>()) }
    var cpuHist by remember { mutableStateOf(listOf<Float>()) }
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                val r = TempReader.read(ctx)
                temps = r
                r.batteryC?.let { battHist = (battHist + Fmt.tempValue(it, unit)).takeLast(60) }
                r.cpuC?.let { cpuHist = (cpuHist + Fmt.tempValue(it, unit)).takeLast(60) }
                kotlinx.coroutines.delay(1500)
            }
        }
    }

    val permMsg = stringResource(R.string.no_notif_perm)
    val askPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { settingsVm.setTempNotify(true); TempService.start(ctx) } else toast(ctx, permMsg)
    }
    fun setNotify(on: Boolean) {
        if (!on) { settingsVm.setTempNotify(false); TempService.stop(ctx); return }
        val need = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (need) askPerm.launch(Manifest.permission.POST_NOTIFICATIONS) else { settingsVm.setTempNotify(true); TempService.start(ctx) }
    }

    val ovNeed = stringResource(R.string.ov_need_perm)
    val overlayLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (com.nexus.device.overlay.OverlayService.canDraw(ctx)) { settingsVm.setOverlayOn(true); com.nexus.device.overlay.OverlayService.start(ctx) } else toast(ctx, ovNeed)
    }
    fun setOverlay(on: Boolean) {
        if (!on) { settingsVm.setOverlayOn(false); com.nexus.device.overlay.OverlayService.stop(ctx); return }
        if (com.nexus.device.overlay.OverlayService.canDraw(ctx)) { settingsVm.setOverlayOn(true); com.nexus.device.overlay.OverlayService.start(ctx) }
        else overlayLauncher.launch(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + ctx.packageName)))
    }
    val ovNames = mapOf(
        "pct" to stringResource(R.string.ov_pct), "fps" to "FPS", "time" to stringResource(R.string.ov_time),
        "temp" to stringResource(R.string.ov_temp), "cpu" to stringResource(R.string.ov_cpu), "load" to stringResource(R.string.ov_load),
        "mhz" to "MHz", "ram" to "RAM",
    )

    val na = stringResource(R.string.st_na)
    LazyColumn(modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        item { BigTitle(stringResource(R.string.tab_monitor)) }

        item {
            ItemRow(
                stringResource(R.string.hw_title), stringResource(R.string.hw_desc), icon = Icons.Filled.Tune,
                shape = groupShape(0, 1), onClick = { onOpen("hwcheck") }, chevron = true,
            )
            Spacer(Modifier.height(8.dp))
        }

        // Temperatures
        item {
            Column(
                Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(stringResource(R.string.temps_title), style = MaterialTheme.typography.titleMedium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(stringResource(R.string.temp_battery), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(temps?.batteryC?.let { Fmt.temp(it, unit) } ?: na, style = MaterialTheme.typography.headlineMedium)
                    }
                    Column {
                        Text(stringResource(R.string.temp_cpu), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(temps?.cpuC?.let { Fmt.temp(it, unit) } ?: na, style = MaterialTheme.typography.headlineMedium)
                    }
                }
                if (battHist.size >= 2 || cpuHist.size >= 2) LineChart(listOf(battHist, cpuHist), Modifier.fillMaxWidth().height(90.dp))
                if (temps != null && temps?.cpuC == null) {
                    Text(stringResource(R.string.temp_cpu_hidden), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // Notification switch
        item {
            ItemRow(
                stringResource(R.string.temp_notify), stringResource(R.string.temp_notify_desc), shape = groupShape(0, 1),
                onClick = { setNotify(!s.tempNotify) },
                trailing = { Switch(checked = s.tempNotify, onCheckedChange = { setNotify(it) }) },
            )
            Spacer(Modifier.height(8.dp))
        }

        // Overheat warning
        item {
            ItemRow(
                stringResource(R.string.hot_row), stringResource(R.string.hot_row_d), shape = groupShape(0, 1),
                onClick = { settingsVm.setOverheatAlert(!s.overheatAlert) },
                trailing = { Switch(checked = s.overheatAlert, onCheckedChange = { settingsVm.setOverheatAlert(it) }) },
            )
            Spacer(Modifier.height(8.dp))
        }

        // Floating window
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ItemRow(
                    stringResource(R.string.ov_title), stringResource(R.string.ov_desc), shape = groupShape(0, if (s.overlayOn) 2 else 1),
                    onClick = { setOverlay(!s.overlayOn) },
                    trailing = { Switch(checked = s.overlayOn, onCheckedChange = { setOverlay(it) }) },
                )
                if (s.overlayOn) {
                    val chosen = com.nexus.device.overlay.OverlayItems.decode(s.overlayItems)
                    Column(Modifier.fillMaxWidth().cardSurface(groupShape(1, 2)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            com.nexus.device.overlay.OverlayItems.all.forEach { id ->
                                androidx.compose.material3.FilterChip(
                                    selected = id in chosen,
                                    onClick = {
                                        val next = com.nexus.device.overlay.OverlayItems.all.filter { (it in chosen) != (it == id) }
                                        if (next.isNotEmpty()) settingsVm.setOverlayItems(next.joinToString(","))
                                    },
                                    label = { Text(ovNames[id] ?: id) },
                                )
                            }
                        }
                        Text(stringResource(R.string.ov_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // Throttling test: a full screen of its own
        item {
            ItemRow(
                stringResource(R.string.throttle),
                if (t.running) stringResource(R.string.thr_running, t.seconds / 60, t.seconds % 60) else stringResource(R.string.thr_row_desc),
                icon = Icons.Filled.ShowChart, shape = groupShape(0, 1), onClick = { onOpen("throttle") }, chevron = true,
            )
            Spacer(Modifier.height(8.dp))
        }

        // The less useful tools live here, one tap away.
        item {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ItemRow(stringResource(R.string.benchmarks), stringResource(R.string.benchmarks_desc), shape = groupShape(0, 2), onClick = { onOpen("tests") }, chevron = true)
                ItemRow(stringResource(R.string.core_freqs), stringResource(R.string.core_freqs_desc), shape = groupShape(1, 2), onClick = { onOpen("cores") }, chevron = true)
            }
            Spacer(Modifier.height(120.dp))
        }
    }
}
