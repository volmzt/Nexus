package com.nexus.device.monitoring

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.nexus.device.access.AccessMode
import com.nexus.device.access.Privileged
import com.nexus.device.hardware.ThermalReader

data class Temps(
    val batteryC: Float?,
    val cpuC: Float?,
    val zones: List<ThermalReader.Zone>,
    /** True when the zones came through Shizuku or root rather than from the app's own rights. */
    val privileged: Boolean,
)

/** One fresh reading of every temperature the phone lets us see. Nothing is cached or invented. */
object TempReader {
    private val cpuSmooth = ThermalReader.Smoother()

    suspend fun read(context: Context): Temps {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val battery = if (raw == Int.MIN_VALUE || raw <= 0) null else raw / 10f

        var zones = ThermalReader.zones()
        var priv = false
        if (zones.isEmpty() && Privileged.state.value.mode != AccessMode.NONE) {
            val r = Privileged.exec(ThermalReader.DUMP_CMD)
            zones = ThermalReader.parse(r.out)
            priv = zones.isNotEmpty()
        }
        return Temps(battery, cpuSmooth.push(ThermalReader.cpuOf(zones)), zones, priv)
    }
}
