package com.nexus.device

import android.graphics.Color
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexus.device.data.AppSettings
import com.nexus.device.data.ThemeMode
import com.nexus.device.domain.Category
import com.nexus.device.presentation.AppViewModelFactory
import com.nexus.device.presentation.DeviceViewModel
import com.nexus.device.presentation.HomeViewModel
import com.nexus.device.presentation.ThrottleViewModel
import com.nexus.device.presentation.ControlViewModel
import com.nexus.device.presentation.battery.BatteryHealthScreen
import com.nexus.device.presentation.battery.BatteryHealthViewModel
import com.nexus.device.presentation.control.ControlScreen
import com.nexus.device.presentation.control.TerminalScreen
import com.nexus.device.presentation.SettingsViewModel
import com.nexus.device.presentation.components.NavTab
import com.nexus.device.presentation.components.NexusNavBar
import com.nexus.device.presentation.device.CategoryDetailScreen
import com.nexus.device.presentation.device.CpuLiveCores
import com.nexus.device.presentation.device.DeviceScreen
import com.nexus.device.presentation.device.DetailHeader
import androidx.compose.foundation.lazy.LazyColumn
import com.nexus.device.presentation.home.HomeScreen
import com.nexus.device.presentation.monitor.MonitorScreen
import com.nexus.device.presentation.settings.PrivacyScreen
import com.nexus.device.presentation.settings.SettingsScreen
import com.nexus.device.presentation.tests.TestsScreen
import com.nexus.device.presentation.tests.Tool
import com.nexus.device.presentation.theme.NexusTheme
import com.nexus.device.presentation.theme.appBackdrop
import com.nexus.device.presentation.tools.AppsScreen
import com.nexus.device.presentation.tools.CodecsScreen
import com.nexus.device.presentation.tools.GpuExtensionsScreen
import com.nexus.device.presentation.tools.SensorsLiveScreen
import androidx.compose.material3.Button
import androidx.compose.material3.Text

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as NexusApplication).container
        setContent {
            val factory = AppViewModelFactory(container)
            val settingsVm: SettingsViewModel = viewModel(factory = factory)
            val s by settingsVm.settings.collectAsStateWithLifecycle()
            val dark = when (s.theme) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            // Edge-to-edge with bar icons that follow the chosen theme, not the system one.
            androidx.compose.runtime.SideEffect {
                enableEdgeToEdge(
                    statusBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                )
            }
            NexusTheme(dark, s.style, s.accent, s.corners, s.textSize) {
                androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().appBackdrop(dark, s.style, s.animatedBg, s.palette, s.bgSpeed)) {
                    Surface(Modifier.fillMaxSize(), color = androidx.compose.ui.graphics.Color.Transparent, contentColor = androidx.compose.material3.MaterialTheme.colorScheme.onBackground) {
                        androidx.compose.runtime.CompositionLocalProvider(com.nexus.device.presentation.theme.LocalBgPalette provides s.palette) {
                            AppRoot(factory, settingsVm, s)
                        }
                    }
                }
            }
        }
    }
}

/** Detail destinations are plain strings so they survive rotation with rememberSaveable. */
private fun catRoute(c: Category) = "cat:${c.id}"

@Composable
private fun AppRoot(factory: AppViewModelFactory, settingsVm: SettingsViewModel, settings: AppSettings) {
    val homeVm: HomeViewModel = viewModel(factory = factory)
    val deviceVm: DeviceViewModel = viewModel(factory = factory)
    val throttleVm: ThrottleViewModel = viewModel(factory = factory)
    val controlVm: ControlViewModel = viewModel(factory = factory)
    val batteryVm: BatteryHealthViewModel = viewModel(factory = factory)
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // The temperature notification is a user choice that survives restarts: bring the service back if it was on.
    androidx.compose.runtime.LaunchedEffect(settings.tempNotify) { if (settings.tempNotify) com.nexus.device.monitoring.TempService.start(ctx) }
    val benchVm: com.nexus.device.presentation.bench.BenchViewModel = viewModel(factory = factory)

    var tab by rememberSaveable { mutableStateOf(0) }
    var route by rememberSaveable { mutableStateOf<String?>(null) }

    // Back: close the detail page first, then return to Home, then leave the app.
    var homeEdit by rememberSaveable { mutableStateOf(false) }
    val homeScroll = androidx.compose.foundation.rememberScrollState()
    BackHandler(enabled = route != null || tab != 0 || homeEdit) {
        if (route != null) route = null else if (homeEdit) homeEdit = false else tab = 0
    }

    val tabs = listOf(
        NavTab(stringResource(R.string.tab_home), Icons.Filled.Home),
        NavTab(stringResource(R.string.tab_device), Icons.Filled.Smartphone),
        NavTab(stringResource(R.string.tab_control), Icons.Filled.Tune),
        NavTab(stringResource(R.string.tab_monitor), Icons.Filled.ShowChart),
        NavTab(stringResource(R.string.tab_settings), Icons.Filled.Settings),
    )
    val openCat: (Category) -> Unit = { route = catRoute(it) }
    // Scroll positions live here, above AnimatedContent, so leaving a screen and coming back keeps the place.
    val tabStates = List(5) { rememberLazyListState() }
    val routeStates = remember { mutableMapOf<String, LazyListState>() }

    Box(Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = route,
            transitionSpec = {
                val deeper = targetState != null && initialState == null
                val shallower = targetState == null && initialState != null
                when {
                    deeper -> (slideInHorizontally(tween(420)) { it / 4 } + fadeIn(tween(420))) togetherWith (fadeOut(tween(200)))
                    shallower -> fadeIn(tween(320)) togetherWith (slideOutHorizontally(tween(320)) { it / 4 } + fadeOut(tween(250)))
                    // Switching tabs is instant: cross-fading two heavy screens is what made it stutter.
                    else -> androidx.compose.animation.EnterTransition.None togetherWith androidx.compose.animation.ExitTransition.None
                }
            },
            label = "root",
        ) { r ->
            val t = tab
            val m = Modifier.fillMaxSize()
            val back = { route = null }
            when {
                r == null -> when (t) {
                    0 -> HomeScreen(
                        homeVm, settings.tempUnit, settings.homeBlocks, homeEdit, settings.palette, benchVm,
                        { run -> if (run) benchVm.start(); route = "bench" }, openCat, { route = it },
                        settingsVm::setHomeBlocks, { homeEdit = it }, settings.plainHome, m, homeScroll,
                    )
                    1 -> DeviceScreen(deviceVm, settings.hiddenCategories, settings.detailed, settingsVm::setDetailed, openCat, m, tabStates[1])
                    2 -> ControlScreen(controlVm, settings.tempUnit, { route = it }, m, tabStates[2])
                    3 -> MonitorScreen(throttleVm, settingsVm, settings.tempUnit, { route = it }, m, tabStates[3])
                    else -> SettingsScreen(settingsVm, { route = "privacy" }, { route = "custom" }, m, tabStates[4])
                }
                r == "bench" -> com.nexus.device.presentation.bench.BenchScreen(benchVm, back, m)
                r == "tests" -> TestsScreen({ tool ->
                    route = when (tool) { Tool.SENSORS_LIVE -> "sensors_live" }
                }, m, back)
                r == "battery_health" -> BatteryHealthScreen(batteryVm, settings.tempUnit, back, m)
                r == "hwcheck" -> com.nexus.device.presentation.hwcheck.HwCheckScreen(back, { route = "sensors_live" }, m)
                r == "terminal" -> TerminalScreen(back, m)
                r == "throttle" -> com.nexus.device.presentation.monitor.ThrottleScreen(throttleVm, settingsVm, settings.tempUnit, back, m)
                r == "cores" -> LazyColumn(m.padding(horizontal = 16.dp)) {
                    item { DetailHeader(stringResource(R.string.core_freqs), back) }
                    item { CpuLiveCores() }
                }
                r == "sensors_live" -> SensorsLiveScreen({ route = catRoute(Category.SENSORS) }, m)
                r == "gpu_ext" -> GpuExtensionsScreen({ route = catRoute(Category.GPU) }, m)
                r == "privacy" -> PrivacyScreen(back, m)
                r == "custom" -> com.nexus.device.presentation.settings.CustomizeScreen(settingsVm, back, { route = null; tab = 0; homeEdit = true }, m)
                r.startsWith("cat:") -> {
                    val cat = Category.entries.firstOrNull { it.id == r.removePrefix("cat:") } ?: Category.SYSTEM
                    when (cat) {
                        Category.CODECS -> CodecsScreen(back, m)
                        Category.APPS -> AppsScreen(back, m)
                        else -> CategoryDetailScreen(cat, deviceVm, settings.detailed, settingsVm::setDetailed, back, m, routeStates.getOrPut(r) { LazyListState() }) {
                            when (cat) {
                                Category.BATTERY -> Button(onClick = { route = "battery_health" }) { Text(stringResource(R.string.bh_title)) }
                                Category.CPU -> Button(onClick = { route = "cores" }) { Text(stringResource(R.string.core_freqs)) }
                                Category.GPU -> Button(onClick = { route = "gpu_ext" }) { Text(stringResource(R.string.gpu_extensions)) }
                                Category.SENSORS -> Button(onClick = { route = "sensors_live" }) { Text(stringResource(R.string.sensors_live)) }
                                else -> {}
                            }
                        }
                    }
                }
                else -> HomeScreen(
                        homeVm, settings.tempUnit, settings.homeBlocks, homeEdit, settings.palette, benchVm,
                        { run -> if (run) benchVm.start(); route = "bench" }, openCat, { route = it },
                        settingsVm::setHomeBlocks, { homeEdit = it }, settings.plainHome, m, homeScroll,
                    )
            }
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = route == null,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(200)), exit = fadeOut(tween(120)),
        ) {
            NexusNavBar(
                tabs, tab, { tab = it },
                Modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
            )
        }
    }
}
