package com.nexus.device

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexus.device.data.AppSettings
import com.nexus.device.data.ThemeMode
import com.nexus.device.domain.Category
import com.nexus.device.presentation.AnalyzerViewModel
import com.nexus.device.presentation.AppViewModelFactory
import com.nexus.device.presentation.BenchmarkViewModel
import com.nexus.device.presentation.DeviceViewModel
import com.nexus.device.presentation.HomeViewModel
import com.nexus.device.presentation.MonitorViewModel
import com.nexus.device.presentation.NetDiagViewModel
import com.nexus.device.presentation.SettingsViewModel
import com.nexus.device.presentation.components.NavTab
import com.nexus.device.presentation.components.NexusNavBar
import com.nexus.device.presentation.device.CategoryDetailScreen
import com.nexus.device.presentation.device.CpuLiveCores
import com.nexus.device.presentation.device.DeviceScreen
import com.nexus.device.presentation.home.HomeScreen
import com.nexus.device.presentation.monitor.MonitorScreen
import com.nexus.device.presentation.settings.PrivacyScreen
import com.nexus.device.presentation.settings.SettingsScreen
import com.nexus.device.presentation.tests.TestsScreen
import com.nexus.device.presentation.tests.Tool
import com.nexus.device.presentation.theme.NexusTheme
import com.nexus.device.presentation.tools.AnalyzerScreen
import com.nexus.device.presentation.tools.AppsScreen
import com.nexus.device.presentation.tools.CodecsScreen
import com.nexus.device.presentation.tools.GpuExtensionsScreen
import com.nexus.device.presentation.tools.NetDiagScreen
import com.nexus.device.presentation.tools.SensorsLiveScreen
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as NexusApplication).container
        setContent {
            val factory = AppViewModelFactory(container)
            val settingsVm: SettingsViewModel = viewModel(factory = factory)
            val s by settingsVm.settings.collectAsStateWithLifecycle()
            val dark = when (s.theme) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            // Edge-to-edge with bar icons that follow the chosen theme, not the system one.
            androidx.compose.runtime.SideEffect {
                enableEdgeToEdge(
                    statusBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
                )
            }
            NexusTheme(dark) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot(factory, settingsVm, s)
                }
            }
        }
    }
}

/** Detail destinations are plain strings so they survive rotation with rememberSaveable. */
private fun catRoute(c: Category) = "cat:${c.id}"

@Composable
private fun AppRoot(factory: AppViewModelFactory, settingsVm: SettingsViewModel, settings: AppSettings) {
    val homeVm: HomeViewModel = viewModel(factory = factory)
    val deviceVm: DeviceViewModel = viewModel(factory = factory)
    val monitorVm: MonitorViewModel = viewModel(factory = factory)
    val benchVm: BenchmarkViewModel = viewModel(factory = factory)
    val analyzerVm: AnalyzerViewModel = viewModel(factory = factory)
    val netVm: NetDiagViewModel = viewModel(factory = factory)

    var tab by rememberSaveable { mutableStateOf(0) }
    var route by rememberSaveable { mutableStateOf<String?>(null) }

    // Back: close the detail page first, then return to Home, then leave the app.
    BackHandler(enabled = route != null || tab != 0) {
        if (route != null) route = null else tab = 0
    }

    val tabs = listOf(
        NavTab(stringResource(R.string.tab_home), Icons.Filled.Home),
        NavTab(stringResource(R.string.tab_device), Icons.Filled.Smartphone),
        NavTab(stringResource(R.string.tab_monitor), Icons.Filled.ShowChart),
        NavTab(stringResource(R.string.tab_tests), Icons.Filled.Science),
        NavTab(stringResource(R.string.tab_settings), Icons.Filled.Settings),
    )
    val openCat: (Category) -> Unit = { route = catRoute(it) }
    // Scroll positions live here, above AnimatedContent, so leaving a screen and coming back keeps the place.
    val tabStates = List(5) { rememberLazyListState() }
    val routeStates = remember { mutableMapOf<String, LazyListState>() }

    Box(Modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = route to tab,
            transitionSpec = {
                val deeper = targetState.first != null && initialState.first == null
                val shallower = targetState.first == null && initialState.first != null
                when {
                    deeper -> (slideInHorizontally(tween(420)) { it / 4 } + fadeIn(tween(420))) togetherWith (fadeOut(tween(200)))
                    shallower -> fadeIn(tween(320)) togetherWith (slideOutHorizontally(tween(320)) { it / 4 } + fadeOut(tween(250)))
                    else -> fadeIn(tween(300)) togetherWith fadeOut(tween(160))
                }
            },
            label = "root",
        ) { (r, t) ->
            val m = Modifier.fillMaxSize()
            val back = { route = null }
            when {
                r == null -> when (t) {
                    0 -> HomeScreen(homeVm, settings.tempUnit, settings.hiddenCategories, openCat, m, tabStates[0])
                    1 -> DeviceScreen(deviceVm, settings.hiddenCategories, settings.detailed, settingsVm::setDetailed, openCat, m, tabStates[1])
                    2 -> MonitorScreen(monitorVm, settings.tempUnit, m, tabStates[2])
                    3 -> TestsScreen(benchVm, { tool ->
                        route = when (tool) { Tool.NET -> "net"; Tool.ANALYZER -> "analyzer"; Tool.SENSORS_LIVE -> "sensors_live" }
                    }, m, tabStates[3])
                    else -> SettingsScreen(settingsVm, { route = "privacy" }, m, tabStates[4])
                }
                r == "net" -> NetDiagScreen(netVm, back, m)
                r == "analyzer" -> AnalyzerScreen(analyzerVm, back, m)
                r == "sensors_live" -> SensorsLiveScreen({ route = catRoute(Category.SENSORS) }, m)
                r == "gpu_ext" -> GpuExtensionsScreen({ route = catRoute(Category.GPU) }, m)
                r == "privacy" -> PrivacyScreen(back, m)
                r.startsWith("cat:") -> {
                    val cat = Category.entries.firstOrNull { it.id == r.removePrefix("cat:") } ?: Category.SYSTEM
                    when (cat) {
                        Category.CODECS -> CodecsScreen(back, m)
                        Category.APPS -> AppsScreen(back, m)
                        else -> CategoryDetailScreen(cat, deviceVm, settings.detailed, settingsVm::setDetailed, back, m, routeStates.getOrPut(r) { LazyListState() }) {
                            when (cat) {
                                Category.CPU -> CpuLiveCores()
                                Category.GPU -> Button(onClick = { route = "gpu_ext" }) { Text(stringResource(R.string.gpu_extensions)) }
                                Category.SENSORS -> Button(onClick = { route = "sensors_live" }) { Text(stringResource(R.string.sensors_live)) }
                                Category.NETWORK -> Button(onClick = { route = "net" }) { Text(stringResource(R.string.net_diag)) }
                                Category.STORAGE -> Button(onClick = { route = "analyzer" }) { Text(stringResource(R.string.analyzer)) }
                                else -> {}
                            }
                        }
                    }
                }
                else -> HomeScreen(homeVm, settings.tempUnit, settings.hiddenCategories, openCat, m, tabStates[0])
            }
        }

        if (route == null) {
            NexusNavBar(
                tabs, tab, { tab = it },
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
            )
        }
    }
}
