package com.nexus.device.presentation.bench

import android.opengl.GLSurfaceView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import com.nexus.device.presentation.components.LineChart
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexus.device.R
import com.nexus.device.bench.BenchGroup
import com.nexus.device.bench.BenchRun
import com.nexus.device.bench.Catalog
import com.nexus.device.bench.GpuBenchRenderer
import com.nexus.device.bench.Scoring
import com.nexus.device.bench.formatPoints
import com.nexus.device.core.Fmt
import com.nexus.device.presentation.components.ItemRow
import com.nexus.device.presentation.components.cardSurface
import com.nexus.device.presentation.components.groupShape
import com.nexus.device.presentation.device.DetailHeader
import java.text.DateFormat
import java.util.Date
import kotlin.math.cos
import kotlin.math.sin

@androidx.annotation.StringRes
internal fun groupName(g: BenchGroup): Int = when (g) {
    BenchGroup.CPU -> R.string.bench_cpu
    BenchGroup.GPU -> R.string.bench_gpu
    BenchGroup.MEM -> R.string.bench_mem
    BenchGroup.UX -> R.string.bench_ux
}

/** The test page: score ring, the four group scores, progress while running, per-test details and history. */
@Composable
fun BenchScreen(vm: BenchViewModel, onBack: () -> Unit, modifier: Modifier = Modifier, listState: LazyListState = rememberLazyListState()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val run = ui.finished ?: history.firstOrNull()
    val previous = if (ui.finished != null && !ui.saved) history.getOrNull(0) else history.getOrNull(1)

    val view = LocalView.current
    DisposableEffect(ui.running) {
        view.keepScreenOn = ui.running
        onDispose { view.keepScreenOn = false }
    }
    DisposableEffect(Unit) { onDispose { vm.cancel() } }

    LazyColumn(
        modifier.fillMaxWidth().padding(horizontal = 16.dp), state = listState,
        verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        item { DetailHeader(stringResource(R.string.bench_title), onBack) }
        item {
            ScoreRing(
                score = if (ui.running) null else run?.total,
                progress = if (ui.running) ui.progress else 1f,
                label = if (ui.running) ui.step?.let { stringResource(it) } ?: "" else stringResource(R.string.bench_total),
            )
        }
        if (!ui.running && run != null && previous != null && previous.total > 0) {
            item {
                val d = (run.total.toDouble() / previous.total - 1) * 100
                Text(
                    stringResource(R.string.bench_vs_prev, (if (d >= 0) "+" else "") + Fmt.one(d) + " %"),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScoreTile(BenchGroup.CPU, run, Modifier.weight(1f))
                ScoreTile(BenchGroup.GPU, run, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScoreTile(BenchGroup.MEM, run, Modifier.weight(1f))
                ScoreTile(BenchGroup.UX, run, Modifier.weight(1f))
            }
        }

        item {
            if (ui.running) {
                OutlinedButton(onClick = { vm.cancel() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.bench_cancel)) }
            } else {
                Button(onClick = { vm.start() }, Modifier.fillMaxWidth()) { Text(stringResource(R.string.bench_run)) }
            }
        }

        if (ui.running) item { LivePanel() }

        // The GPU and smoothness tests need a real screen, so they are drawn here while they run.
        if (ui.host == BenchViewModel.Host.GPU) item {
            Column(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(stringResource(R.string.bench_gpu_hint), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                GpuHost { m, e -> vm.onGpu(m, e) }
            }
        }
        if (ui.host == BenchViewModel.Host.SMOOTH) item { SmoothnessTest { vm.onSmooth(it) } }

        if (!ui.running) {
            ui.hotC?.let { item { Text(stringResource(R.string.bench_hot, Fmt.one(it.toDouble())), color = MaterialTheme.colorScheme.error) } }
            items(ui.notes) { n -> Text(n, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }

        if (run != null && !ui.running) {
            item {
                Text(
                    stringResource(R.string.bench_temps, temp(run.battStartC), temp(run.battEndC), temp(run.cpuStartC), temp(run.cpuEndC)),
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            item { SectionTitle(R.string.bench_details) }
            val rows = run.scores
            items(rows.size) { i ->
                val s = rows[i]
                val def = Catalog.get(s.id)
                if (def != null) ItemRow(
                    stringResource(def.name), Fmt.one(s.value) + " " + def.unit, shape = groupShape(i, rows.size),
                    trailing = { Text(formatPoints(Scoring.points(s.value, def.reference)), style = MaterialTheme.typography.titleMedium) },
                )
            }
        }

        if (history.isNotEmpty() && !ui.running) {
            item { SectionTitle(R.string.bench_history) }
            val rows = history.take(10)
            items(rows.size) { i ->
                val r = rows[i]
                ItemRow(
                    formatPoints(r.total), DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(r.time)),
                    shape = groupShape(i, rows.size),
                )
            }
        }
        item { Spacer(Modifier.height(120.dp)) }
    }
}

private fun temp(v: Float?): String = v?.let { Fmt.one(it.toDouble()) + "°" } ?: "—"

@Composable
private fun SectionTitle(res: Int) {
    Text(
        stringResource(res), style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.fillMaxWidth().padding(top = 12.dp, start = 4.dp),
    )
}

@Composable
private fun ScoreTile(group: BenchGroup, run: BenchRun?, modifier: Modifier) {
    Column(
        modifier.cardSurface(RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(stringResource(groupName(group)), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(run?.let { formatPoints(it.group(group)) } ?: "—", style = MaterialTheme.typography.headlineSmall)
    }
}

/** The big ring: fills with progress while a test runs, shows the total when it is finished. */
@Composable
fun ScoreRing(score: Int?, progress: Float, label: String, modifier: Modifier = Modifier) {
    val sweep by animateFloatAsState(progress.coerceIn(0f, 1f), tween(500), label = "ring")
    val track = MaterialTheme.colorScheme.surfaceContainerHigh
    val colors = listOf(Color(0xFF2237FF), Color(0xFFB847F0), Color(0xFF6C3BFF), Color(0xFF2237FF))
    Box(modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val topLeft = Offset(stroke / 2, stroke / 2)
            val arcSize = Size(size.width - stroke, size.height - stroke)
            drawArc(track, 135f, 270f, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Brush.sweepGradient(colors), 135f, 270f * sweep, false, topLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(score?.let { formatPoints(it) } ?: "…", style = MaterialTheme.typography.displaySmall)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

/** A small GLSurfaceView. Its first frame runs the GPU test, so the view must be on screen while it runs. */
@Composable
private fun GpuHost(onResult: (com.nexus.device.bench.GpuMeasure?, String?) -> Unit) {
    AndroidView(
        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)),
        factory = { ctx ->
            GLSurfaceView(ctx).apply {
                setEGLContextClientVersion(3)
                setRenderer(GpuBenchRenderer { m, e -> post { onResult(m, e) } })
                renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            }
        },
    )
}

/**
 * Draws a few hundred moving shapes for three seconds and watches the frame times. The score is the share of frames
 * that were on time (within 1.5 frame intervals), scaled down if the average frame rate fell short of the display's.
 */
@Composable
private fun SmoothnessTest(onDone: (Double?) -> Unit) {
    var t by remember { mutableFloatStateOf(0f) }
    val refresh = LocalView.current.display?.refreshRate?.takeIf { it > 30f } ?: 60f

    LaunchedEffect(Unit) {
        val frames = ArrayList<Long>()
        val first = androidx.compose.runtime.withFrameNanos { it }
        var last = first
        while (last - first < 3_000_000_000L) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            frames.add(now - last)
            t = (now - first) / 1e9f
            last = now
        }
        val usable = frames.drop(5)
        if (usable.size < 10) { onDone(null); return@LaunchedEffect }
        val interval = 1e9 / refresh
        val onTime = usable.count { it <= interval * 1.5 }.toDouble() / usable.size
        val avgFps = 1e9 / usable.average()
        onDone(100.0 * onTime * minOf(1.0, avgFps / refresh))
    }

    Canvas(Modifier.fillMaxWidth().height(220.dp).cardSurface(RoundedCornerShape(24.dp))) {
        val time = t
        val brush = Brush.linearGradient(listOf(Color(0xFF2237FF), Color(0xFFB847F0)))
        for (i in 0 until 160) {
            val a = time * (0.6f + i % 5 * 0.15f) + i
            val cx = size.width * (0.5f + 0.45f * sin(a * 1.3f + i))
            val cy = size.height * (0.5f + 0.42f * cos(a * 0.9f + i * 0.5f))
            rotate(degrees = a * 40f, pivot = Offset(cx, cy)) {
                drawRoundRect(brush, Offset(cx - 18f, cy - 12f), Size(36f, 24f), CornerRadius(8f), alpha = 0.55f)
            }
        }
        for (i in 0 until 240) {
            val a = time * 1.4f + i * 0.21f
            drawCircle(Color.White.copy(alpha = 0.25f), 5f, Offset(size.width * (0.5f + 0.48f * cos(a)), size.height * (0.5f + 0.45f * sin(a * 1.7f))))
        }
    }
}


/** Temperature and per-core clock graphs, sampled once a second while a test runs. */
@Composable
private fun LivePanel() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var battery by remember { mutableStateOf(listOf<Float>()) }
    var cpu by remember { mutableStateOf(listOf<Float>()) }
    var clocks by remember { mutableStateOf(listOf<Float>()) }
    LaunchedEffect(Unit) {
        while (true) {
            val temps = com.nexus.device.monitoring.TempReader.read(ctx)
            val freqs = com.nexus.device.hardware.CpuFreqReader.allCurrent()
            temps.batteryC?.let { battery = (battery + it).takeLast(60) }
            temps.cpuC?.let { cpu = (cpu + it).takeLast(60) }
            val top = freqs.filterNotNull().maxOrNull()
            if (top != null) clocks = (clocks + top / 1_000_000f).takeLast(60)
            kotlinx.coroutines.delay(1000)
        }
    }
    Column(Modifier.fillMaxWidth().cardSurface(RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.bench_live_temps), style = MaterialTheme.typography.titleMedium)
        if (battery.size >= 2 || cpu.size >= 2) LineChart(listOf(battery, cpu), Modifier.fillMaxWidth().height(80.dp))
        else Text("…", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (clocks.size >= 2) {
            Text(stringResource(R.string.bench_live_clock, Fmt.one(clocks.last().toDouble())), style = MaterialTheme.typography.titleMedium)
            LineChart(listOf(clocks), Modifier.fillMaxWidth().height(80.dp))
        }
    }
}
