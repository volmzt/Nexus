package com.nexus.device.hardware

import android.app.ActivityManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import com.nexus.device.core.Fmt
import com.nexus.device.domain.Category

data class SummaryItem(val category: Category, val title: String, val value: String)

/** Headline facts for the Home screen. Everything is read from Android; a missing value is simply left out. */
object DeviceSummary {
    @Suppress("DEPRECATION")
    fun build(context: Context): List<SummaryItem> {
        val out = mutableListOf<SummaryItem>()
        out += SummaryItem(Category.SYSTEM, "Manufacturer", Build.MANUFACTURER.replaceFirstChar { it.uppercase() })
        out += SummaryItem(Category.SYSTEM, "Model", Build.MODEL)
        out += SummaryItem(Category.SYSTEM, "Device name", Build.DEVICE)
        out += SummaryItem(Category.SYSTEM, "Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        System.getProperty("os.version")?.takeIf { it.isNotBlank() }?.let { out += SummaryItem(Category.SYSTEM, "Kernel", it) }
        CpuInfo.socName()?.let { out += SummaryItem(Category.CPU, "Processor", "$it · ${Runtime.getRuntime().availableProcessors()} cores") }
        GlInfoReader.query()?.renderer?.let { out += SummaryItem(Category.GPU, "GPU", it) }
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        out += SummaryItem(Category.MEMORY, "RAM", Fmt.bytes(mi.totalMem))
        runCatching {
            val d = (context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
            val m = DisplayMetrics().also { d.getRealMetrics(it) }
            out += SummaryItem(Category.DISPLAY, "Display", "${m.widthPixels} × ${m.heightPixels} · ${String.format(java.util.Locale.US, "%.0f", d.refreshRate)} Hz")
        }
        return out
    }
}
