package com.nexus.device

import com.nexus.device.hardware.ThermalReader
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ThermalTests {
    @Test fun parsesMillidegreesAndDegrees() {
        val zones = ThermalReader.parse("cpu-0-0-usr 41500\nbattery 29.5\nbroken line\nnegative -5000\n")
        assertEquals(2, zones.size)
        assertEquals(41.5f, zones[0].tempC, 0.01f)
        assertEquals(29.5f, zones[1].tempC, 0.01f)
    }

    @Test fun cpuValueIsTheMedianOfCoreSensors() {
        val zones = ThermalReader.parse("cpu-0-0-usr 30000\ncpu-1-0-usr 40000\ncpu-2-0-usr 87000\nbattery 25000\ngpuss-0 90000")
        assertEquals(40f, ThermalReader.cpuOf(zones)!!, 0.01f)
    }

    @Test fun noCpuSensorGivesNull() {
        assertNull(ThermalReader.cpuOf(ThermalReader.parse("battery 25000\nusb 24000")))
    }

    @Test fun smootherIgnoresSingleSpikeButFollowsConfirmedChange() {
        val s = ThermalReader.Smoother(alpha = 0.5f, jump = 8f)
        assertEquals(30f, s.push(30f)!!, 0.01f)
        assertEquals(32f, s.push(34f)!!, 0.01f)
        assertEquals(32f, s.push(80f)!!, 0.01f)   // lone spike is held back
        assertEquals(33f, s.push(34f)!!, 0.01f)   // and forgotten
        assertEquals(33f, s.push(60f)!!, 0.01f)   // first reading of a real change
        assertEquals(60f, s.push(61f)!!, 0.01f)   // confirmed
        assertNotNull(s.push(null))
    }
}
