package com.nexus.device

import com.nexus.device.core.Availability
import com.nexus.device.core.Fmt
import com.nexus.device.core.Spec
import com.nexus.device.core.TempUnit
import com.nexus.device.core.spec
import com.nexus.device.domain.Category
import com.nexus.device.reporting.ReportBuilder
import com.nexus.device.reporting.ReportFormat
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreTests {
    @Test fun bytesFormatting() {
        assertEquals("512 B", Fmt.bytes(512))
        assertEquals("1.0 KB", Fmt.bytes(1024))
        assertEquals("1.5 GB", Fmt.bytes(1_610_612_736L))
    }

    @Test fun temperatureUnits() {
        assertEquals("36.6 °C", Fmt.temp(36.6f, TempUnit.C))
        assertEquals("98.6 °F", Fmt.temp(37f, TempUnit.F))
    }

    @Test fun durationFormatting() {
        assertEquals("1d 1h 1m", Fmt.duration(90_060_000L))
    }

    @Test fun specReportsNullAsUnavailable() {
        val s = spec("X") { null }
        assertEquals(Availability.UNAVAILABLE, s.availability)
    }

    @Test fun specReportsSecurityExceptionAsPermission() {
        val s = spec("X") { throw SecurityException("no") }
        assertEquals(Availability.PERMISSION, s.availability)
    }

    @Test fun specKeepsRealValue() {
        val s = spec("X", approximate = true) { "42" }
        assertEquals("42", s.value)
        assertEquals(Availability.APPROXIMATE, s.availability)
    }

    @Test fun reportHidesSensitiveValues() {
        val data = mapOf(Category.SYSTEM to listOf(Spec("Model", "A"), Spec("Fingerprint", "SECRET", sensitive = true)))
        val titles = mapOf(Category.SYSTEM to "System")
        val hidden = ReportBuilder.build(data, titles, ReportFormat.TXT, true, "1")
        val shown = ReportBuilder.build(data, titles, ReportFormat.TXT, false, "1")
        assertFalse(hidden.contains("SECRET"))
        assertTrue(shown.contains("SECRET"))
    }

    @Test fun htmlReportEscapesMarkup() {
        val data = mapOf(Category.SYSTEM to listOf(Spec("A", "<b>x</b>")))
        val html = ReportBuilder.build(data, mapOf(Category.SYSTEM to "System"), ReportFormat.HTML, false, "1")
        assertTrue(html.contains("&lt;b&gt;"))
        assertFalse(html.contains("<b>x</b>"))
    }
}
