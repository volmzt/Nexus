# NEXUS DEVICE

Native Android app (Kotlin, Jetpack Compose, Material 3) that reads device information from Android APIs and system files. No account, no ads, no analytics, no root. Minimum Android 8.0 (API 26).

## Status

The source code is complete for the stages below, but **it has not been compiled or run on a device yet**. The environment where it was written has no Android SDK and cannot reach Google Maven, so the first real build happens in GitHub Actions. Expect to fix a few compile errors on that first run. See "Testing" for what was and was not verified.

## Build

Requirements: JDK 17, Android SDK (compileSdk 35). Android Studio Ladybug or newer opens the project directly.

```
./gradlew testDebugUnitTest      # unit tests
./gradlew assembleDebug          # app/build/outputs/apk/debug/
./gradlew assembleRelease        # app/build/outputs/apk/release/
./gradlew bundleRelease          # app/build/outputs/bundle/release/ (AAB for Google Play)
```

### GitHub Actions

`.github/workflows/build.yml` runs tests, lint, and builds the debug APK, release APK and AAB, then uploads them as workflow artifacts. Push to `main` (or run the workflow by hand) and download the files from the run page.

### Release signing

Without secrets the release APK is signed with the debug key, which is fine for installing and testing but not for Google Play. To sign properly, add these repository secrets:

| Secret | Meaning |
| --- | --- |
| `NEXUS_KEYSTORE_BASE64` | your `.jks` file encoded with `base64 -w0` |
| `NEXUS_KEYSTORE_PASSWORD` | keystore password |
| `NEXUS_KEY_ALIAS` | key alias |
| `NEXUS_KEY_PASSWORD` | key password |

## Architecture

Single Gradle module, packages follow the layers from the brief:

| Package | Role |
| --- | --- |
| `core` | `Spec` model, availability states, the shared error mechanism `spec { }`, formatting, manual DI container |
| `domain` | `Category`, `SpecProvider`, `DeviceRepository`, `Sample` |
| `hardware` | One provider per category (CPU, GPU, memory, storage, system, display, battery, network, sensors, cameras, codecs, apps) |
| `monitoring` | `SystemSampler`: one real measurement per call |
| `diagnostics` | Benchmarks, latency test, SAF storage analyzer |
| `database` | Room: benchmark results, monitor sessions |
| `data` | DataStore settings |
| `reporting` | TXT, JSON, HTML and PDF report builders |
| `presentation` | Compose screens, view models (MVVM, `StateFlow`), theme and components |

Every hardware read goes through `spec { }`: a missing value becomes "not provided", a `SecurityException` becomes "needs permission", and nothing is ever replaced by an invented number.

## What works (by design, pending first build)

- Home: device summary, RAM, battery, storage meters and temperature, live mini charts built from real samples, refresh button, last-update time.
- Device: 12 categories, search across all values, tap to copy, per-value status (available, approximate, not provided, needs permission).
- CPU: SoC, cores, ABIs, features, per-core min/max/current frequency read from sysfs, shown as unavailable when Android hides it.
- GPU: renderer, vendor, OpenGL ES and GLSL versions, Vulkan version, extension list with search.
- Memory, storage, system, display, battery, network, sensors, cameras (Camera2 characteristics only, camera is never opened), codecs (audio/video, profiles, resolutions, frame rates), app catalog with search and sorting.
- Monitor: start/stop, interval 0.5/1/2 s, RAM / temperature / battery / storage chart, min, average, max, per-core frequencies, connection state, saved session history. Stops automatically when the app goes to the background.
- Tests: CPU single and multi thread, memory bandwidth, allocation, storage write and read, canvas rendering, sensor rate. Each test is capped at about a second, runs are refused above 42 °C battery temperature, results are saved and compared with your own previous run. Display tests: colour fills, gradient, gray steps, multi-touch drawing.
- Tools: network latency (only on button press), storage analyzer for a folder you pick (largest files, extensions, SHA-256 duplicates), live sensor graphs.
- Settings: theme (dark, light, system), temperature unit, hidden sections, per-app language (Android 13+), clear history, reports (save as TXT, JSON, HTML, PDF through the system file picker, or share as text), privacy policy, licenses.

## Update 1 (UI rework)

- Home: compact device card and live tiles (battery with temperature, CPU frequency and temperature, storage). CPU temperature is read from thermal zones when Android allows it, otherwise "not provided".
- Scroll position is kept per tab and per detail page.
- Bottom bar: no press ripple, only the sliding highlight.
- Device: one-line summary per section, Simple / Detailed switch, tap = explanation dialog ("?" marks rows with an explanation), long-press = copy.
- Languages: English, Russian, Ukrainian (explanations are translated, parameter names stay in English).
- Next: Shizuku/root access, editing DPI/refresh rate/animations, throttling test, notification monitor, terminal, hidden Xiaomi screens, NEXUS score.

## Update 2 (control, temperatures, terminal)

- New tab **Control** (kernel-manager style): access card (Shizuku / root), CPU clusters (governor, min/max frequency), GPU (Adreno kgsl: governor, max frequency), display (DPI, resolution, refresh rate, animation speed), tweaks, terminal. Changing CPU/GPU needs **root**; display and tweaks work with **Shizuku**. Every change is read back and reported if the system refused it.
- **Monitor** tab: live battery and CPU temperature, a persistent notification with both (works after the app is closed, off by default, stop button in the notification), all-core throttling test with performance graph and automatic stop at a battery temperature you choose. Benchmarks and per-core frequencies moved one tap deeper.
- **Terminal**: command runner with Normal / Shizuku / Root modes, quick commands, copy output.
- Fix: the sensor-rate test no longer asks for 0 microseconds (that needs HIGH_SAMPLING_RATE_SENSORS); it uses 200 Hz.
- CPU temperature: Android blocks the thermal files for normal apps; with Shizuku or root they are read through the shell.
- Not done yet: first-run guide and Shizuku wizard, Xiaomi hidden screens, overall NEXUS score, hiding extra tiles.

## Update 3 (stability, home, battery health, widget)

- CPU temperature is now the average of the core sensors with light smoothing (it used to show the single hottest sensor, which jumps by several degrees).
- Home: battery, processor (clock + temperature), RAM, load, storage, GPU, and a temperature history chart. Marketing model name when the vendor publishes it.
- Battery health page (Device > Battery): reported state, cycles, capacity estimate, 24 h history of charge and temperature. History is stored in Room only while the app or the temperature notification runs, and is deleted after 7 days.
- Home-screen widget with battery level, battery and CPU temperature.
- Room migration 1 to 2 keeps existing benchmark results.
- GPU: several driver file names are tried; shown as "not provided" when the phone exposes none.
- Fixes: single-core label, missing max frequency fallback, foreground-service start failures are caught, terminal output capped.
- Unit tests for the thermal parser and smoother.
- MIT license added.

## Android limits that apply

- Serial number, factory battery capacity, GPU driver version, MAC address: not available to apps.
- Wi-Fi name and BSSID need location permission, mobile network type needs phone-state permission. The app does not ask for either and shows them as "needs permission".
- CPU frequencies and some thermal files are blocked by SELinux on many phones. The app then shows "not provided" instead of guessing.
- Only battery temperature is available to normal apps. CPU and GPU temperature sensors are not exposed.
- Battery cycle count needs Android 14+ and manufacturer support.
- Sensor rate is capped near 200 Hz without the high-sampling-rate permission.
- Package visibility: only launchable apps are listed.
- The graphics test measures software Canvas drawing, not the GPU.
- Provider texts such as "Not exposed by Android" are English only. Interface labels are English and Russian.

## Not implemented

- C++/NDK and Rust modules: nothing in the app needs them, so none were added.
- Room export of settings, scheduled or background monitoring, Wi-Fi throughput test (only latency is implemented).
- Dedicated tablet layouts: screens are single-column lists that stretch.

## Testing

Verified in the authoring environment:
- Core logic (`Spec`, `Fmt`) compiled with Kotlin 2.0.21 and its assertions run and pass.
- All 29 Kotlin files were parsed by the Kotlin compiler with no syntax errors; one real bug (a `return` in an expression-bodied function) was found and fixed.

Not verified: Android compilation, resources, Room/KSP, Compose rendering, anything on a device. The checklist from the brief (Android versions, rotation, missing sensors, no network, denied permissions, low memory) still has to be run on real hardware.

## Update 4

- **Updates install over the old build.** A fixed sideload key is committed (`app/nexus-sideload.jks`) and the version code grows with every CI run, so a new APK installs over the previous one. Builds made before this update were signed with a different key, so uninstall the old app once; after that no more uninstalling.
- **Visual style** (Settings): Semi-transparent or Strictly opaque. The fake "Liquid Glass" was removed in 0.4.1: Compose has no cheap backdrop blur, so it could not be done honestly. Opaque is the lightest on GPU and battery.
- 0.4.2: tab switches no longer animate (no overlap), thermal reads run off the main thread, cards drawn without a clip layer, installed build is not debuggable, redesigned Settings.
- 0.4.1: fixed black-on-black text (content colour is now set explicitly), tab switching is instant instead of cross-fading two heavy screens, the nav highlight no longer bounces, removed leftover imports that broke the build.
- **Control** now has tabs: Processor, Display, Tweaks, Power. The processor loop runs only on its tab, power is read every 2 s only while the Power tab is open.
- **Refresh rate** writes `peak_refresh_rate`, `min_refresh_rate`, `user_refresh_rate` (and the Xiaomi `miui_refresh_rate`), reads the value back, and shows the real panel rate next to the setting. HyperOS may still override it per app.
- **Temperature**: CPU value is the median of per-core sensors, then an exponential moving average that ignores single-sample spikes.
- **Removed**: network diagnostics, storage analyzer, the Internet permission. The app has no network access.
- CPU/GPU frequency and governor changes need root; Shizuku alone cannot write those kernel files.
