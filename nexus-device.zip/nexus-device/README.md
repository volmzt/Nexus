# NEXUS DEVICE

Native Android app (Kotlin, Jetpack Compose, Material 3) that reads device information from Android APIs and system files. No account, no ads, no analytics, no root. Minimum Android 8.0 (API 26).

## Status

The source code is complete for the stages below, but **it has not been compiled or run on a device yet**. The environment where it was written has no Android SDK and cannot reach Google Maven, so the first real build happens in GitHub Actions. Expect to fix a few compile errors on that first run. See "Testing" for what was and was not verified.

## Build

Requirements: JDK 17, Android SDK (compileSdk 35). Android Studio Ladybug or newer opens the project directly.

```
./gradlew testDebugUnitTest      # unit tests
./gradlew assembleDebug          # app/build/outputs/apk/debug/
./gradlew assembleRelease        # app/build/outputs/apk/release/
./gradlew bundleRelease          # app/build/outputs/bundle/release/ (AAB for Google Play)
```

### GitHub Actions

`.github/workflows/build.yml` runs tests, lint, and builds the debug APK, release APK and AAB, then uploads them as workflow artifacts. Push to `main` (or run the workflow by hand) and download the files from the run page.

### Release signing

Without secrets the release APK is signed with the debug key, which is fine for installing and testing but not for Google Play. To sign properly, add these repository secrets:

| Secret | Meaning |
| --- | --- |
| `NEXUS_KEYSTORE_BASE64` | your `.jks` file encoded with `base64 -w0` |
| `NEXUS_KEYSTORE_PASSWORD` | keystore password |
| `NEXUS_KEY_ALIAS` | key alias |
| `NEXUS_KEY_PASSWORD` | key password |

## Architecture

Single Gradle module, packages follow the layers from the brief:

| Package | Role |
| --- | --- |
| `core` | `Spec` model, availability states, the shared error mechanism `spec { }`, formatting, manual DI container |
| `domain` | `Category`, `SpecProvider`, `DeviceRepository`, `Sample` |
| `hardware` | One provider per category (CPU, GPU, memory, storage, system, display, battery, network, sensors, cameras, codecs, apps) |
| `monitoring` | `SystemSampler`: one real measurement per call |
| `diagnostics` | Benchmarks, latency test, SAF storage analyzer |
| `database` | Room: benchmark results, monitor sessions |
| `data` | DataStore settings |
| `reporting` | TXT, JSON, HTML and PDF report builders |
| `presentation` | Compose screens, view models (MVVM, `StateFlow`), theme and components |

Every hardware read goes through `spec { }`: a missing value becomes "not provided", a `SecurityException` becomes "needs permission", and nothing is ever replaced by an invented number.

## What works (by design, pending first build)

- Home: device summary, RAM, battery, storage meters and temperature, live mini charts built from real samples, refresh button, last-update time.
- Device: 12 categories, search across all values, tap to copy, per-value status (available, approximate, not provided, needs permission).
- CPU: SoC, cores, ABIs, features, per-core min/max/current frequency read from sysfs, shown as unavailable when Android hides it.
- GPU: renderer, vendor, OpenGL ES and GLSL versions, Vulkan version, extension list with search.
- Memory, storage, system, display, battery, network, sensors, cameras (Camera2 characteristics only, camera is never opened), codecs (audio/video, profiles, resolutions, frame rates), app catalog with search and sorting.
- Monitor: start/stop, interval 0.5/1/2 s, RAM / temperature / battery / storage chart, min, average, max, per-core frequencies, connection state, saved session history. Stops automatically when the app goes to the background.
- Tests: CPU single and multi thread, memory bandwidth, allocation, storage write and read, canvas rendering, sensor rate. Each test is capped at about a second, runs are refused above 42 °C battery temperature, results are saved and compared with your own previous run. Display tests: colour fills, gradient, gray steps, multi-touch drawing.
- Tools: network latency (only on button press), storage analyzer for a folder you pick (largest files, extensions, SHA-256 duplicates), live sensor graphs.
- Settings: theme (dark, light, system), temperature unit, hidden sections, per-app language (Android 13+), clear history, reports (save as TXT, JSON, HTML, PDF through the system file picker, or share as text), privacy policy, licenses.

## Update 1 (UI rework)

- Home: compact device card and live tiles (battery with temperature, CPU frequency and temperature, storage). CPU temperature is read from thermal zones when Android allows it, otherwise "not provided".
- Scroll position is kept per tab and per detail page.
- Bottom bar: no press ripple, only the sliding highlight.
- Device: one-line summary per section, Simple / Detailed switch, tap = explanation dialog ("?" marks rows with an explanation), long-press = copy.
- Languages: English, Russian, Ukrainian (explanations are translated, parameter names stay in English).
- Next: Shizuku/root access, editing DPI/refresh rate/animations, throttling test, notification monitor, terminal, hidden Xiaomi screens, NEXUS score.

## Android limits that apply

- Serial number, factory battery capacity, GPU driver version, MAC address: not available to apps.
- Wi-Fi name and BSSID need location permission, mobile network type needs phone-state permission. The app does not ask for either and shows them as "needs permission".
- CPU frequencies and some thermal files are blocked by SELinux on many phones. The app then shows "not provided" instead of guessing.
- Only battery temperature is available to normal apps. CPU and GPU temperature sensors are not exposed.
- Battery cycle count needs Android 14+ and manufacturer support.
- Sensor rate is capped near 200 Hz without the high-sampling-rate permission.
- Package visibility: only launchable apps are listed.
- The graphics test measures software Canvas drawing, not the GPU.
- Provider texts such as "Not exposed by Android" are English only. Interface labels are English and Russian.

## Not implemented

- C++/NDK and Rust modules: nothing in the app needs them, so none were added.
- Room export of settings, scheduled or background monitoring, Wi-Fi throughput test (only latency is implemented).
- Dedicated tablet layouts: screens are single-column lists that stretch.

## Testing

Verified in the authoring environment:
- Core logic (`Spec`, `Fmt`) compiled with Kotlin 2.0.21 and its assertions run and pass.
- All 29 Kotlin files were parsed by the Kotlin compiler with no syntax errors; one real bug (a `return` in an expression-bodied function) was found and fixed.

Not verified: Android compilation, resources, Room/KSP, Compose rendering, anything on a device. The checklist from the brief (Android versions, rotation, missing sensors, no network, denied permissions, low memory) still has to be run on real hardware.
