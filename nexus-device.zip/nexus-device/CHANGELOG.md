# Changelog

## 0.9.33
- Home: blocks of the same size now simply swap cells; the other blocks stay in place.
- Home: "Empty" cells (button in edit mode) to leave free space; tap one in edit mode to remove it.
- Home: autoscroll while dragging near the screen edge.
- Floating window with battery %, FPS (screen refresh rate without Shizuku/root), time and temperature.
- Check tab: hidden Android and Xiaomi system screens.
- R8 keep rules for Shizuku.
